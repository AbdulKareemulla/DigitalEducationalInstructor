using Microsoft.VisualStudio.TestTools.UnitTesting;
using DataStructureAldoPractice1;
namespace AlgoUnitTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            int[] arr = { 6, 4, 7, 2, 8 };
            int[] isequl = { 2, 4, 6, 7, 8 };

            int[] res = LinearSort.LinearSort1(arr);
            
            Assert.AreEqual(res[0], isequl[0]);
            Assert.AreEqual(res[1], isequl[1]);
            Assert.AreEqual(res[2], isequl[2]);
            Assert.AreEqual(res[3], isequl[3]);
            Assert.AreEqual(res[4], isequl[4]);
        }

    }
}
