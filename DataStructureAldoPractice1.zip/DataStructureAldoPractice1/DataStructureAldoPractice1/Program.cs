﻿using Logical;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataStructureAldoPractice1
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arr = { 6, 4, 7, 2, 8 };
            int[] res = LinearSort.LinearSort1(arr);
            //int[] arr = { 10, 80, 30, 90, 40, 50, 70 };
            //QuickSort.QuickSort2(arr, 0, arr.Length-1);

            //DefaultQueueAlgorithms defaultQueueAlgorithms = new DefaultQueueAlgorithms();
            //defaultQueueAlgorithms.EnQue(20);
            //defaultQueueAlgorithms.EnQue(30);
            //defaultQueueAlgorithms.Display();
            //defaultQueueAlgorithms.DeQue();
            //defaultQueueAlgorithms.DeQue();

            //Fixed Size
            //ImplementQueueFromArray quearr = new ImplementQueueFromArray();
            //quearr.EnQue(1);
            //quearr.EnQue(2);
            //quearr.EnQue(3);
            //quearr.EnQue(4);
            //quearr.EnQue(5);
            //quearr.Display();
            //quearr.DeQue();
            //quearr.EnQue(6);
            //quearr.Display();
        }
    }
}
