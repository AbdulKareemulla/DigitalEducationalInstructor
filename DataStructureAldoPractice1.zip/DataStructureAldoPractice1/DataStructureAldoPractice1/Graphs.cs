﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataStructureAldoPractice1
{
    public class TreeGraphs
    {
        public TreeGraphNode CreateGraph()
        {
            TreeGraphNode root =
                new TreeGraphNode("A",
                new TreeGraphNode("B",
                new TreeGraphNode("C"), new TreeGraphNode("D")),
                new TreeGraphNode("E",
                new TreeGraphNode("F"), new TreeGraphNode("G",
                new TreeGraphNode("H"), null)));

            return root;
        }

        public void BFSTraversal(TreeGraphNode node)
        {
            Queue<TreeGraphNode> Quegraph = new Queue<TreeGraphNode>();
            Quegraph.Enqueue(node);
            while (Quegraph.Count > 0)
            {
                TreeGraphNode nde = Quegraph.Dequeue();
                Console.Write(nde.data + " ");

                if (nde.left != null)
                    Quegraph.Enqueue(nde.left);

                if (nde.right != null)
                    Quegraph.Enqueue(nde.right);
            }

            Console.WriteLine();
        }


        public void DFSTraversal(TreeGraphNode node)
        {
            if (node == null)
                return;
            Console.Write(node.data + " ");
            DFSTraversal(node.left);
            DFSTraversal(node.right);
        }
    }

    public class TreeGraphNode
    {
        public string data;
        public TreeGraphNode left;
        public TreeGraphNode right;
        public TreeGraphNode(string d)
        {
            data = d;
            left = right = null;
        }

        public TreeGraphNode(string d, TreeGraphNode lft, TreeGraphNode rght)
        {
            data = d;
            left = lft;
            right = rght;
        }


    }

    public class Graphs
    {
        LinkedList<int>[] adj = null;
        int v;
        public Graphs(int v)
        {
            this.v = v;
            adj = new LinkedList<int>[v];
            for (int i = 0; i < adj.Length; i++)
            {
                adj[i] = new LinkedList<int>();
            }
        }

        public void AddEdge(int c, int v)
        {
            adj[c].AddLast(v);
        }

        public void BFS(int startingvertex)
        {
            bool[] visited = new bool[v];


            Queue<int> quelist = new Queue<int>();
            quelist.Enqueue(startingvertex);
            visited[startingvertex] = true;
            while (quelist.Count > 0)
            {
                int s = quelist.Dequeue();
                Console.Write(s + " ");

                LinkedList<int> lnklst = adj[s];

                foreach (int lst in lnklst)
                {
                    if (!visited[lst])
                    {
                        visited[lst] = true;
                        quelist.Enqueue(lst);
                    }
                }
            }
        }


        public void DFS(int startingvertex)
        {
            bool[] visited = new bool[v];

            Stack<int> quelist = new Stack<int>();
            quelist.Push(startingvertex);
            visited[startingvertex] = true;
            while (quelist.Count > 0)
            {
                int s = quelist.Pop();
                Console.Write(s + " ");

                foreach (int lst in adj[s])
                {
                    if (!visited[lst])
                    {
                        visited[lst] = true;
                        quelist.Push(lst);
                    }
                }
            }
        }
    }

    public class BFSInMatrix
    {
        public void BFS(int[,] matrix)
        {
            int h = matrix.GetLength(0);
            if (h == 0)
                return;
            int l = matrix.GetLength(1);
            Boolean[,] visited = new Boolean[h, l];

            Queue<string> que = new Queue<string>();
            que.Enqueue("0,0");

            while (que.Count > 0)
            {
                string s = que.Dequeue();

                int row = Convert.ToInt32(s.Split(',')[0]);
                int col = Convert.ToInt32(s.Split(',')[1]);

                if ((row < 0) || (col < 0) || row >= h || col >= l || visited[row, col])
                    continue;

                visited[row, col] = true;
                Console.Write(matrix[row, col] + " ");
                que.Enqueue(row + "," + (col - 1));
                que.Enqueue(row + "," + (col + 1));
                que.Enqueue(row - 1 + "," + (col));
                que.Enqueue(row + 1 + "," + (col));
            }
        }


        public void DFS(int[,] matrix)
        {
            int h = matrix.GetLength(0);
            if (h == 0)
                return;
            int l = matrix.GetLength(1);

            Boolean[,] visited = new Boolean[h, l];

            Stack<string> stk = new Stack<string>();
            stk.Push("0,0");

            while (stk.Count > 0)
            {
                string s = stk.Pop();
                int row = Convert.ToInt32(s.Split(',')[0]);
                int col = Convert.ToInt32(s.Split(',')[1]);

                if (row < 0 || col < 0 || row >= h || col >= l || visited[row, col])
                    continue;

                visited[row, col] = true;
                Console.Write(matrix[row, col] + " ");
                stk.Push(row + "," + (col - 1));
                stk.Push(row + "," + (col + 1));
                stk.Push(row - 1 + "," + (col));
                stk.Push(row + 1 + "," + (col));
            }

        }


        public void DFSRecursive(int[,] matrix)
        {
            int h = matrix.GetLength(0);
            if (h == 0)
                return;
            int l = matrix.GetLength(1);

            Boolean[,] visited = new Boolean[h, l];

            DFSUtil(matrix, 0, 0, visited);
        }


        public void DFSUtil(int[,] matrix, int row, int col, Boolean[,] visited)
        {
            int h = matrix.GetLength(0);
            int l = matrix.GetLength(1);

            if (row < 0 || col < 0 || col >= l || row >= h || visited[row, col])
                return;

            visited[row, col] = true;
            Console.Write(matrix[row, col] + " ");

            DFSUtil(matrix, row + 1, col, visited);
            DFSUtil(matrix, row - 1, col, visited);
            DFSUtil(matrix, row, col + 1, visited);
            DFSUtil(matrix, row, col - 1, visited);

        }

    }

    class Graph
    {
        int vertices;
        int[,] matrix;

        public Graph(int v)
        {
            this.vertices = v;
            matrix = new int[v, v];
        }

        public void AddEdges(int row, int col, int weight)
        {
            matrix[row, col] = weight;
            matrix[col, row] = weight;
        }

        public int MinimumVertex(bool[] mst, int[] key)
        {
            int vertex = -1;

            int min = int.MaxValue;

            for (int i = 0; i < vertices; i++)
            {
                if (mst[i] == false && key[i] < min)
                {
                    min = key[i];
                    vertex = i;
                }
            }

            return vertex;
        }

        public class ResultSet
        {
            public int parent;
            public int weight;
        }

        public void PrimsMST()
        {
            bool[] mst = new bool[vertices];
            int[] keys = new int[vertices];
            ResultSet[] resultSet = new ResultSet[vertices];
            for (int i = 0; i < vertices; i++)
            {
                keys[i] = int.MaxValue;
                resultSet[i] = new ResultSet();
            }


            keys[0] = 0;
            resultSet[0].parent = -1;


            for (int i = 0; i < vertices; i++)
            {
                int vertex = MinimumVertex(mst, keys);
                mst[vertex] = true;
                for (int j = 0; j < vertices; j++)
                {
                    if (matrix[vertex, j] > 0)
                    {
                        if (mst[j] == false && keys[j] > matrix[vertex, j])
                        {
                            keys[j] = matrix[vertex, j];
                            resultSet[j].parent = vertex;
                            resultSet[j].weight = keys[j];
                        }
                    }
                }
            }

            PrintPrimsVertices(resultSet);


        }

        public void PrintPrimsVertices(ResultSet[] resultSets)
        {
            int totalweight = 0;
            for (int i = 1; i < vertices; i++)
            {
                Console.WriteLine("Edge : " + i + "-" + resultSets[i].parent + " Weight" + resultSets[i].weight);
                totalweight = totalweight + resultSets[i].weight;
            }

            Console.WriteLine("Total weight of spanning Tree : " + totalweight);
        }
    }

    public class KrushkalExample
    {
        public class KrushkalEdge
        {
            public int Source;
            public int Destination;
            public int Weight;
        }

        public class KrushkalGraph
        {
            public int VerticesCount;
            public int Edgecount;
            public KrushkalEdge[] edge;
        }

        public class Subset
        {
            public int Rank;
            public int Parent;
        }

        public KrushkalGraph CreateGraph(int verticescount, int edgecount)
        {
            KrushkalGraph krushkalGraph = new KrushkalGraph();
            krushkalGraph.Edgecount = edgecount;
            krushkalGraph.VerticesCount = verticescount;
            krushkalGraph.edge = new KrushkalEdge[edgecount];
            return krushkalGraph;
        }
        public int FindParent(Subset[] subsets, int i)
        {
            if (subsets[i].Parent != i)
                subsets[i].Parent = FindParent(subsets, subsets[i].Parent);

            return subsets[i].Parent;
        }

        public void Union(Subset[] subsets, int x, int y)
        {
            int xparent = FindParent(subsets, x);
            int yparent = FindParent(subsets, y);

            if (subsets[xparent].Rank < subsets[yparent].Rank)
            {
                subsets[xparent].Parent = yparent;

            }
            else if (subsets[xparent].Rank > subsets[yparent].Rank)
            {
                subsets[yparent].Parent = xparent;
            }
            else
            {
                subsets[yparent].Parent = xparent;
                ++subsets[xparent].Rank;
            }
        }

        public void KrushkalAlgorithm(KrushkalGraph graph)
        {

            int vertices = graph.VerticesCount;
            KrushkalEdge[] edges = graph.edge;
            Subset[] subsets = new Subset[vertices];
            KrushkalEdge[] results = new KrushkalEdge[vertices];

            Array.Sort(graph.edge, delegate (KrushkalEdge a, KrushkalEdge b)
            {
                return a.Weight.CompareTo(b.Weight);
            });

            int e = 0;
            int i = 0;

            for (int v = 0; v < subsets.Length; v++)
            {
                subsets[v] = new Subset();
                subsets[v].Parent = v;
                subsets[v].Rank = 0;
            }

            while (e < vertices - 1)
            {
                KrushkalEdge nextedge = edges[i++];
                int x = FindParent(subsets, nextedge.Source);
                int y = FindParent(subsets, nextedge.Destination);
                if (x != y)
                {
                    results[e++] = nextedge;
                    Union(subsets, x, y);
                }
            }

            for (int j = 0; j < e; j++)
            {
                Console.WriteLine(results[j].Source + "-->" + results[j].Destination + "  " + results[j].Weight);
            }
        }
    }

    public class Edge
    {
        public int source, dest;

        public Edge(int source, int dest)
        {
            this.source = source;
            this.dest = dest;
        }
    }

    // Class to represent a graph object
    public class GraphDetectCycleUndirected
    {
        // A List of Lists to represent an adjacency list
        public List<List<int>> adjList = null;

        // Constructor
        public GraphDetectCycleUndirected(List<Edge> edges, int N)
        {
            adjList = new List<List<int>>();

            for (int i = 0; i < N; i++)
            {
                adjList.Add(new List<int>());
            }

            // add edges to the undirected graph
            foreach (Edge edge in edges)
            {
                int src = edge.source;
                int dest = edge.dest;

                adjList[src].Add(dest);
                adjList[dest].Add(src);
            }
        }

        public Boolean BFS(GraphDetectCycleUndirected graph, int src, int N)
        {
            Boolean[] discovered = new Boolean[N];
            discovered[src] = true;
            Queue<GNode> q = new Queue<GNode>();
            q.Enqueue(new GNode(src, -1));
            while (q.Count > 0)
            {
                GNode node = q.Dequeue();
                foreach (int u in graph.adjList[(node.v)])
                {
                    if (!discovered[u])
                    {
                        discovered[u] = true;
                        q.Enqueue(new GNode(u, node.v));
                    }
                    else if (u != node.parent)
                    {
                        return true;
                    }
                }
            }
            return false;
        }
    }
    // Node to store vertex and its parent info in BFS
    public class GNode
    {
        public int v, parent;

        public GNode(int v, int parent)
        {
            this.v = v;
            this.parent = parent;
        }
    }


    // Direct Graph using DFS
    public class DGGraph
    {
        public int V;
        public List<List<int>> adjlist;
        public DGGraph(int v)
        {
            V = v;
            adjlist = new List<List<int>>(v);
            for (int i = 0; i < v; i++)
            {
                adjlist.Add(new List<int>());
            }
        }

        public void addEdge(int src, int des)
        {
            adjlist[src].Add(des);
        }


        public bool isCyclic()
        {
            bool[] visited = new bool[V];
            bool[] refStack = new bool[V];

            for (int i = 0; i < V; i++)
            {
                if (CyclicUtil(i, visited, refStack))
                    return true;
            }

            return false;
        }

        public bool CyclicUtil(int i, bool[] visited, bool[] refStack)
        {
            if (refStack[i])
                return true;

            if (visited[i])
                return false;

            visited[i] = true;
            refStack[i] = true;

            List<int> lst = adjlist[i];
            foreach (int item in lst)
            {
                if (CyclicUtil(item, visited, refStack))
                    return true;
            }

            refStack[i] = false;

            return false;
        }
    }

    public class UDGraph
    {
        public int V;
        public List<List<int>> adglist;
        public UDGraph(int v)
        {
            V = v;
            adglist = new List<List<int>>(v);
            for (int i = 0; i < v; i++)
            {
                adglist.Add(new List<int>());
            }
        }

        public void addEdge(int src, int des)
        {
            adglist[src].Add(des);
            adglist[des].Add(src);
        }

        public bool isCycle()
        {
            bool[] visited = new bool[V];


            for (int i = 0; i < V; i++)
            {
                if (!visited[i])
                {
                    if (CycleUtil(i, visited, -1))
                        return true;
                }
            }

            return false;
        }


        public bool CycleUtil(int v, bool[] visited, int parent)
        {
            visited[v] = true;

            foreach (int item in adglist[v])
            {
                if (!visited[item])
                {
                    if (CycleUtil(item, visited, v))
                        return true;
                }
                else if (item != parent)
                    return true;
            }

            return false;
        }
    }

    public class FindBridges
    {
        public int vertices;
        public List<List<int>> adjlist;
        public int time = 0;
        public FindBridges(int v)
        {
            vertices = v;
            adjlist = new List<List<int>>(v);
            for (int i = 0; i < v; i++)
            {
                adjlist.Add(new List<int>(i));
            }
        }

        public void addEdge(int src, int des)
        {
            adjlist[src].Add(des);
            adjlist[des].Add(src);
        }

        public void DisplayBridgeUtil(int u, bool[] visited, int[] low, int[] disc, int[] parent)
        {
            visited[u] = true;
            low[u] = disc[u] = ++time;
            foreach (int i in adjlist[u])
            {
                int v = i;

                if (!visited[v])
                {
                    parent[v] = u;

                    DisplayBridgeUtil(v, visited, low, disc, parent);

                    low[u] = Math.Min(low[u], low[v]);
                    if (low[v] > disc[u])
                        Console.WriteLine(u + " --> " + v);
                }

                else if (v != parent[u])
                {
                    low[u] = Math.Min(low[u], disc[v]);
                }
            }
        }
        public void DisplayBridges()
        {
            bool[] visited = new bool[vertices];
            int[] parent = new int[vertices];
            int[] low = new int[vertices];
            int[] disc = new int[vertices];

            for (int i = 0; i < vertices; i++)
            {
                visited[i] = false;
                parent[i] = -1;
            }

            for (int i = 0; i < vertices; i++)
            {
                if (!visited[i])
                    DisplayBridgeUtil(i, visited, low, disc, parent);
            }
        }
    }


    public class TopologyGraphs
    {
        public int vertices;

        public List<List<int>> adjlist;

        public TopologyGraphs(int vert)
        {
            vertices = vert;

            adjlist = new List<List<int>>(vert);
            for (int i = 0; i < vert; i++)
            {
                adjlist.Add(new List<int>());
            }
        }

        public void addEdge(int src, int des)
        {
            adjlist[src].Add(des);
        }

        public void TopologySort()
        {
            bool[] visited = new bool[vertices];
            Stack<int> stck = new Stack<int>();
            for (int i = 0; i < vertices; i++)
            {
                if (!visited[i])
                {
                    TopologyUtil(i, visited, stck);
                }
            }

            foreach (var item in stck)
            {
                Console.Write(item + " ");
            }
        }

        public void TopologyUtil(int vertex, bool[] visited, Stack<int> stck)
        {
            visited[vertex] = true;
            foreach (int item in adjlist[vertex])
            {
                if (!visited[item])
                {
                    TopologyUtil(item, visited, stck);
                }
            }
            stck.Push(vertex);
        }
    }

    public class ConnectedComponentGraphs
    {
        public int vertices;
        public List<List<int>> adjlis;
        public ConnectedComponentGraphs(int vertices)
        {
            this.vertices = vertices;
            adjlis = new List<List<int>>(vertices);
            for (int i = 0; i < vertices; i++)
            {
                adjlis.Add(new List<int>());
            }
        }

        public void addEdge(int src, int des)
        {
            adjlis[src].Add(des);
            adjlis[des].Add(src);
        }

        public void DFSUtil(int vertex, bool[] visited)
        {
            visited[vertex] = true;
            Console.Write(vertex + " ");
            foreach (var item in adjlis[vertex])
            {
                if (!visited[item])
                {
                    DFSUtil(item, visited);
                }
            }
        }

        public void connectedComponents()
        {
            bool[] visited = new bool[vertices];

            for (int i = 0; i < vertices; i++)
            {
                if (!visited[i])
                {
                    DFSUtil(i, visited);
                    Console.WriteLine();
                }
            }

        }

    }

    public class StronglyConnectedGraph
    {
        public int vertices;
        public List<List<int>> adjlst;
        public StronglyConnectedGraph(int v)
        {
            vertices = v;
            adjlst = new List<List<int>>(v);

            for (int i = 0; i < vertices; i++)
            {
                adjlst.Add(new List<int>());
            }
        }

        public void addEdge(int src, int des)
        {
            adjlst[src].Add(des);
        }


        public StronglyConnectedGraph Transpose()
        {
            StronglyConnectedGraph g = new StronglyConnectedGraph(vertices);

            for (int i = 0; i < vertices; i++)
            {
                foreach (var item in adjlst[i])
                {
                    g.adjlst[item].Add(i);
                }
            }

            return g;
        }



        public void DFSUtil(int vertex, bool[] visited, Stack<int> stck, bool isprint)
        {

            visited[vertex] = true;

            if (isprint)
                Console.Write(vertex + " ");
            foreach (var item in adjlst[vertex])
            {
                if (!visited[item])
                    DFSUtil(item, visited, stck, isprint);
            }


            if (!isprint)
                stck.Push(vertex);
        }

        public void PrintSCCs()
        {
            bool[] visited = new bool[vertices];
            Stack<int> stack = new Stack<int>();
            for (int i = 0; i < vertices; i++)
            {
                if (!visited[i])
                    DFSUtil(i, visited, stack, false);
            }

            StronglyConnectedGraph g = Transpose();

            for (int i = 0; i < vertices; i++)
            {
                visited[i] = false;
            }

            while (stack.Count > 0)
            {
                int v = stack.Pop();
                if (!visited[v])
                {
                    g.DFSUtil(v, visited, stack, true);
                    Console.WriteLine();
                }
            }

        }
    }

    public class TGraph
    {
        private int V;
        private List<List<int>> adj;

        public TGraph(int v)
        {
            V = v;
            adj = new List<List<int>>(V);
            for (int i = 0; i < v; ++i)
                adj.Add(new List<int>());
        }

        public void addEdge(int v, int w) { adj[v].Add(w); }



        void DFSUtil(int v, Boolean[] visited, bool isprint, Stack<int> stck)
        {
            visited[v] = true;
            if (isprint)
                Console.Write(v + " ");


            foreach (var item in adj[v])
            {
                if (!visited[item])
                    DFSUtil(item, visited, isprint, stck);
            }

            if (!isprint)
                stck.Push(v);
        }


        TGraph getTranspose()
        {
            TGraph g = new TGraph(V);
            for (int v = 0; v < V; v++)
            {
                foreach (var item in adj[v])
                {
                    g.adj[item].Add(v);
                }
            }
            return g;
        }

        public void printSCCs()
        {
            Stack<int> stack = new Stack<int>();

            Boolean[] visited = new Boolean[V];
            for (int i = 0; i < V; i++)
                visited[i] = false;

            for (int i = 0; i < V; i++)
                if (visited[i] == false)
                    DFSUtil(i, visited, false, stack);

            TGraph gr = getTranspose();

            for (int i = 0; i < V; i++)
                visited[i] = false;

            while (stack.Count > 0)
            {
                int v = (int)stack.Pop();

                if (visited[v] == false)
                {
                    gr.DFSUtil(v, visited, true, stack);
                    Console.WriteLine();
                }
            }
        }
    }

    public class Dijsktra
    {
        public int V;
        public Dijsktra(int v)
        {
            V = v;
        }

        public int minimumVertex(int[] dist, bool[] visitset)
        {
            int min = int.MaxValue;
            int minindex = -1
;
            for (int i = 0; i < V; i++)
            {
                if (!visitset[i] && min >= dist[i])
                {
                    min = dist[i];
                    minindex = i;
                }
            }
            return minindex;
        }

        public void printDistance(int[] dist)
        {
            for (int i = 0; i < V; i++)
            {
                Console.WriteLine(i + "  distance  " + dist[i]);
            }
        }

        public void DijsktraAlgo(int[,] graph, int src)
        {
            int[] dist = new int[V];
            bool[] vistset = new bool[V];

            for (int i = 0; i < V; i++)
            {
                dist[i] = int.MaxValue;
                vistset[i] = false;
            }

            dist[src] = 0;

            for (int i = 0; i < V - 1; i++)
            {
                int u = minimumVertex(dist, vistset);
                vistset[u] = true;

                for (int v = 0; v < V; v++)
                    if (!vistset[v] && graph[u, v] != 0 && dist[u] != int.MaxValue && dist[u] + graph[u, v] < dist[v])
                        dist[v] = dist[u] + graph[u, v];
            }

            printDistance(dist);
        }
    }

    public class BellmanFordGraph
    {
        public class Edge
        {
            public int src;
            public int dest;
            public int weight;

            public Edge()
            {
                src = dest = weight = 0;
            }

        }
        public int V;
        public int E;
        public Edge[] edge;
        public BellmanFordGraph(int v, int e)
        {
            E = e;
            V = v;
            edge = new Edge[e];
            for (int i = 0; i < e; i++)
            {
                edge[i] = new Edge();
            }
        }

        public void PrintGraph(int[] dist)
        {
            for (int i = 0; i < dist.Length; i++)
            {
                Console.WriteLine(i + " " + dist[i]);
            }
        }
        public void BellmanFodAlgo(BellmanFordGraph bmfgraph, int src)
        {
            int[] dist = new int[V];

            for (int i = 0; i < V; i++)
            {
                dist[i] = int.MaxValue;
            }
            dist[src] = 0;

            for (int i = 0; i < V; i++)
            {
                for (int j = 0; j < E; j++)
                {
                    int u = bmfgraph.edge[j].src;
                    int v = bmfgraph.edge[j].dest;
                    int weight = bmfgraph.edge[j].weight;
                    if (dist[u] != int.MaxValue && dist[u] + weight < dist[v])
                        dist[v] = dist[u] + weight;
                }
            }


            for (int i = 0; i < V; i++)
            {
                for (int j = 0; j < E; j++)
                {
                    int u = bmfgraph.edge[j].src;
                    int v = bmfgraph.edge[j].dest;
                    int weight = bmfgraph.edge[j].weight;
                    if (dist[u] != int.MaxValue && dist[u] + weight < dist[v])
                    {
                        dist[v] = dist[u] + weight;
                        Console.WriteLine("Graph Contains negative cycle");
                        return;
                    }
                }
            }

            PrintGraph(dist);

        }
    }

    public class FloydWarshall
    {
        public int Vertices;
        public int inf = int.MaxValue;
        public FloydWarshall(int vertices)
        {
            this.Vertices = vertices;
        }
        public void PrintGraph(int[,] dist)
        {

            for (int i = 0; i < Vertices; i++)
            {
                for (int j = 0; j < Vertices; j++)
                {
                    if (dist[i, j] == 99999)
                    {
                        Console.Write("INF ");
                    }
                    else
                    {
                        Console.Write(dist[i, j] + "  ");
                    }
                }
                Console.WriteLine();

            }
        }

        public void FloydWarshallAlgo(int[,] graph)
        {
            int[,] dist = new int[Vertices, Vertices];

            for (int i = 0; i < Vertices; i++)
            {
                for (int j = 0; j < Vertices; j++)
                {
                    dist[i, j] = graph[i, j];
                }
            }


            for (int k = 0; k < Vertices; k++)
            {
                for (int i = 0; i < Vertices; i++)
                {
                    for (int j = 0; j < Vertices; j++)
                    {
                        if (dist[i, j] > (dist[i, k] + dist[k, j]))
                            dist[i, j] = (dist[i, k] + dist[k, j]);
                    }
                }
            }

            PrintGraph(dist);
        }
    }

    public class MColoringGraph
    {
        public int vertices;
        public int[] color;
        public int m;
        public int[,] graph;
        public MColoringGraph(int v, int m, int[,] g)
        {
            vertices = v;
            color = new int[v];
            this.m = m;
            graph = g;
        }

        public void PrintColor()
        {
            for (int i = 0; i < color.Length; i++)
            {
                Console.WriteLine("Vertex " + i + " " + color[i]);
            }
        }

        public void ColoringGraph(int k)
        {
            for (int c = 1; c <= m; c++)
            {
                if (IsSafe(k, c))
                {
                    color[k] = c;
                    if (k + 1 < vertices)
                    {
                        ColoringGraph(k + 1);
                    }
                }
            }
        }

        public bool IsSafe(int v, int c)
        {
            for (int i = 0; i < vertices; i++)
            {
                if (graph[v, i] == 1 && c == color[i])
                    return false;
            }
            return true;
        }
    }

    public class CheckMColoringGraph
    {
        public int vertices;
        public int[] color;
        public int m;
        public int[,] graph;
        public CheckMColoringGraph(int v, int m, int[,] g)
        {
            vertices = v;
            color = new int[v];
            this.m = m;
            graph = g;
        }

        public void PrintColor()
        {
            for (int i = 0; i < color.Length; i++)
            {
                Console.WriteLine("Vertex " + i + " " + color[i]);
            }
        }


        public void ColoringGraph(int k)
        {
            if (ColoringGraphUtil(k))
            {
                Console.WriteLine(" can build the graph with these number of colors ");
                PrintColor();
            }
            else
            {
                Console.WriteLine(" Cannot build the graph with these number of colors ");
            }
        }
        public bool ColoringGraphUtil(int k)
        {
            if (k == vertices)
                return true;
            for (int c = 1; c <= m; c++)
            {
                if (IsSafe(k, c))
                {
                    color[k] = c;
                    if (ColoringGraphUtil(k + 1))
                        return true;
                    color[k] = 0;
                }
            }

            return false;
        }

        public bool IsSafe(int v, int c)
        {
            for (int i = 0; i < vertices; i++)
            {
                if (graph[v, i] == 1 && c == color[i])
                    return false;
            }
            return true;
        }

        //bool graphColoringUtil(int[,] graph, int m,
        //                int[] color, int v)
        //{
        //    if (v == vertices)
        //        return true;
        //    for (int c = 1; c <= m; c++)
        //    {
        //        if (IsSafe(v, graph, color, c))
        //        {
        //            color[v] = c;
        //            if (graphColoringUtil(graph, m,
        //                                  color, v + 1))
        //                return true;
        //            color[v] = 0;
        //        }
        //    }


        //    return false;
        //}

    }

    public class HManNode
    {
        public char Symbol { get; set; }
        public int Frequency { get; set; }
        public HManNode Right { get; set; }
        public HManNode Left { get; set; }
    }

    public class HuffmanTree
    {
        private List<HManNode> nodes = new List<HManNode>();
        public HManNode Root { get; set; }
        public Dictionary<char, int> Frequencies = new Dictionary<char, int>();



        public BitArray Encode(string source)
        {
            List<bool> encodedSource = new List<bool>();
            for (int i = 0; i < source.Length; i++)
            {
                List<bool> encodedSymbol = Traverse(source[i], new List<bool>(), this.Root);
                encodedSource.AddRange(encodedSymbol);
            }

            BitArray bits = new BitArray(encodedSource.ToArray());

            return bits;
        }

        public string Decode(BitArray bits)
        {
            HManNode current = this.Root;
            string decoded = "";

            foreach (bool bit in bits)
            {
                if (bit)
                {
                    if (current.Right != null)
                    {
                        current = current.Right;
                    }
                }
                else
                {
                    if (current.Left != null)
                    {
                        current = current.Left;
                    }
                }

                if (IsLeaf(current))
                {
                    decoded += current.Symbol;
                    current = this.Root;
                }
            }

            return decoded;
        }

        public bool IsLeaf(HManNode node)
        {
            return (node.Left == null && node.Right == null);
        }

        public List<bool> Traverse(char symbol, List<bool> data, HManNode Root)
        {
            // Leaf
            if (Root.Right == null && Root.Left == null)
            {
                if (symbol.Equals(Root.Symbol))
                {
                    return data;
                }
                else
                {
                    return null;
                }
            }
            else
            {
                List<bool> left = null;
                List<bool> right = null;

                if (Root.Left != null)
                {
                    List<bool> leftPath = new List<bool>();
                    leftPath.AddRange(data);
                    leftPath.Add(false);

                    left = Traverse(symbol, leftPath, Root.Left);
                }

                if (Root.Right != null)
                {
                    List<bool> rightPath = new List<bool>();
                    rightPath.AddRange(data);
                    rightPath.Add(true);
                    right = Traverse(symbol, rightPath, Root.Right);
                }

                if (left != null)
                {
                    return left;
                }
                else
                {
                    return right;
                }
            }
        }

        public void Build(string source)
        {
            for (int i = 0; i < source.Length; i++)
            {
                if (!Frequencies.ContainsKey(source[i]))
                {
                    Frequencies.Add(source[i], 0);
                }

                Frequencies[source[i]]++;
            }

            foreach (KeyValuePair<char, int> symbol in Frequencies)
            {
                nodes.Add(new HManNode() { Symbol = symbol.Key, Frequency = symbol.Value });
            }

            while (nodes.Count > 1)
            {
                List<HManNode> orderedNodes = nodes.OrderBy(node => node.Frequency).ToList<HManNode>();

                if (orderedNodes.Count >= 2)
                {
                    // Take first two items
                    List<HManNode> taken = orderedNodes.Take(2).ToList<HManNode>();

                    // Create a parent node by combining the frequencies
                    HManNode parent = new HManNode()
                    {
                        Symbol = '*',
                        Frequency = taken[0].Frequency + taken[1].Frequency,
                        Left = taken[0],
                        Right = taken[1]
                    };

                    nodes.Remove(taken[0]);
                    nodes.Remove(taken[1]);
                    nodes.Add(parent);
                }

                this.Root = nodes.FirstOrDefault();

            }

        }
    }

    public class HuffmanNode
    {
        public char Symbol { get; set; }
        public int Frequencies { get; set; }
        public HuffmanNode Left { get; set; }
        public HuffmanNode Right { get; set; }
    }

    public class HuffmanAlgorithm
    {
        Dictionary<char, int> Frequency = new Dictionary<char, int>();
        List<HuffmanNode> listnode = new List<HuffmanNode>();
        HuffmanNode Root;
        public void Build(string input)
        {
            for (int i = 0; i < input.Length; i++)
            {
                if (!Frequency.ContainsKey(input[i]))
                {
                    Frequency.Add(input[i], 0);
                }
                Frequency[input[i]]++;
            }

            foreach (KeyValuePair<char, int> item in Frequency)
            {
                listnode.Add(new HuffmanNode { Frequencies = item.Value, Symbol = item.Key });
            }

            while (listnode.Count > 1)
            {
                listnode = listnode.OrderBy(node => node.Frequencies).ToList<HuffmanNode>();

                if (listnode.Count >= 2)
                {
                    List<HuffmanNode> lstnde = listnode.Take(2).ToList<HuffmanNode>();

                    HuffmanNode parent = new HuffmanNode()
                    {
                        Symbol = '*',
                        Frequencies = lstnde[0].Frequencies + lstnde[1].Frequencies,
                        Left = lstnde[0],
                        Right = lstnde[1]
                    };

                    listnode.Remove(lstnde[0]);
                    listnode.Remove(lstnde[1]);
                    listnode.Add(parent);
                }

                this.Root = listnode.FirstOrDefault();

            }
        }

        public List<bool> Traverse(char symbol, List<bool> data, HuffmanNode Root)
        {
            if (Root.Left == null && Root.Right == null)
            {
                if (Root.Symbol == symbol)
                {
                    return data;
                }
                else
                {
                    return null;
                }
            }
            else
            {
                List<bool> lftdata = null;
                List<bool> rightdata = null;
                if (Root.Left != null)
                {
                    List<bool> leftnode = new List<bool>();
                    leftnode.AddRange(data);
                    leftnode.Add(false);
                    lftdata = Traverse(symbol, leftnode, Root.Left);
                }
                if (Root.Right != null)
                {
                    List<bool> rightnode = new List<bool>();
                    rightnode.AddRange(data);
                    rightnode.Add(true);
                    rightdata = Traverse(symbol, rightnode, Root.Right);
                }
                if (lftdata != null)
                {
                    return lftdata;
                }
                else
                {
                    return rightdata;
                }
            }



        }

        public BitArray Encode(string input)
        {

            List<bool> lst = new List<bool>();
            for (int i = 0; i < input.Length; i++)
            {
                List<bool> rootlst = Traverse(input[i], new List<bool>(), Root);
                lst.AddRange(rootlst);
            }

            BitArray bits = new BitArray(lst.ToArray());
            return bits;
        }

        public string Decode(BitArray bits)
        {
            HuffmanNode current = this.Root;
            string decoded = "";
            foreach (bool bit in bits)
            {
                if (bit)
                {
                    if (Root.Right != null)
                    {
                        current = current.Right;
                    }
                }
                else
                {
                    if (Root.Left != null)
                    {
                        current = current.Left;
                    }
                }

                if (current.Left == null && current.Right == null)
                {
                    decoded += current.Symbol;
                    current = this.Root;
                }
            }

            return decoded;
        }
    }

}
