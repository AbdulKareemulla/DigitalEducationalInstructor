﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataStructureAldoPractice1
{
    public class StringAlgo
    {
        public static int[] IncrementArrayByOne(int[] arr)
        {
            int carry = 1;
            int[] result = new int[arr.Length];
            for (int i = arr.Length - 1; i >= 0; i--)
            {
                int sum = arr[i] + carry;
                if (sum == 10)
                {
                    carry = 1;
                }
                else
                {
                    carry = 0;
                }
                result[i] = sum;
            }
            if (carry == 1)
            {
                result = new int[arr.Length + 1];
                result[0] = 1;
            }
            return result;
        }

        public static int[] IncrementByOne(int[] arr)
        {

            string k = "";
            for (int i = 0; i < arr.Length; i++)
            {
                k = k + Convert.ToString(arr[i]);
            }

            int outpu = Convert.ToInt16(k) + 1;
            string kk = outpu.ToString();
            char[] chart = kk.ToCharArray();
            if (chart.Length == arr.Length)
            {
                int[] outp = new int[k.Length];
                for (int j = 0; j < k.Length; j++)
                {
                    outp[j] = Convert.ToInt16(chart[j].ToString());
                }

                return outp;
            }
            else
            {
                int[] outp = new int[k.Length + 1];
                for (int j = 0; j < k.Length; j++)
                {
                    outp[j] = Convert.ToInt16(chart[j].ToString());
                }

                return outp;
            }


        }

        public int digits = 4;
        public int min = 1000;
        public int max = 9999;

        public void LogicalDecrement(int prev, int cur)
        {
            int maximum = Math.Max(min, prev);

            for (int i = 0; i < 9999; i++)
            {

                int cnt = 0;
                int a = i;
                int b = cur;
            }


            //int[] outputarr = new int[inputarr.Length];
            //int k = 0;
            //for (int i = inputarr.Length; i >= 0; i--)
            //{
            //    char[] j = i.ToString().ToCharArray();
            //    j[3] = Convert.ToChar(k);

            //}



            //  return outputarr;
        }

        public static void CamelCase(string camelCase)
        {
            int count = 0;
            char[] camelcaseletter = camelCase.ToCharArray();
            string eachword = "";
            for (int i = 0; i < camelcaseletter.Length; i++)
            {
                if (camelcaseletter[i] < 'a')
                {
                    count++;
                    Console.WriteLine(eachword);
                    eachword = "";
                }
                eachword = eachword + camelcaseletter[i];
            }
            Console.WriteLine(eachword);
            Console.WriteLine(count + 1);
            count = 0;
            eachword = "";
            for (int i = 0; i < camelcaseletter.Length; i++)
            {
                if ("ABCDEFGHIJKLMNOPQRSTUVWXYZ".Contains(camelcaseletter[i]))
                {
                    count++;
                    Console.WriteLine(eachword);
                    eachword = "";
                }
                eachword = eachword + camelcaseletter[i];
            }

            Console.WriteLine(eachword);
            Console.WriteLine(count + 1);






            int wordCount = 1;
            for (int i = 0; i < camelcaseletter.Length; ++i)
            {
                if (char.IsUpper(camelcaseletter[i]))
                {
                    ++wordCount;
                }
            }
            Console.Write(wordCount);



            string s = Console.ReadLine();
            int words = s.ToCharArray().Count(x => x == char.ToUpper(x));
            Console.WriteLine(words + 1);
        }

        public static void ValidatePassowrdCount(string password)
        {
            int n = password.Length;
            char[] passarray = password.ToCharArray();
            int num = 0; int lc = 0; int uc = 0; int sp = 0;
            int output = 0;
            string numbers = "0123456789";
            string lower_case = "abcdefghijklmnopqrstuvwxyz";
            string upper_case = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            string special_characters = "!@#$%^&*()-+";
            for (int i = 0; i < n; i++)
            {
                if (numbers.Contains(passarray[i]))
                    num = 1;

                if (lower_case.Contains(passarray[i]))
                    lc = 1;

                if (upper_case.Contains(passarray[i]))
                    uc = 1;

                if (special_characters.Contains(passarray[i]))
                    sp = 1;
            }
            int count = num + lc + uc + sp;
            count = 4 - count;
            if (password.Length > 6)
            {
                output = count;
            }
            else
            {
                if (count == 0)
                {
                    output = 6 - password.Length;
                }
                if (password.Length + count >= 6)
                {
                    output = count;
                }

                if (password.Length + count < 6)
                {
                    output = 6 - password.Length;
                }
            }

            Console.WriteLine(output);
        }

        public static void Pangram(string strpangram)
        {
            int A = 0;
            int B = 0;
            int C = 0;
            int D = 0;
            int E = 0;
            int F = 0;
            int G = 0;
            int H = 0;
            int I = 0;
            int J = 0;
            int K = 0;
            int L = 0;
            int M = 0;
            int N = 0;
            int O = 0;
            int P = 0;
            int Q = 0;
            int R = 0;
            int S = 0;
            int T = 0;
            int U = 0;
            int V = 0;
            int W = 0;
            int X = 0;
            int Y = 0;
            int Z = 0;
            string upper_case = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            char[] chrpanrgam = strpangram.ToCharArray();
            for (int i = 0; i <= chrpanrgam.Length - 1; i++)
            {
                if (Convert.ToChar(chrpanrgam[i].ToString().ToUpper()) == 'A')
                {
                    A = 1;
                }
                if (Convert.ToChar(chrpanrgam[i].ToString().ToUpper()) == 'B')
                {
                    B = 1;
                }
                if (Convert.ToChar(chrpanrgam[i].ToString().ToUpper()) == 'C')
                {
                    C = 1;
                }
                if (Convert.ToChar(chrpanrgam[i].ToString().ToUpper()) == 'D')
                {
                    D = 1;
                }
                if (Convert.ToChar(chrpanrgam[i].ToString().ToUpper()) == 'E')
                {
                    E = 1;
                }
                if (Convert.ToChar(chrpanrgam[i].ToString().ToUpper()) == 'F')
                {
                    F = 1;
                }
                if (Convert.ToChar(chrpanrgam[i].ToString().ToUpper()) == 'G')
                {
                    G = 1;
                }
                if (Convert.ToChar(chrpanrgam[i].ToString().ToUpper()) == 'H')
                {
                    H = 1;
                }
                if (Convert.ToChar(chrpanrgam[i].ToString().ToUpper()) == 'I')
                {
                    I = 1;
                }
                if (Convert.ToChar(chrpanrgam[i].ToString().ToUpper()) == 'J')
                {
                    J = 1;
                }
                if (Convert.ToChar(chrpanrgam[i].ToString().ToUpper()) == 'K')
                {
                    K = 1;
                }
                if (Convert.ToChar(chrpanrgam[i].ToString().ToUpper()) == 'L')
                {
                    L = 1;
                }
                if (Convert.ToChar(chrpanrgam[i].ToString().ToUpper()) == 'M')
                {
                    M = 1;
                }
                if (Convert.ToChar(chrpanrgam[i].ToString().ToUpper()) == 'N')
                {
                    N = 1;
                }
                if (Convert.ToChar(chrpanrgam[i].ToString().ToUpper()) == 'O')
                {
                    O = 1;
                }
                if (Convert.ToChar(chrpanrgam[i].ToString().ToUpper()) == 'P')
                {
                    P = 1;
                }
                if (Convert.ToChar(chrpanrgam[i].ToString().ToUpper()) == 'Q')
                {
                    Q = 1;
                }
                if (Convert.ToChar(chrpanrgam[i].ToString().ToUpper()) == 'R')
                {
                    R = 1;
                }
                if (Convert.ToChar(chrpanrgam[i].ToString().ToUpper()) == 'S')
                {
                    S = 1;
                }
                if (Convert.ToChar(chrpanrgam[i].ToString().ToUpper()) == 'T')
                {
                    T = 1;
                }
                if (Convert.ToChar(chrpanrgam[i].ToString().ToUpper()) == 'U')
                {
                    U = 1;
                }
                if (Convert.ToChar(chrpanrgam[i].ToString().ToUpper()) == 'V')
                {
                    V = 1;
                }
                if (Convert.ToChar(chrpanrgam[i].ToString().ToUpper()) == 'W')
                {
                    W = 1;
                }
                if (Convert.ToChar(chrpanrgam[i].ToString().ToUpper()) == 'X')
                {
                    X = 1;
                }
                if (Convert.ToChar(chrpanrgam[i].ToString().ToUpper()) == 'Y')
                {
                    Y = 1;
                }
                if (Convert.ToChar(chrpanrgam[i].ToString().ToUpper()) == 'Z')
                {
                    Z = 1;
                }

            }

            int count = A + B + C + D + E + F + G + H + I + J + K + L + M + N + O + P + Q + R + S + T + U + V + W + X + Y + Z;
            if (count == 26)
            {
                Console.WriteLine("p");
            }
            else
            {
                Console.WriteLine("NP");
            }
        }

        public static void AlphabetIncrement(string stralpha, int k)
        {
            char[] charalpha = "abcdefghijklmnopqrstuvwxyz".ToCharArray();
            char[] changalpha = new char[26];
            char[] charinput = stralpha.ToCharArray();
            string ouput = "";

            for (int i = 0; i < charalpha.Length; i++)
            {
                if (i + k < 26)
                {
                    changalpha[i] = charalpha[i + k];
                }
            }
            int l = 0;
            for (int j = k; j > 0; j--)
            {
                changalpha[26 - j] = charalpha[l];
                l++;
            }

            for (int i = 0; i < charinput.Length; i++)
            {
                if ((charinput[i] >= 97 && charinput[i] <= 122) || (charinput[i] >= 65 && charinput[i] <= 90))
                {
                    if ((charinput[i] >= 97 && charinput[i] <= 122))
                    {
                        int index = Array.IndexOf(charalpha, charinput[i]);
                        ouput = ouput + changalpha[index];
                    }

                    if ((charinput[i] >= 65 && charinput[i] <= 90))
                    {
                        char Captalltr = Convert.ToChar(charinput[i].ToString().ToLower());
                        int index = Array.IndexOf(charalpha, Captalltr);
                        ouput = ouput + changalpha[index].ToString().ToUpper();
                    }
                }
                else
                {
                    ouput = ouput + charinput[i];
                }
            }
            Console.WriteLine(ouput);
        }

        public static void AltAlphabet()
        {
            string s = Console.ReadLine();
            int ans = 0;
            for (int i = 0; i < 26; i++)
            {
                for (int j = 0; j < 26; j++)
                {
                    if (i == j)
                        continue;
                    int p1 = i;
                    int p2 = j;
                    int flag = 1;
                    int l = 0;
                    foreach (char c in s)
                    {
                        if (((c - 'a') != p1) && ((c - 'a') != p2))
                            continue;
                        if ((c - 'a') == p1)
                        {
                            l = l + 1;
                            int m = p1;
                            p1 = p2;
                            p2 = m;
                        }
                        else
                            flag = 0;
                    }

                    if ((flag == 1) && (l > 1))
                    {
                        ans = Math.Max(ans, 1);
                    }

                }
            }

            Console.WriteLine(ans);
            Console.ReadLine();
        }

        public static int alternating(string line, char p1, char p2)
        {
            bool first = true;
            int r = 0;
            foreach (var c in line.Where(x => x == p1 || x == p2))
            {
                if (first)
                {
                    if (c == p2) return -1;
                    r++;
                }
                else
                {
                    if (c == p1) return -1;
                    r++;
                }
                first = !first;
            }
            return r;
        }

        public static int TwoCharacter(string strinput)
        {
            int altint = 0;
            for (int i = 'a'; i < 'z'; i++)
            {
                for (int j = 'a'; j < 'z'; j++)
                {
                    if (i == j)
                    {
                    }
                    else
                    {
                        char p1 = (char)i;
                        char p2 = (char)j;
                        altint = Math.Max(altint, alt(strinput, p1, p2));
                    }
                }
            }
            return altint;
        }

        public static int alt(string strinput, char p1, char p2)
        {
            int r = 0;
            bool flag = true;
            foreach (char c in strinput.Where(x => x == p1 || x == p2))
            {

                if (flag)
                {
                    if (c == p1)
                    {
                        r++;
                    }
                    else
                    {
                        return 0;
                    }
                }
                else
                {
                    if (c == p2)
                    {
                        r++;
                    }
                    else
                    {
                        return 0;
                    }
                }
                flag = !flag;

            }

            return r;

        }

        public static int TwoCharAlt()
        {

            int maxr = 0;
            string s = "";
            for (char i = 'a'; i <= 'z'; ++i)
            {
                for (char j = i; j <= 'z'; ++j)
                {
                    int r = 0;
                    char last = '0';
                    if (i != j)
                    {
                        foreach (char c in s)
                        {
                            if ((c == i) || (c == j))
                            {
                                if (c != last)
                                {
                                    r++;
                                    last = c;
                                }
                                else
                                {
                                    r = 0;
                                    break;
                                }
                            }
                        }
                    }
                    maxr = Math.Max(maxr, r);
                }
            }
            maxr = maxr == 1 ? 0 : maxr;
            Console.WriteLine(maxr);



            string line = "abaacdabd";
            int n = 9;

            if (n == 1) { Console.WriteLine(0); return 0; }
            int ans = 0;
            for (int i = 0; i < 26; i++)
            {
                for (int j = 0; j < 26; j++)
                {
                    if (i == j) continue;
                    ans = Math.Max(ans, alternating(line, (char)('a' + i), (char)('a' + j)));
                }
            }
            return ans;
            //  Console.WriteLine(ans);
        }

        public static string[] WeightedUniformString(string inputstring, int[] queries)
        {
            string[] outputlsit = new string[queries.Length];
            string s = inputstring;
            /*StringBuilder sb = new StringBuilder();
            for (int i = 0; i < 100000; i++){
                sb.Append('a');
            }
            string s = sb.ToString();*/
            //Console.WriteLine(s);
            HashSet<int> hash = new HashSet<int>();
            //List<string> list = new List<string>();
            //string a = s[0].ToString();
            //list.Add(a);
            int value = s[0] - 'a' + 1;
            hash.Add(value);
            for (int i = 1; i < s.Length; i++)
            {
                if (s[i] == s[i - 1])
                    value += s[i] - 'a' + 1;
                else
                {
                    value = s[i] - 'a' + 1;
                }
                hash.Add(value);
            }
            //Console.WriteLine(String.Join(" ",list));
            /*for (int i = 0; i < list.Count; i++){
                int c = list[i].Length;
                hash.Add((list[i][0] - 'a' + 1) * c);
            }*/
            //Console.WriteLine(String.Join(" ",hash));
            int n = queries.Length;
            for (int a0 = 0; a0 < n; a0++)
            {
                int x = Convert.ToInt32(queries[a0]);
                if (hash.Contains(x))
                    outputlsit[a0] = "Yes";
                else
                    outputlsit[a0] = "No";
            }




















            //  string[] outputlsit = new string[queries.Length];
            char? prevchar = null;
            int prevint = 0;
            HashSet<int> lstprocess = new HashSet<int>();
            int charval = 0;
            foreach (char c in inputstring)
            {

                if (prevchar == c)
                {
                    charval = charval + c - 'a' + 1;
                }
                else
                {
                    charval = c - 'a' + 1;
                }

                lstprocess.Add(charval);
                prevint = charval;
                prevchar = c;
            }
            for (int i = 0; i < queries.Length; i++)
            {

                bool results = lstprocess.Contains(queries[i]);

                if (results)
                {
                    outputlsit[i] = "Yes";
                }
                else
                {
                    outputlsit[i] = "No";
                }

            }

            return outputlsit;

        }

        public static int BearGene(string beargene)
        {
            int n = beargene.Length;
            int min = beargene.Length;

            int A = 0;
            int C = 0;
            int G = 0;
            int T = 0;
            for (int i = 0; i < n; i++)
            {
                switch (beargene[i])
                {
                    case 'A': A++; break;
                    case 'G': G++; break;
                    case 'T': T++; break;
                    case 'C': C++; break;
                }
            }
            A = A - n / 4; C = C - n / 4; G = G - n / 4; T = T - n / 4;
            int best = Math.Max(0, A) + Math.Max(0, C) + Math.Max(0, G) + Math.Max(0, T);

            if ((A == 0) && (C == 0) && (G == 0) && (T == 0))
            {
                return 0;
            }

            else if ((A + C + G + T) == 1)
            {
                return 1;
            }
            else
            {
                switch (beargene[0])
                {
                    case 'A': A--; break;
                    case 'G': G--; break;
                    case 'T': T--; break;
                    case 'C': C--; break;
                }

                int start = 0;
                int end = 0;
                while ((min != best) && (start < n) && (end < n))
                {
                    if ((A <= 0) && (C <= 0) && (G <= 0) && (T < 0))
                    {
                        if (end - start + 1 < min)
                            min = end - start + 1;

                        switch (beargene[start])
                        {
                            case 'A': A++; break;
                            case 'G': G++; break;
                            case 'T': T++; break;
                            case 'C': C++; break;
                        }
                        start++;
                    }
                    else
                    {
                        end++;
                        if (end < n)
                            switch (beargene[end])
                            {
                                case 'A': A--; break;
                                case 'G': G--; break;
                                case 'T': T--; break;
                                case 'C': C--; break;
                            }
                    }
                }
            }

            return min;

        }

        static int output = 1;
        public static int Factorial(int x)
        {

            if (x == 1)
                return output;


            output = output * x;
            Factorial(x - 1);

            return output;
        }
    }
}
