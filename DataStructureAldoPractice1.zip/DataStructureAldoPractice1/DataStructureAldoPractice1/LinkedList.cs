﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataStructureAldoPractice1
{
    public class SinglyLinkedList
    {

        public SingleLinkedList CreateListedList()
        {
            SingleLinkedList slnlst = new SingleLinkedList();
            slnlst.head = new Node(0);

            Node first = new Node(1);
            Node second = new Node(2);
            Node third = new Node(3);

            slnlst.head.Next = first;
            first.Next = second;
            second.Next = third;

            Node n = slnlst.head;
            while (n != null)
            {
                Console.WriteLine(n.data);
                n = n.Next;
            }
            return slnlst;
        }

        public Node CreateListedListFormergesort()
        {
            Node zeroth = new Node(15);
            Node first = new Node(10);
            Node second = new Node(5);
            Node third = new Node(20);
            Node fourth = new Node(3);
            Node fivth = new Node(2);

            zeroth.Next = first;
            first.Next = second;
            second.Next = third;
            third.Next = fourth;
            fourth.Next = fivth;

            Node n = zeroth;
            while (n != null)
            {
                Console.WriteLine(n.data);
                n = n.Next;
            }
            return zeroth;
        }
        public SingleLinkedList InserFront(SingleLinkedList slst, int newnode)
        {
            Node n = new Node(newnode);
            n.Next = slst.head;
            slst.head = n;

            Node n1 = slst.head;
            while (n1 != null)
            {
                Console.WriteLine(n1.data);
                n1 = n1.Next;
            }

            return slst;
        }
        public void InsertAfter(Node prevnode, int newnode)
        {
            Node newn = new Node(newnode);
            newn.Next = prevnode.Next;
            prevnode.Next = newn;
        }
        public SingleLinkedList InsertLast(SingleLinkedList slst, int newnode)
        {
            Node temp = slst.head;
            Node nwnd = new Node(newnode);
            if (slst.head == null)
            {
                slst.head = nwnd;
                return slst;
            }

            while (temp.Next != null)
            {
                temp = temp.Next;
            }

            temp.Next = nwnd;

            Node n = slst.head;
            while (n != null)
            {
                Console.WriteLine(n.data);
                n = n.Next;
            }

            return slst;
        }

        public void DeleteNodebyKeys(SingleLinkedList slst, int key)
        {
            Node temp = slst.head;
            Node prev = null;


            if (temp != null && temp.data == key)
            {
                slst.head = temp.Next;
                return;
            }

            while (temp != null && temp.data != key)
            {
                prev = temp;
                temp = temp.Next;
            }
            prev.Next = temp.Next;
            return;
        }

        public void DeleteByPosition(SingleLinkedList slst, int position)
        {
            Node temp = slst.head;
            if (position == 0)
            {
                slst.head = temp.Next;
            }


            for (int i = 0; temp != null && i < position - 1; i++)
            {
                temp = temp.Next;
            }

            if (temp == null && temp.Next == null)
            {
                return;
            }

            Node nodenext = temp.Next.Next;
            temp.Next = nodenext;
        }

        public void Search(SingleLinkedList slst, int k)
        {
            Node temp = slst.head;
            while (temp != null)
            {
                if (temp.data == k)
                {
                    Console.WriteLine("Data Found");
                    return;
                }
                temp = temp.Next;
            }

            Console.WriteLine("Data Not Found");

        }

        public void FindMid(SingleLinkedList slst)
        {
            Node slowptr = slst.head;
            Node fastptr = slst.head;
            if (slst.head != null)
            {
                while (fastptr != null && fastptr.Next != null)
                {
                    slowptr = slowptr.Next;
                    fastptr = fastptr.Next.Next;
                }
                Console.WriteLine("Mid data is " + slowptr.data);
            }
        }

        public Node FindMiddle(Node h)
        {
            // Base case 
            if (h == null)
                return h;
            Node fastptr = h.Next;
            Node slowptr = h;

            // Move fastptr by two and slow ptr by one 
            // Finally slowptr will point to middle node 
            while (fastptr != null)
            {
                fastptr = fastptr.Next;
                if (fastptr != null)
                {
                    slowptr = slowptr.Next;
                    fastptr = fastptr.Next;
                }
            }
            return slowptr;
        }

        public void ReverseLinkedList(SingleLinkedList slst)
        {
            Console.WriteLine("Before Reversing");
            Node temp = slst.head;

            while (temp != null)
            {

                Console.Write(" " + temp.data);
                temp = temp.Next;
            }

            Node temp1 = null;
            Node current = slst.head;
            Node prev = null;
            Console.WriteLine("");
            while (current != null)
            {
                temp1 = current.Next;
                current.Next = prev;
                prev = current;
                current = temp1;
            }

            slst.head = prev;


            Console.WriteLine("After Reversing");
            Node temp2 = slst.head;
            while (temp2 != null)
            {
                Console.Write(" " + temp2.data);
                temp2 = temp2.Next;
            }
        }

        public Node SortedMege(Node a, Node b)
        {
            Node result = null;
            if (a == null)
                return b;
            if (b == null)
                return a;

            if (a.data <= b.data)
            {
                result = a;
                result.Next = SortedMege(a.Next, b);
            }
            else
            {
                result = b;
                result.Next = SortedMege(a, b.Next);
            }

            return result;
        }

        public Node MergeSort(Node head)
        {
            if (head == null || head.Next == null)
            {
                return head;
            }

            Node mid = FindMiddle(head);
            Node nextofmiddle = mid.Next;
            mid.Next = null;

            Node left = MergeSort(head);
            Node right = MergeSort(nextofmiddle);
            Node srtedll = SortedMege(left, right);
            return srtedll;
        }
    }
    public class SingleLinkedList
    {
        internal Node head;
    }
    public class Node
    {
        internal Node Next;
        internal int data;
        public Node(int d)
        {
            data = d;
            Next = null;
        }
    }

    internal class DoubleLinkedList
    {
        internal DNode head;
    }

    internal class DNode
    {
        internal int data;
        internal DNode next;
        internal DNode prev;
        internal DNode(int d)
        {
            data = d;
            next = null;
            prev = null;
        }
    }

    internal class DLinkedList
    {

        public DoubleLinkedList CreateDoubleList()
        {
            DoubleLinkedList doubleLinkedList = new DoubleLinkedList();

            DNode node0 = new DNode(0);
            DNode node1 = new DNode(1);
            DNode node3 = new DNode(3);

            node3.prev = node1;
            node3.next = null;

            node1.prev = node0;
            node1.next = node3;


            node0.prev = null;
            node0.next = node1;

            doubleLinkedList.head = node0;

            InsertAfter(node1, 2);
            // InsertBefore(node3, 78);

            return doubleLinkedList;
        }
        #region Insert_into_DoubleLinkedList
        public DoubleLinkedList InsertFront(DoubleLinkedList doubleLinkedList, int data)
        {
            DNode newnode = new DNode(data);
            newnode.next = doubleLinkedList.head;
            newnode.prev = null;

            if (doubleLinkedList.head != null)
            {
                doubleLinkedList.head.prev = newnode;
            }

            doubleLinkedList.head = newnode;

            return doubleLinkedList;
        }

        internal void InsertAfter(DNode prev_node, int data)
        {
            DNode newnode = new DNode(data);
            newnode.next = prev_node.next;
            newnode.prev = prev_node;

            prev_node.next = newnode;

            if (newnode.next != null)
            {
                newnode.next.prev = newnode;
            }

        }

        internal void InsertBefore(DNode next_node, int data)
        {
            DNode newnode = new DNode(data);
            newnode.next = next_node;
            newnode.prev = next_node.prev;

            next_node.prev = newnode;

            if (newnode.prev != null)
            {
                newnode.prev.next = newnode;
            }


        }

        internal void InsertLast(DoubleLinkedList doubleLinkedList, int data)
        {
            DNode temp = doubleLinkedList.head;
            DNode lastnode = null;

            while (temp != null)
            {
                lastnode = temp;
                temp = temp.next;
            }

            DNode newnode = new DNode(data);
            if (doubleLinkedList.head == null)
            {
                newnode.prev = null;
                doubleLinkedList.head = newnode;
                return;
            }

            newnode.next = null;
            newnode.prev = lastnode;

            lastnode.next = newnode;
        }

        #endregion Insert_into_DoubleLinkedList


        internal void DeleteNodebyKey(DoubleLinkedList doubleLinkedList, int key)
        {
            DNode temp = doubleLinkedList.head;

            if (temp != null && temp.data == key)
            {
                doubleLinkedList.head = temp.next;
                doubleLinkedList.head.prev = null;
                return;
            }

            while (temp != null && temp.data != key)
            {
                temp = temp.next;
            }

            if (temp == null)
            {
                return;
            }

            if (temp.next != null)
            {
                temp.next.prev = temp.prev;
            }

            if (temp.prev != null)
            {
                temp.prev.next = temp.next;
            }

        }
        internal void ReverseLinkedList(DoubleLinkedList doubleLinkedList)
        {
            DNode temp = null;
            DNode current = doubleLinkedList.head;

            /* swap next and prev for all nodes of doubly linked list */
            while (current != null)
            {
                temp = current.prev;
                current.prev = current.next;
                current.next = temp;
                current = current.prev;
            }
            if (temp != null)
            {
                doubleLinkedList.head = temp.prev;
            }
        }

    }

    public class SingleCircularList
    {
        int data;
        public SingleCircularList next;
        public SingleCircularList(int value)
        {
            data = value;
            next = this;
        }

        public SingleCircularList InsertData(int instdata)
        {
            SingleCircularList node1 = new SingleCircularList(instdata);
            if (this.next == this)
            {
                node1.next = this;
                this.next = node1;
            }
            else
            {
                SingleCircularList temp = this.next;
                node1.next = this;
                this.next = node1;
            }
            return node1;
        }
    }


    public class SinglyCircularLL
    {
        public class Node
        {
            internal int data;
            internal Node Next;
        }

        public Node InsertEmpty(Node lastnode, int data)
        {
            if (lastnode != null)
            {
                return lastnode;
            }

            Node node = new Node();
            node.data = data;

            lastnode = node;
            lastnode.Next = lastnode;

            return lastnode;
        }
        public Node addEnd(Node lastnode, int data)
        {
            if (lastnode == null)
            {
                return InsertEmpty(lastnode, data);
            }

            Node node = new Node();
            node.data = data;
            node.Next = lastnode.Next;
            lastnode.Next = node;
            lastnode = node;

            return lastnode;
        }
        public Node beginNode(Node lastnode, int data)
        {
            if (lastnode == null)
            {
                return InsertEmpty(lastnode, data);
            }

            Node node = new Node();
            node.data = data;
            node.Next = lastnode.Next;
            lastnode.Next = node;
            return lastnode;
        }
        public Node InsertAfter(Node lastnode, int data, int item)
        {
            Node temp, p;
            p = lastnode.Next;

            do
            {
                if (p.data == item)
                {
                    Node node = new Node();
                    node.data = data;
                    node.Next = p.Next;
                    p.Next = node;

                    if (p == lastnode)
                        lastnode = node;

                    return lastnode;
                }
                p = p.Next;
            }
            while (p != lastnode.Next);

            return lastnode;
        }
        public void Traverse(Node lastnode)
        {
            Node p = lastnode.Next;
            do
            {
                Console.Write(p.data + " ");
                p = p.Next;
            }
            while (p != lastnode.Next);
        }


        public Node remove(int i, Node head)
        {
            Node p = head;
            do
            {
                if (p.Next.data == i)
                {
                    Node n = p.Next;
                    p.Next = n.Next;
                    if (n == head)
                    { // removal of head
                        head = p;
                    }
                    return n.Next;
                }
                p = p.Next;
            } while (p != head);
            return null;
        }
    }
    // End Singly Circular Linked List


    // Begin Double Circular List
    public class DoubleCircularLL
    {
        public class Node
        {
            public int data;
            public Node Next;
            public Node Prev;
        }

        public Node start;

        public Node InsertEnd(Node head, int data)
        {
            if (head == null)
            {
                Node node = new Node();
                node.data = data;

                node.Next = node;
                node.Prev = node;

                head = node;

                return head;
            }

            Node last = head.Prev;

            Node node1 = new Node();
            node1.data = data;

            node1.Next = head;
            node1.Prev = last;

            last.Next = node1;
            head.Prev = node1;
            return head;

        }


        public Node InsertBegin(Node head, int data)
        {
            Node lastnode = head.Prev;
            Node node = new Node();
            node.data = data;
            node.Prev = lastnode;
            node.Next = head;

            lastnode.Next = node;
            head.Prev = node;
            return node;
        }

        public Node InsertAfter(int value1, int value2, Node node)
        {
            Node newnode = new Node();
            newnode.data = value1;

            Node temp = node;
            while (temp.data != value2)
            {
                temp = temp.Next;
            }



            newnode.Prev = temp;
            newnode.Next = temp.Next;
            temp.Next.Prev = newnode;
            temp.Next = newnode;


            return node;
        }

        public void Travers(Node head)
        {
            Console.WriteLine(" Forward Direction");
            Node temp = head;
            while (temp.Next != head)
            {
                Console.Write(temp.data + " ");
                temp = temp.Next;
            }
            Console.Write(temp.data + " ");

            Console.WriteLine(" Back Direction");

            Node last = head.Prev;
            Node temp1 = last;
            while (temp1.Prev != last)
            {
                Console.Write(temp1.data + " ");
                temp1 = temp1.Prev;
            }
            Console.Write(temp1.data + " ");
        }

        public Node deleteNode(Node start, int key)
        {
            if (start == null)
            {
                return null;
            }

            Node curr = start, Prev = null;
            while (curr.data != key)
            {
                if (curr.Next == start)
                {
                    Console.WriteLine("No Data Found");
                    return start;
                }
                Prev = curr;
                curr = curr.Next;
            }

            if (curr.Next == start && Prev == null)
            {
                start = null;
                return start;
            }

            if (curr == start)
            {
                Node last = start.Prev;
                start = start.Next;
                last.Next = start;
                start.Prev = last;

            }
            else if (curr.Next == start)
            {
                Prev.Next = start;
                start.Prev = Prev;
            }
            else
            {

                Node nxt = curr.Next;
                Prev.Next = nxt;
                nxt.Prev = Prev;
            }
            return start;
        }


    }
}
