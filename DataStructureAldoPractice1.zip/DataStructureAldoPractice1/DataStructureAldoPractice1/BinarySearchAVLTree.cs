﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataStructureAldoPractice1
{
    public class BinarySearch
    {

        public class TreeNode
        {
            public int data { get; set; }
            public TreeNode leftnode;
            public TreeNode rightnode;
            public TreeNode(int da)
            {
                data = da;
                leftnode = null;
                rightnode = null;
            }
        }

        Dictionary<int, int> hm = new Dictionary<int, int>();
        int preindex = 0;

        public TreeNode buidTree(int[] preorder, int[] inorder)
        {
            for (int i = 0; i < inorder.Length - 1; i++)
                hm.Add(inorder[i], i);

            return build(preorder, inorder, 0, inorder.Length - 1);
        }

        public TreeNode build(int[] preorder, int[] inorder, int start, int end)
        {
            if (start > end)
                return null;

            TreeNode root = new TreeNode(preorder[preindex++]);
            if (root == null)
                return null;

            if (start == end)
                return root;
            int index = hm[root.data];
            root.leftnode = build(preorder, inorder, start, index - 1);
            root.rightnode = build(preorder, inorder, index + 1, end);
            return root;

        }



        public TreeNode buidTreePo(int[] postorder, int[] inorder)
        {
            for (int i = 0; i < inorder.Length; i++)
                hm.Add(inorder[i], i);
            preindex = inorder.Length;
            return buildPo(postorder, inorder, 0, inorder.Length - 1, inorder.Length - 1);
        }

        public TreeNode buildPo(int[] postorder, int[] inorder, int start, int end, int index)
        {
            if (start > end)
                return null;
            TreeNode root = new TreeNode(postorder[index]);
            if (root == null)
                return null;

            if (start == end)
                return root;
            int inRootIndex = hm[postorder[index]];
            root.rightnode = buildPo(postorder, inorder, inRootIndex + 1, end, index - 1);
            root.leftnode = buildPo(postorder, inorder, start, inRootIndex - 1, index - (end - inRootIndex) - 1);
            return root;

        }

        //public TreeNode buildTree(int[] inorder, int[] postorder)
        //{
        //    if (inorder.Length == 0 || postorder.Length == 0) return null;

        //    return this.buildTreeRecursion(inorder, 0, inorder.Length - 1, postorder, 0, postorder.Length - 1);
        //}

        //private TreeNode buildTreeRecursion(
        //    int[] inorder,
        //    int inorderlow,
        //    int inorderhigh,
        //    int[] postorder,
        //    int postorderlow,
        //    int postorderhigh)
        //{
        //    if (inorderlow > inorderhigh || postorderlow > postorderhigh)
        //    {
        //        return null;
        //    }

        //    var rootValue = postorder[postorderhigh];
        //    var root = new TreeNode(rootValue);
        //    var inorderIndex = Array.IndexOf(inorder, postorder[postorderhigh], inorderlow, inorderhigh - inorderlow + 1);

        //    root.leftnode = this.buildTreeRecursion(
        //        inorder,
        //        inorderlow,
        //        inorderIndex - 1,
        //        postorder,
        //        postorderlow,
        //        postorderlow + (inorderIndex - inorderlow - 1));

        //    root.rightnode = this.buildTreeRecursion(
        //        inorder,
        //        inorderIndex + 1,
        //        inorderhigh,
        //        postorder,
        //        postorderlow + (inorderIndex - inorderlow - 1) + 1,
        //        postorderhigh - 1);

        //    return root;
        //}

        //public TreeNode buildTree(int[] inorder, int[] postorder)
        //{
        //    if (inorder.Length == 0 || postorder.Length == 0) return null;

        //    return this.buildTreeRecursion(inorder, 0, inorder.Length - 1, postorder, 0, postorder.Length - 1);
        //}

        //private TreeNode buildTreeRecursion(
        //    int[] inorder,
        //    int inorderlow,
        //    int inorderhigh,
        //    int[] postorder,
        //    int postorderlow,
        //    int postorderhigh)
        //{
        //    if (inorderlow > inorderhigh || postorderlow > postorderhigh)
        //    {
        //        return null;
        //    }

        //    var rootValue = postorder[postorderhigh];
        //    var root = new TreeNode(rootValue);

        //    var inorderIndex = Array.IndexOf(inorder, postorder[postorderhigh], inorderlow, inorderhigh - inorderlow + 1);

        //    root.leftnode = this.buildTreeRecursion(
        //        inorder,
        //        inorderlow,
        //        inorderIndex - 1,
        //        postorder,
        //        postorderlow,
        //        postorderlow + (inorderIndex - inorderlow - 1));

        //    root.rightnode = this.buildTreeRecursion(
        //        inorder,
        //        inorderIndex + 1,
        //        inorderhigh,
        //        postorder,
        //        postorderlow + (inorderIndex - inorderlow - 1) + 1,
        //        postorderhigh - 1);

        //    return root;
        //}

        //  pu


        public void postorderTraversal(TreeNode node)
        {
            if (node != null)
            {
                postorderTraversal(node.leftnode);
                postorderTraversal(node.rightnode);
                Console.Write(node.data + " ");
            }
        }

        public void InorderTraversal(TreeNode node)
        {
            if (node != null)
            {
                InorderTraversal(node.leftnode);
                Console.Write(node.data + " ");
                InorderTraversal(node.rightnode);
            }
        }

        public void CreateBinaryTree(int[] arr)
        {
            TreeNode root = null;
            for (int i = 0; i < arr.Length; i++)
            {
                root = InsertBinaryTree(arr[i], root);
            }
            InorderTraversal(root);
            root = DeleteBinaryTree(20, root);
            Console.WriteLine();
            InorderTraversal(root);
        }

        public TreeNode InsertBinaryTree(int data, TreeNode root)
        {
            if (root == null)
                return new TreeNode(data);
            if (root.data > data)
            {
                root.leftnode = InsertBinaryTree(data, root.leftnode);
            }
            else
            {
                root.rightnode = InsertBinaryTree(data, root.rightnode);
            }
            return root;

        }

        public TreeNode DeleteBinaryTree(int data, TreeNode root)
        {
            if (root == null)
                return root;
            if (root.data > data)
            {
                root.leftnode = DeleteBinaryTree(data, root.leftnode);
            }
            else if (root.data < data)
            {
                root.rightnode = DeleteBinaryTree(data, root.rightnode);
            }
            else
            {
                if (root.leftnode == null)
                    return root.rightnode;
                else if (root.rightnode == null)
                    return root.leftnode;

                //root.data = InoderSuccessor(root.rightnode);
                //root.rightnode = DeleteBinaryTree(root.data, root.rightnode);
                root.data = InoderPredessor(root.leftnode);
                root.leftnode = DeleteBinaryTree(root.data, root.leftnode);
            }
            return root;
        }

        public int InoderSuccessor(TreeNode root)
        {
            int i = root.data;

            while (root.leftnode != null)
            {
                i = root.leftnode.data;
                root = root.leftnode;
            }
            return i;

        }

        public int InoderPredessor(TreeNode root)
        {
            int i = root.data;

            while (root.rightnode != null)
            {
                i = root.rightnode.data;
                root = root.rightnode;
            }
            return i;

        }
    }

    public class AVLNode
    {
        public int data { get; set; }
        public int height { get; set; }

        public AVLNode right, left;
        public AVLNode(int d)
        {
            data = d;
            height = 1;
            right = left = null;
        }

    }

    public class AVLTree
    {
        public AVLNode root = null;
        public int max(int a, int b)
        {
            return (a > b) ? a : b;

        }

        public int Height(AVLNode node)
        {
            if (node == null)
                return 0;

            return node.height
;
        }

        public int GetBalance(AVLNode node)
        {
            if (node == null)
                return 0;
            return Height(node.left) - Height(node.right);

        }

        public AVLNode RotateLeft(AVLNode x)
        {
            AVLNode y = x.right;
            AVLNode T2 = y.left;

            y.left = x;
            x.right = T2;

            x.height = 1 + (max(Height(x.left), Height(x.right)));
            y.height = 1 + (max(Height(y.left), Height(y.right)));

            return y;
        }

        public AVLNode RotateRight(AVLNode y)
        {
            AVLNode x = y.left;
            AVLNode T2 = x.right;

            x.right = y;
            y.left = T2;

            y.height = 1 + (max(Height(y.left), Height(y.right)));
            x.height = 1 + (max(Height(x.left), Height(x.right)));


            return x;
        }

        public AVLNode Insert(AVLNode root, int data)
        {
            if (root == null)
                return new AVLNode(data);
            if (data < root.data)
                root.left = Insert(root.left, data);
            else if (data > root.data)
                root.right = Insert(root.right, data);
            else
                return root;
            root.height = 1 + max(Height(root.left), Height(root.right));
            int balance = GetBalance(root);

            if (balance > 1 && data < root.left.data)
            {
                return RotateRight(root);
            }

            if (balance < -1 && data > root.right.data)
            {
                return RotateLeft(root);
            }


            if (balance > 1 && data > root.left.data)
            {
                root.left = RotateLeft(root.left);
                return RotateRight(root);
            }

            if (balance < -1 && data < root.right.data)
            {
                root.right = RotateRight(root.right);
                return RotateLeft(root);
            }
            return root;
        }
    }

    public class SegmentTree
    {



        public int ConstructSegmentTree(int[] st, int si, int[] arr, int l, int r)
        {
            if (l == r)
            {
                st[si] = arr[r];
                return st[si];
            }

            int mid = l + (r - l) / 2;

            st[si] = ConstructSegmentTree(st, si * 2 + 1, arr, l, mid) +
                 ConstructSegmentTree(st, si * 2 + 2, arr, mid + 1, r);

            return st[si];
        }


        public int GetSumST(int[] st, int si, int sl, int sr, int l, int r)
        {
            if (sl >= l && sr <= r)
            {
                return st[si];
            }

            if (sl > r || sr < l)
                return 0;

            int mid = sl + (sr - sl) / 2;

            return GetSumST(st, 2 * si + 1, sl, mid, l, r) + GetSumST(st, 2 * si + 2, mid + 1, sr, l, r);

        }


        public void UpdateST(int[] st, int si, int sl, int sr, int pos, int diff)
        {

            if (pos < sl || pos > sr)
                return;

            st[si] = st[si] + diff;

            if (sl != sr)
            {
                int mid = sl + (sr + sl) / 2;
                UpdateST(st, 2 * si + 1, sl, mid, pos, diff);
                UpdateST(st, 2 * si + 2, mid + 1, sr, pos, diff);

            }

        }
        //     int[] st;


        //public     SegmentTree(int[] arr, int n)
        //     {
        //         int x = (int)(Math.Ceiling(Math.Log(n) / Math.Log(2)));
        //         int max_size = 2 * (int)Math.Pow(2, x) - 1;
        //         st = new int[max_size];
        //         constructSTUtil(arr, 0, n - 1, 0);
        //     }

        //     int getMid(int s, int e)
        //     {
        //         return s + (e - s) / 2;
        //     }

        //     int getSumUtil(int ss, int se, int qs, int qe, int si)
        //     {
        //         if (qs <= ss && qe >= se)
        //             return st[si];

        //         if (se < qs || ss > qe)
        //             return 0;

        //         int mid = getMid(ss, se);
        //         return getSumUtil(ss, mid, qs, qe, 2 * si + 1) +
        //                 getSumUtil(mid + 1, se, qs, qe, 2 * si + 2);
        //     }

        //     void updateValueUtil(int ss, int se, int i,
        //                                 int diff, int si)
        //     {
        //         if (i < ss || i > se)
        //             return;

        //         st[si] = st[si] + diff;
        //         if (se != ss)
        //         {
        //             int mid = getMid(ss, se);
        //             updateValueUtil(ss, mid, i, diff, 2 * si + 1);
        //             updateValueUtil(mid + 1, se, i, diff, 2 * si + 2);
        //         }
        //     }

        //     void updateValue(int[] arr, int n, int i, int new_val)
        //     {
        //         if (i < 0 || i > n - 1)
        //         {
        //             Console.WriteLine("Invalid Input");
        //             return;
        //         }

        //         int diff = new_val - arr[i];

        //         arr[i] = new_val;

        //         // Update the values of nodes in segment tree 
        //         updateValueUtil(0, n - 1, i, diff, 0);
        //     }

        //     int getSum(int n, int qs, int qe)
        //     {
        //         if (qs < 0 || qe > n - 1 || qs > qe)
        //         {
        //             Console.WriteLine("Invalid Input");
        //             return -1;
        //         }
        //         return getSumUtil(0, n - 1, qs, qe, 0);
        //     }

        //     int constructSTUtil(int[] arr, int ss, int se, int si)
        //     {
        //         if (ss == se)
        //         {
        //             st[si] = arr[ss];
        //             return arr[ss];
        //         }

        //         int mid = getMid(ss, se);
        //         st[si] = constructSTUtil(arr, ss, mid, si * 2 + 1) +
        //                 constructSTUtil(arr, mid + 1, se, si * 2 + 2);
        //         return st[si];
        //     }

    }
}
