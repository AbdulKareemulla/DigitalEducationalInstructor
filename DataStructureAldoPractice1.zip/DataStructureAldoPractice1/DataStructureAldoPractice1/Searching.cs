﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataStructureAldoPractice1
{
    public static class BinarySearch1
    {
        public static void BinarySearch11(int[] arr, int si)
        {
            int output = -1;
            int l = 0;
            int r = arr.Length - 1;
            while (l <= r)
            {
                int mid = (l + r) / 2;
                if (arr[mid] == si)
                {
                    output = mid;
                    Console.WriteLine(output);
                    return;
                }
                else if (arr[mid] > si)
                {
                    r = mid - 1;
                }
                else
                {
                    l = mid + 1;
                }
            }

            output = -1; ;
        }
    }

    public static class ExponentialSearch
    {
        public static void ExponentialSearch1(int[] arr, int x)
        {
            int n = arr.Length;
            int i = 1;
            while (n > i && arr[i] <= x)
            {
                i = i * 2;
            }

            BinarySearch1(arr, x, i / 2, Math.Min(i, n));
        }

        public static void BinarySearch1(int[] arr, int si, int l, int r)
        {
            int output = -1;
            while (l <= r)
            {
                int mid = (l + r) / 2;
                if (arr[mid] == si)
                {
                    output = mid;
                    Console.WriteLine(output);
                    return;
                }
                else if (arr[mid] > si)
                {
                    r = mid - 1;
                }
                else
                {
                    l = mid + 1;
                }
            }

            output = -1; ;
        }
    }

    public static class FibonacciSearch
    {
        public static int fibonaccianSearch(int[] arr, int x, int n)
        {
            int F2 = 0;
            int F1 = 1;
            int F = F2 + F1;
            int offset = -1;
            while (F < n + 1)
            {
                F2 = F1;
                F1 = F;
                F = F1 + F2;
            }

            while (F > 1)
            {
                int i = Math.Min(offset + F2, n);

                if (arr[i] < x)
                {
                    F = F1;
                    F1 = F2;
                    F2 = F - F1;
                    offset = i;
                }
                else if (arr[i] > x)
                {
                    F = F2;
                    F1 = F1 - F2;
                    F2 = F - F1;
                }
                else
                {
                    return i;
                }
            }
            if (arr[offset + 1] == x)
            {
                return offset + 1;
            }

            return -1;
        }
    }

    public static class InterpolationSerach
    {
        public static int InterpolationSearch1(int[] arr, int x)
        {
            int output = -1;
            int h = arr.Length - 1;
            int l = 0;

            while (l <= h && arr[l] <= x && arr[h] >= x)
            {
                if (l == h)
                {
                    output = l;
                    return output;
                }
                int pos = Convert.ToInt16(l + (((double)(h - l) / (arr[h] - arr[l])) * (x - arr[l])));

                if (arr[pos] == x)
                {
                    output = pos;
                    return output;
                }

                if (arr[pos] < x)
                {
                    l = pos + 1;

                }
                else
                {
                    h = pos - 1;

                }
            }


            return output;
        }

    }

    public static class JumpSearch
    {
        public static void JumpSearch1(int[] arr, int m, int si)
        {
            int l = 0;
            int n = arr.Length - 1;
            int r = m;

            while (r <= n)
            {
                if (arr[l] <= si && si <= arr[r])
                {
                    for (int i = l; i < r; i++)
                    {
                        if (si == arr[i])
                        {
                            Console.WriteLine(i);
                            return;
                        }
                    }
                }

                l = r;
                r = l + m;

            }

            // return -1 for serach item not exist

        }
    }

    public static class LinearSearch
    {
        public static void LinearSearch1(int[] arr, int si)
        {
            for (int i = 0; i < arr.Length; i++)
            {
                if (arr[i] == si)
                {
                    Console.WriteLine(i);
                }
            }
        }
    }
}
