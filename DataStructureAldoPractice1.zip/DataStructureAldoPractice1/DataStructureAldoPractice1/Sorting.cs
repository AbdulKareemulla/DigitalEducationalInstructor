﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataStructureAldoPractice1
{
    public static class LinearSort
    {
        public static int[] LinearSort1(int[] arr)
        {
            int count = 0;
            for (int i = 1; i < arr.Length; i++)
            {
                int temp = arr[i];
                int j = i - 1;

                while (j >= 0 && arr[j] > temp)
                {
                    count++;
                    arr[j + 1] = arr[j];
                    j--;
                }
                arr[j + 1] = temp;
            }
            return arr;
        }
    }

    public static class CountingSort
    {
        public static void CountinfSort1(int[] arr)
        {
            int maxvalue = 0;
            for (int i = 0; i < arr.Length; i++)
            {
                if (maxvalue < arr[i])
                    maxvalue = arr[i];
            }
            int[] count = new int[maxvalue + 1];

            for (int i = 0; i < arr.Length; i++)
            {
                count[arr[i]] = count[arr[i]] + 1;
            }

            for (int i = 1; i < count.Length; i++)
            {
                count[i] = count[i] + count[i - 1];
            }

            int[] b = new int[arr.Length];
            for (int i = arr.Length - 1; i >= 0; i--)
            {
                count[arr[i]] = count[arr[i]] - 1;
                b[count[arr[i]]] = arr[i];
            }

            for (int i = 0; i < b.Length - 1; i++)
            {
                Console.Write(b[i] + " ");
            }
        }

        public static void ContingSort2()
        {
            List<int> lstvalues = new List<int>();
            int N = int.Parse(Console.ReadLine());
            for (int i = 0; i < N; i++)
            {
                lstvalues.Add(int.Parse(Console.ReadLine().Split(' ')[0]));
            }
            int previous = 0;
            for (int i = 0; i <= 100; i++)
            {
                int eachvaluelength = lstvalues.Where(c => c == i).ToArray().Length;
                previous = previous + eachvaluelength;
                Console.Write(previous + " ");
            }
        }

        public static void ContingSort3()
        {
            int maxvalue = 0;
            int lstcount = Convert.ToInt32(Console.ReadLine());

            int[] arr = new int[lstcount];
            string[] strarr = new string[lstcount];

            for (int i = 0; i < lstcount; i++)
            {
                string[] splitstring = Console.ReadLine().Split(' ');
                arr[i] = Convert.ToInt32(splitstring[0]);
                strarr[i] = splitstring[1];

                if (Convert.ToInt32(splitstring[0]) > maxvalue)
                {
                    maxvalue = Convert.ToInt32(splitstring[0]);
                }
            }
            StringBuilder sb = new StringBuilder();
            int half = lstcount / 2;
            for (int i = 0; i <= maxvalue; i++)
            {
                for (int j = 0; j < lstcount; j++)
                {
                    if (i == arr[j])
                    {
                        if (half > j)
                        {
                            sb.Append("- ");
                        }
                        else
                        {
                            sb.Append(strarr[j] + " ");
                        }
                    }
                }
            }

            Console.WriteLine(sb.ToString());

        }
    }

    public static class SelectionSort
    {
        public static void SelectionSort1(int[] arr)
        {
            for (int i = 0; i < arr.Length - 1; i++)
            {
                int min = i;
                for (int j = i; j < arr.Length; j++)
                {
                    if (arr[min] > arr[j])
                    {
                        min = j;
                    }
                }
                if (min != i)
                {
                    int first = arr[i];
                    int second = arr[min];

                    arr[i] = second;
                    arr[min] = first;
                }
            }
        }
    }

    public static class BubbleSort
    {
        public static void BubbleSort1(int[] arr)
        {
            for (int i = 0; i < arr.Length - 1; i++)
            {
                int flag = 0;
                for (int j = 0; j < arr.Length - i - 1; j++)
                {
                    if (arr[j] > arr[j + 1])
                    {
                        int temp = arr[j];
                        arr[j] = arr[j + 1];
                        arr[j + 1] = temp;
                        flag = 1;
                    }
                }
                if (flag == 0)
                {
                    break;
                }
            }
        }

    }

    public static class InsertionSort
    {
        public static void insertionSortFOR(int[] ar)
        {
            int n = ar.Length;
            int digittosort = ar[n - 1];

            if (ar.Length == 1)
            {
                Console.WriteLine(ar[0]);
            }

            for (int i = ar.Length - 2; i >= 0; i--)
            {
                if (ar[i] > digittosort)
                {
                    ar[i + 1] = ar[i];
                    PrintArray(ar);
                    if (i == 0)
                    {
                        ar[0] = digittosort;
                        PrintArray(ar);
                    }

                }
                else
                {
                    ar[i + 1] = digittosort;
                    PrintArray(ar);
                    return;
                }
            }
        }

        public static void PrintArray(int[] arr)
        {
            for (int j = 0; j < arr.Length; j++)
            {
                Console.Write(arr[j] + " ");
            }
            Console.WriteLine();
        }

        public static void insertionSortWHILE(int[] ar)
        {
            //int n = ar.Length;
            //int digittosort = ar[n - 1];
            //int i = ar.Length - 1;
            //while ((i > 0) && (digittosort < ar[i-1]))
            //{
            //    ar[i] = ar[i - 1];
            //    i--;
            //    PrintArray(ar);
            //}
            //ar[i] = digittosort;
            //PrintArray(ar);


            int n = ar.Length - 2;
            int digittosort = ar[ar.Length - 1];

            while (ar[n] > digittosort)
            {
                ar[n + 1] = ar[n];
                n--;
            }
            ar[n + 1] = digittosort;
        }

        public static void insertionsortmulti(int[] ar)
        {
            int n = ar.Length;
            for (int i = 1; i < n; i++)
            {
                for (int j = i - 1; j >= 0 && ar[j] > ar[j + 1]; j--)
                {
                    int curr = ar[j];
                    int decrecurre = ar[j + 1];
                    ar[j] = decrecurre;
                    ar[j + 1] = curr;
                }
                PrintArray(ar);
            }

            for (int i = 1; i < n; i++)
            {
                int j = i - 1;
                while (j >= 0 && ar[j] > ar[j + 1])
                {
                    int curr = ar[j];
                    int decrecurre = ar[j + 1];
                    ar[j] = decrecurre;
                    ar[j + 1] = curr;
                    j--;
                }
                PrintArray(ar);
            }
        }

        public static void insertionSortmultiple2(int[] A)
        {
            var j = 0;
            int count = 0;
            for (var i = 1; i < A.Length; i++)
            {
                var value = A[i];
                j = i - 1;
                while (j >= 0 && A[j] > A[j + 1])
                {
                    int a = A[j + 1];
                    A[j + 1] = A[j];
                    A[j] = a;
                    j = j - 1;
                    count++;
                }
                //  A[j + 1] = value; 
            }
            Console.WriteLine(string.Join(" ", A));
        }

    }

    public static class MergeSort
    {
        public static void MergeSort1(int[] arr, int lb, int ub)
        {
            if (lb < ub)
            {
                int mid = (lb + ub) / 2;
                MergeSort1(arr, lb, mid);
                MergeSort1(arr, mid + 1, ub);
                Merge(arr, lb, mid, ub);
            }
        }

        public static void Merge(int[] arr, int lb, int mid, int ub)
        {
            int i = 0;
            int j = 0;
            int k = lb;
            int n1 = mid - lb + 1;
            int n2 = ub - mid;
            int[] L = new int[n1];
            int[] R = new int[n2];

            for (i = 0; i < n1; i++)
                L[i] = arr[lb + i];
            for (j = 0; j < n2; j++)
                R[j] = arr[mid + 1 + j];

            i = 0;
            j = 0;
            while (i < n1 && j < n2)
            {
                if (L[i] <= R[j])
                {
                    arr[k] = L[i];
                    i++;
                    k++;
                }
                else
                {
                    arr[k] = R[j];
                    j++;
                    k++;
                }
            }

            while (i < n1)
            {
                arr[k] = L[i];
                i++;
                k++;
            }

            while (j < n2)
            {
                arr[k] = R[j];
                j++;
                k++;
            }

        }
    }

    public static class QuickSort
    {

        public static void QuickSort1(int[] arr, int lb, int ub)
        {
            if (lb < ub)
            {
                int pivotindx = Partition1(arr, lb, ub);
                QuickSort1(arr, lb, pivotindx - 1);
                QuickSort1(arr, pivotindx + 1, ub);
            }
        }

        public static int Partition1(int[] arr, int lb, int ub)
        {
            int start = lb;
            int end = ub;
            int pivot = arr[lb];
            while (start < end)
            {

                while (arr[start] <= pivot)
                {
                    start++;
                    if (arr.Length == start)
                    {
                        break;
                    }
                }
                while (arr[end] > pivot)
                {
                    end--;
                }

                if (start < end)
                {
                    int temp = arr[start];
                    arr[start] = arr[end];
                    arr[end] = temp;
                }
            }

            int temp1 = arr[end];
            arr[end] = arr[lb];
            arr[lb] = temp1;
            return end;
        }

        public static void QuickSort2(int[] arr, int lb, int ub)
        {
            if (lb < ub)
            {
                int pivotindx = Partition2(arr, lb, ub);
                Console.WriteLine(string.Join(" ", arr));
                QuickSort2(arr, lb, pivotindx - 1);
                QuickSort2(arr, pivotindx + 1, ub);
            }
        }

        public static int Partition2(int[] arr, int lb, int ub)
        {
            int pivot = arr[ub];
            int startingind = lb;
            for (int i = lb; i < ub; i++)
            {
                if (arr[i] < pivot)
                {
                    int temp = arr[i];
                    arr[i] = arr[startingind];
                    arr[startingind] = temp;
                    startingind++;
                }
            }

            int temp1 = arr[ub];
            arr[ub] = arr[startingind];
            arr[startingind] = temp1;
            return startingind;
        }
    }

    public static class HeapSort
    {
        public static void HeapSort1(int[] arr, int n)
        {
            int len = arr.Length;
            for (int i = len / 2 - 1; i >= 0; i--)
            {
                MaxHeapify(arr, len, i);
            }

            for (int i = n; i >= 0; i--)
            {
                int temp = arr[0];
                arr[0] = arr[i];
                arr[i] = temp;
                MaxHeapify(arr, i, 0);
            }
        }

        public static void MaxHeapify(int[] arr, int n, int i)
        {
            int logest = i;
            int l = 2 * i + 1;
            int r = 2 * i + 2;

            while (l < n && arr[l] > arr[logest])
            {
                logest = l;
            }
            while (r < n && arr[r] > arr[logest])
            {
                logest = r;
            }

            if (i != logest)
            {
                int temp = arr[i];
                arr[i] = arr[logest];
                arr[logest] = temp;
                MaxHeapify(arr, n, logest);
            }
        }

    }

    public static class RadixSort
    {
        public static void RadixSort1(int[] arr)
        {
            int digitcnt = 0;
            for (int i = 0; i < arr.Length; i++)
            {
                int cnt = arr[i];
                if (cnt.ToString().Length > digitcnt)
                {
                    digitcnt = cnt.ToString().Length;
                }
            }

            int m = 1;
            for (int i = 1; i <= digitcnt; i++)
            {
                RadixCounting(arr, m);
                m = m * 10;
            }


        }

        public static void RadixCounting(int[] arr, int pass)
        {
            int[] count = new int[10];

            for (int i = 0; i < arr.Length; i++)
            {
                count[(arr[i] / pass) % 10]++;
            }

            for (int i = 1; i < count.Length; i++)
            {
                count[i] = count[i] + count[i - 1];
            }

            int[] b = new int[arr.Length];

            for (int i = arr.Length - 1; i >= 0; i--)
            {
                count[(arr[i] / pass) % 10] = count[(arr[i] / pass) % 10] - 1;

                b[count[(arr[i] / pass) % 10]] = arr[i];
            }

            for (int i = 0; i < arr.Length; i++)
            {
                arr[i] = b[i];
            }



        }

    }
    public static class ShellSort
    {
        public static void ShellSort1(int[] arr)
        {
            int n = arr.Length;
            for (int gap = n / 2; gap >= 1; gap = gap / 2)
            {
                for (int j = gap; j < n; j++)
                {
                    for (int i = j - gap; i >= 0; i = i - gap)
                    {
                        if (arr[i] > arr[i + gap])
                        {
                            int temp = arr[i + gap];
                            arr[i + gap] = arr[i];
                            arr[i] = temp;
                        }
                        else
                        {
                            break;
                        }
                    }
                }
            }
        }

    }

}
