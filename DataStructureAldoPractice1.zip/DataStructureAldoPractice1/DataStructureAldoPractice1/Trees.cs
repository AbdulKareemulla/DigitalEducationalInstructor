﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataStructureAldoPractice1
{
    public class LinkListNode
    {
        public int data { get; set; }
        public LinkListNode lstnode;
        public LinkListNode(int d)
        {
            data = d;
            lstnode = null;
        }
    }

    public class BinaryTreeNode
    {
        public int data { get; set; }
        public BinaryTreeNode leftnode;
        public BinaryTreeNode rightnode;
        public BinaryTreeNode(int d)
        {
            data = d;
            leftnode = null;
            rightnode = null;
        }


    }

    public class BinaryTree
    {
        public LinkListNode head;
        public BinaryTreeNode root;
        public void push(int listdata)
        {
            LinkListNode lk = new LinkListNode(listdata);
            lk.lstnode = head;
            head = lk;
        }


        public void InOrderTravers(TreeNode root)
        {
            if (root != null)
            {
                InOrderTravers(root.left);
                Console.Write(root.data + " ");

                InOrderTravers(root.right);
            }
        }

        public void PreOrderTravers(TreeNode root)
        {
            if (root != null)
            {
                Console.Write(root.data + " ");
                PreOrderTravers(root.left);
                PreOrderTravers(root.right);
            }
        }

        public void PostOrderTravers(TreeNode root)
        {
            if (root != null)
            {
                PostOrderTravers(root.left);
                PostOrderTravers(root.right);
                Console.Write(root.data + " ");
            }
        }

        public BinaryTreeNode ConstructBinaryTreeFromArray(int[] arr, BinaryTreeNode root, int i)
        {
            if (i < arr.Length)
            {
                root = new BinaryTreeNode(arr[i]);
                root.leftnode = ConstructBinaryTreeFromArray(arr, root.leftnode, (2 * i + 1));
                root.rightnode = ConstructBinaryTreeFromArray(arr, root.rightnode, (2 * i + 2));
            }
            return root;
        }

        Dictionary<int, int> hm = new Dictionary<int, int>();
        public int preindex = 0;
        public TreeNode ConstructBinaryTreeInorderPreorder(int[] inorder, int[] preorder)
        {
            for (int i = 0; i < inorder.Length; i++)
            {
                hm.Add(inorder[i], i);
            }
            return RecursiveBinaryTreeInorderPreorder(preorder, inorder, 0, inorder.Length - 1);
        }

        public TreeNode RecursiveBinaryTreeInorderPreorder(int[] preorder, int[] inorder, int start, int end)
        {
            if (start > end)
                return null;
            TreeNode root = new TreeNode(preorder[preindex++]);

            if (root.data == null)
                return null;

            if (start == end)
                return root;

            int index = hm[root.data];

            root.left = RecursiveBinaryTreeInorderPreorder(preorder, inorder, start, index - 1);
            root.right = RecursiveBinaryTreeInorderPreorder(preorder, inorder, index + 1, end);
            return root;
        }

    }


    public class BinarySearchTree
    {
        public void Looping(int[] arr)
        {
            BinaryTree trees = new BinaryTree();
            //int[] preorder = { 20, 16, 5, 18, 17, 19, 60, 85, 70 };
            //int[] inorder = { 5, 16, 17, 18, 19, 20, 60, 70, 85 };
            //int[] postorder = { 5, 17, 19, 18, 16, 70, 85, 60, 20 };
            //TreeNode node = trees.ConstructBinaryTreeInorderPostorder(inorder, postorder);
            TreeNode trnode = null;
            for (int i = 0; i < arr.Length; i++)
            {
                trnode = insertionRecursive(trnode, arr[i]);
            }
            trees.InOrderTravers(trnode);
            deleteRecursively(trnode, 20);
            Console.WriteLine();
            trees.InOrderTravers(trnode);
        }

        public TreeNode insertionRecursive(TreeNode root, int value)
        {

            if (root == null)
                return new TreeNode(value);

            if (value < (int)root.data)
            {
                root.left = insertionRecursive(root.left, value);
            }
            else if (value > (int)root.data)
            {
                root.right = insertionRecursive(root.right, value);
            }

            return root;

        }

        public TreeNode deleteRecursively(TreeNode root, int value)
        {

            if (root == null)
                return root;

            if (value < (int)root.data)
            {
                root.left = deleteRecursively(root.left, value);
            }
            else if (value > (int)root.data)
            {
                root.right = deleteRecursively(root.right, value);
            }
            else
            {

                if (root.left == null)
                {
                    return root.right;
                }
                else if (root.right == null)
                    return root.left;

                root.data = inOrderSuccessor(root.right);
                root.right = deleteRecursively(root.right, (int)root.data);
            }

            return root;

        }

        public int inOrderSuccessor(TreeNode root)
        {
            int minimum = (int)root.data;
            while (root.left != null)
            {
                minimum = (int)root.left.data;
                root = root.left;
            }
            return minimum;
        }


        public int InoderPredessor(TreeNode root)
        {
            int i = root.data;

            while (root.right != null)
            {
                i = root.right.data;
                root = root.right;
            }
            return i;

        }
    }

    public class Trees
    {

        Dictionary<int, int> hm = new Dictionary<int, int>();
        public int preindex = 0;
        
        public TreeNode ConstructBinaryTreeInorderPostorder(int[] inorder, int[] postorder)
        {
            for (int i = 0; i < inorder.Length; i++)
            {
                hm.Add(inorder[i], i);
            }
            return RecursiveBinaryTreeInorderPostorder(postorder, inorder, 0, inorder.Length - 1, inorder.Length - 1);

        }

        public TreeNode RecursiveBinaryTreeInorderPostorder(int[] postorder, int[] inorder, int start, int end, int index)
        {
            if (start > end)
                return null;
            TreeNode root = new TreeNode(postorder[index]);

            if (root.data == null)
                return null;

            if (start == end)
                return root;

            int inrtindex = hm[root.data];

            root.right = RecursiveBinaryTreeInorderPostorder(postorder, inorder, inrtindex + 1, end, index - 1);
            root.left = RecursiveBinaryTreeInorderPostorder(postorder, inorder, start, inrtindex - 1, index - (end - inrtindex) - 1);
            return root;
        }

        public TreeNode RecursiveBinaryTreePreorderPostorder(int[] preorder, int[] postorder, int start, int end)
        {
            if (start > end || preindex >= preorder.Length)
                return null;
            TreeNode root = new TreeNode(preorder[preindex++]);

            if (start == end || preindex >= preorder.Length)
                return root;
            int index = hm[root.data];

            if (index <= end)
            {
                root.left = RecursiveBinaryTreePreorderPostorder(preorder, postorder, start, index);
                root.right = RecursiveBinaryTreePreorderPostorder(preorder, postorder, index + 1, end);

            }
            return root;
        }

        public TreeNode ConstructBinaryTreePreorderPostorder(int[] preorder,
                                         int[] postorder)
        {
            preindex = 0;

            for (int i = 0; i < preorder.Length; i++)
            {
                hm.Add(preorder[i], i);
            }

            return RecursiveBinaryTreePreorderPostorder(preorder, postorder, 0, postorder.Length - 1);
        }

    }

    public class TreeNode
    {

        public int data { get; set; }
        public TreeNode left { get; set; }
        public TreeNode right { get; set; }
        public TreeNode(int data)
        {
            this.data = data;
            left = right = null;
        }
    }

}
