using System;

namespace FirstCoreMVCApplication.Models
{
    public class ErrorViewModel
    {
        public string RequestId { get; set; }
        public string Stacktrace { get; set; }
        public string Message { get; set; }
        public bool ShowRequestId => !string.IsNullOrEmpty(RequestId);
    }
}