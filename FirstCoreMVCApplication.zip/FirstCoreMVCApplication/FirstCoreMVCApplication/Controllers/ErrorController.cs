﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace FirstCoreMVCApplication.Controllers
{
    public class ErrorController : Controller
    {

        // GET: /<controller>/
        [Route("Error/ErrorIndex")]
        public IActionResult ErrorIndex()
        {


            var feature = HttpContext.Features.Get<IExceptionHandlerFeature>();
            var error = feature?.Error;
            // _logger = factory.Create("Unhandled Error");
            //_logger.LogError("Oops!", error);
            return View();
        }
    }
}
