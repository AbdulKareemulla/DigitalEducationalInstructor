﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logical
{
    public class QueueAlgorithms
    {
        public void QueueOperation()
        {
            Queue que = new Queue();
            que.Enqueue("1st Element");
            que.Enqueue("2st Element");
            que.Enqueue("3st Element");
            que.Enqueue("4st Element");

            Console.WriteLine(que.Peek());
            foreach (var q in que)
            {
                Console.WriteLine(q);
            }

            Console.WriteLine("Deque Element " + que.Dequeue());
            Console.WriteLine("Deque Element " + que.Dequeue());

            foreach (var q in que)
            {
                Console.WriteLine(q);
            }

            que.Dequeue();
        }
    }

    public class ImplementQueueFromArray
    {
        int size = 5;
        int[] arrque = new int[5];
        int front = -1;
        int rear = -1;
        public void EnQue(int data)
        {
            if (rear == size - 1)
            {
                Console.WriteLine(" Overflow ");
            }
            else if (front == -1 && rear == -1)
            {
                front++;
                rear++;
                arrque[rear] = data;
            }
            else
            {
                rear++;
                arrque[rear] = data;
            }
        }

        public void DeQue()
        {
            if (front == -1 && rear == -1)
            {
                Console.WriteLine(" Empty Queue ");
            }
            if (front == rear)
            {
                front = -1;
                rear = -1;
            }
            else
            {
                Console.WriteLine("Dequeue Element " + arrque[front]);
                front++;
            }
        }

        public void Peek()
        {
            if (front == -1 && rear == -1)
            {
                Console.WriteLine("Queue is Empty");
            }
            else
            {
                Console.WriteLine(arrque[front]);
            }
        }

        public void Display()
        {
            if (front == -1 && rear == -1)
            {
                Console.WriteLine("Queue is Empty");
            }
            else
            {
                for (int i = front; i < rear + 1; i++)
                {
                    Console.WriteLine(arrque[i]);
                }

            }
        }
    }

    //public class DoubleEndedQueue
    //{
    //    int size = 5;
    //    int[] arrque = new int[5];
    //    int front = -1;
    //    int rear = -1;
    //    public void EnqueFront(int d)
    //    {
    //        if ((front == 0 && rear == size - 1) || (front == rear + 1))
    //        {
    //            Console.WriteLine("Que is full");
    //        }
    //        else if (front == -1 && rear == -1)
    //        {
    //            front = rear = 0;
    //            arrque[front] = d;
    //        }
    //        else if (front == 0)
    //        {
    //            front = size - 1;
    //            arrque[front] = d;
    //        }
    //        else
    //        {
    //            front--;
    //            arrque[front] = d;
    //        }

    //    }
    //    public void EnqueRare(int d)
    //    {
    //        if ((front == 0 && rear == size - 1) || (front == rear + 1))
    //        {
    //            Console.WriteLine("Que is full");
    //        }
    //        else if (front == -1 && rear == -1)
    //        {
    //            front = rear = 0;
    //            arrque[rear] = d;
    //        }
    //        else if (rear == size - 1)
    //        {
    //            rear = 0;
    //            arrque[rear] = d;
    //        }
    //        else
    //        {
    //            rear++;
    //            arrque[rear] = d;
    //        }

    //    }
    //    public void Display()
    //    {

    //        int i = front;

    //        while (i != rear)
    //        {
    //            Console.Write(arrque[i] + " ");
    //            i = (i + 1) % size;
    //        }
    //        Console.Write(arrque[i] + " ");
    //        Console.WriteLine();
    //    }
    //    public void PrintFront()
    //    {
    //        if ((front == -1 && rear == -1))
    //        {
    //            Console.WriteLine("Que is empty");
    //        }

    //        Console.WriteLine(arrque[front]);
    //    }
    //    public void PrintRear()
    //    {
    //        if ((front == -1 && rear == -1))
    //        {
    //            Console.WriteLine("Que is empty");
    //        }

    //        Console.WriteLine(arrque[rear]);
    //    }
    //    public void DequFront()
    //    {
    //        if ((front == -1 && rear == -1))
    //        {
    //            Console.WriteLine("Que is empty");
    //        }
    //        else if (front == rear)
    //        {
    //            rear = front = -1;
    //        }
    //        else if (front == size - 1)
    //        {
    //            front = 0;
    //        }
    //        else
    //        {
    //            front++;
    //        }
    //    }

    //    public void DequRear()
    //    {
    //        if ((front == -1 && rear == -1))
    //        {
    //            Console.WriteLine("Que is empty");
    //        }
    //        else if (front == rear)
    //        {
    //            rear = front = -1;
    //        }
    //        else if (rear == 0)
    //        {
    //            rear = size - 1;
    //        }
    //        else
    //        {
    //            rear--;
    //        }
    //    }
    //}

    //public class ImplementStackUsingQueue1
    //{
    //    Queue q1 = new Queue();
    //    Queue q2 = new Queue();

    //    public void Push(int d)
    //    {
    //        q2.Enqueue(d);

    //        while (q1.Count > 0)
    //        {
    //            q2.Enqueue(q1.Dequeue());
    //        }

    //        while (q2.Count > 0)
    //        {
    //            q1.Enqueue(q2.Dequeue());
    //        }
    //    }

    //    public void Pop()
    //    {
    //        if (q1.Count > 0)
    //        {
    //            q1.Dequeue();
    //        }

    //    }

    //    public void Display()
    //    {

    //        foreach (var item in q1)
    //        {
    //            Console.Write(item +" ");
    //        }
    //    }
    //}

    public class ImplementStackUsingQueue2
    {
        Queue q1 = new Queue();
        Queue q2 = new Queue();

        public void Push(int d)
        {
            q1.Enqueue(d);
        }

        public void Pop()
        {
            if (q1.Count==0 && q2.Count==0)
            {
                Console.WriteLine("Queue is Empty");
                return;
            }

            while (q1.Count > 1)
            {
                q2.Enqueue(q1.Dequeue());
            }
            q1.Dequeue();
            while (q2.Count > 0)
            {
                q1.Enqueue(q2.Dequeue());
            }

        }

    }
}