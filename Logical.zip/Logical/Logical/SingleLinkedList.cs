﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logical
{
    public class SinglyLinkedList
    {

        public SingleLinkedList CreateListedList()
        {
            SingleLinkedList slnlst = new SingleLinkedList();
            slnlst.head = new Node(0);

            Node first = new Node(1);
            Node second = new Node(2);
            Node third = new Node(3);

            slnlst.head.Next = first;
            first.Next = second;
            second.Next = third;

            Node n = slnlst.head;
            while (n != null)
            {
                Console.WriteLine(n.data);
                n = n.Next;
            }
            return slnlst;
        }

        public Node CreateListedListFormergesort()
        {
            Node zeroth = new Node(15);
            Node first = new Node(10);
            Node second = new Node(5);
            Node third = new Node(20);
            Node fourth = new Node(3);
            Node fivth = new Node(2);

            zeroth.Next = first;
            first.Next = second;
            second.Next = third;
            third.Next = fourth;
            fourth.Next = fivth;

            Node n = zeroth;
            while (n != null)
            {
                Console.WriteLine(n.data);
                n = n.Next;
            }
            return zeroth;
        }
        public SingleLinkedList InserFront(SingleLinkedList slst, int newnode)
        {
            Node n = new Node(newnode);
            n.Next = slst.head;
            slst.head = n;

            Node n1 = slst.head;
            while (n1 != null)
            {
                Console.WriteLine(n1.data);
                n1 = n1.Next;
            }

            return slst;
        }
        public void InsertAfter(Node prevnode, int newnode)
        {
            Node newn = new Node(newnode);
            newn.Next = prevnode.Next;
            prevnode.Next = newn;
        }
        public SingleLinkedList InsertLast(SingleLinkedList slst, int newnode)
        {
            Node temp = slst.head;
            Node nwnd = new Node(newnode);
            if (slst.head == null)
            {
                slst.head = nwnd;
                return slst;
            }

            while (temp.Next != null)
            {
                temp = temp.Next;
            }

            temp.Next = nwnd;

            Node n = slst.head;
            while (n != null)
            {
                Console.WriteLine(n.data);
                n = n.Next;
            }

            return slst;
        }

        public void DeleteNodebyKeys(SingleLinkedList slst, int key)
        {
            Node temp = slst.head;
            Node prev = null;


            if (temp != null && temp.data == key)
            {
                slst.head = temp.Next;
                return;
            }

            while (temp != null && temp.data != key)
            {
                prev = temp;
                temp = temp.Next;
            }
            prev.Next = temp.Next;
            return;
        }

        public void DeleteByPosition(SingleLinkedList slst, int position)
        {
            Node temp = slst.head;
            if (position == 0)
            {
                slst.head = temp.Next;
            }


            for (int i = 0; temp != null && i < position - 1; i++)
            {
                temp = temp.Next;
            }

            if (temp == null && temp.Next == null)
            {
                return;
            }

            Node nodenext = temp.Next.Next;
            temp.Next = nodenext;
        }

        public void Search(SingleLinkedList slst, int k)
        {
            Node temp = slst.head;
            while (temp != null)
            {
                if (temp.data == k)
                {
                    Console.WriteLine("Data Found");
                    return;
                }
                temp = temp.Next;
            }

            Console.WriteLine("Data Not Found");

        }

        public void FindMid(SingleLinkedList slst)
        {
            Node slowptr = slst.head;
            Node fastptr = slst.head;
            if (slst.head != null)
            {
                while (fastptr != null && fastptr.Next != null)
                {
                    slowptr = slowptr.Next;
                    fastptr = fastptr.Next.Next;
                }
                Console.WriteLine("Mid data is " + slowptr.data);
            }
        }

        public Node FindMiddle(Node h)
        {
            // Base case 
            if (h == null)
                return h;
            Node fastptr = h.Next;
            Node slowptr = h;

            // Move fastptr by two and slow ptr by one 
            // Finally slowptr will point to middle node 
            while (fastptr != null)
            {
                fastptr = fastptr.Next;
                if (fastptr != null)
                {
                    slowptr = slowptr.Next;
                    fastptr = fastptr.Next;
                }
            }
            return slowptr;
        }

        public void ReverseLinkedList(SingleLinkedList slst)
        {
            Console.WriteLine("Before Reversing");
            Node temp = slst.head;

            while (temp != null)
            {

                Console.Write(" " + temp.data);
                temp = temp.Next;
            }

            Node temp1 = null;
            Node current = slst.head;
            Node prev = null;
            Console.WriteLine("");
            while (current != null)
            {
                temp1 = current.Next;
                current.Next = prev;
                prev = current;
                current = temp1;
            }

            slst.head = prev;


            Console.WriteLine("After Reversing");
            Node temp2 = slst.head;
            while (temp2 != null)
            {
                Console.Write(" " + temp2.data);
                temp2 = temp2.Next;
            }
        }

        public Node SortedMege(Node a, Node b)
        {
            Node result = null;
            if (a == null)
                return b;
            if (b == null)
                return a;

            if (a.data <= b.data)
            {
                result = a;
                result.Next = SortedMege(a.Next, b);
            }
            else
            {
                result = b;
                result.Next = SortedMege(a, b.Next);
            }

            return result;
        }

        public Node MergeSort(Node head)
        {
            if (head == null || head.Next == null)
            {
                return head;
            }

            Node mid = FindMiddle(head);
            Node nextofmiddle = mid.Next;
            mid.Next = null;

            Node left = MergeSort(head);
            Node right = MergeSort(nextofmiddle);
            Node srtedll= SortedMege(left, right);
            return srtedll;
        }
    }
    public class SingleLinkedList
    {
        internal Node head;
    }
    public class Node
    {
        internal Node Next;
        internal int data;
        public Node(int d)
        {
            data = d;
            Next = null;
        }
    }
}
