﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Logical.BinarySearch;

namespace Logical
{
    class Program
    {
        static void Main(string[] args)
        {
            String s1 = "AXY";
            String s2 = "ADXCPY";

            char[] X = s1.ToCharArray();
            char[] Y = s2.ToCharArray();
            int m = X.Length;
            int n = Y.Length;
            string s = "AABEBCDD";
            int[] arr = { 40, 20, 30, 10, 30 };

            DynamicProgramming dp = new DynamicProgramming();
            DynamicProgramming.TreesDP.min min = new DynamicProgramming.TreesDP.min();

            DynamicProgramming.TreesDP root = new DynamicProgramming.TreesDP(1);
            //root.left = new DynamicProgramming.TreesDP(2);
            //root.right = new DynamicProgramming.TreesDP(3);
            // root.right.left = new DynamicProgramming.TreesDP(15);
            //  root.right.right = new DynamicProgramming.TreesDP(7);


            //root.PathSum(root, min);



            root = new DynamicProgramming.TreesDP(-15);
            root.left = new DynamicProgramming.TreesDP(5);
            root.right = new DynamicProgramming.TreesDP(6);
            root.left.left = new DynamicProgramming.TreesDP(-8);
            root.left.right = new DynamicProgramming.TreesDP(1);
            root.left.left.left = new DynamicProgramming.TreesDP(2);
            root.left.left.right = new DynamicProgramming.TreesDP(6);
            root.right.left = new DynamicProgramming.TreesDP(3);
            root.right.right = new DynamicProgramming.TreesDP(9);
            root.right.right.right = new DynamicProgramming.TreesDP(0);
            root.right.right.right.left = new DynamicProgramming.TreesDP(4);
            root.right.right.right.right = new DynamicProgramming.TreesDP(-1);
            root.right.right.right.right.left = new DynamicProgramming.TreesDP(10);
            // root.PathSumWithleafnode(root, min);
            root.Diameter(root, min);
            Console.WriteLine("Max pathSum of the given binary tree is " + min.value);

            //  Console.WriteLine("Path Sum is " + min.value);

            // Console.ReadLine();
            //dp.Forloop(3, 33);
            //Console.WriteLine(dp.EggDroppingMemoize(2,32));
            //  Console.WriteLine(dp.ScrumbleStringMemoize("great", "grate"));
            //Console.Read();
            // String str = "T|F&T^T";
            //dp.Forloop(1001, 1001,2);
            // int ways = dp.EvaluateExpressionMemoize(str, 0, str.Length - 1, 1);
            //Console.WriteLine(ways);
            //dp.memoization(arr.Length);
            //Console.WriteLine(dp.MatrixChainMultiplicationMemoization(arr, 1, arr.Length - 1));

            //  Console.WriteLine(dp.SequencePatternMatching(X, Y, m, n));
            //Console.WriteLine(dp.LogestRepeatingSubSequence(s.ToCharArray(), s.ToCharArray(), s.Length, s.Length));
            //DynamicProgramming.PrintShortestCommonSubSequence dps = new DynamicProgramming.PrintShortestCommonSubSequence();
            //Console.WriteLine(dps.PrintShortestSubSequece(X, Y, m, n));
            //string s = "agbcba";
            //  Console.WriteLine(dp.MinimumDeletionForPalindrom(s));
            // Console.WriteLine(dp.LargestPalindromFromString(s));
            //dp.MinimumInsertionDeletionConvertionAtoB(X, Y, m, n);
            // Console.WriteLine(dp.ShortestCommonSubsequence(X, Y, m, n));
            //DynamicProgramming.PrintCommonSubstring dpsubstring = new DynamicProgramming.PrintCommonSubstring();
            //dpsubstring.PrintLargestCommonSubString(X, Y, m, n);


            //String[] arr = { "gracewe", "graceful", "disgraceful",
            //                                "gracefully" };
            // Function call
            //String stems =dp.findstem(arr);
            //Console.WriteLine(stems);

            //// Console.WriteLine(dp.LargestCommonSubString(X, Y, m, n));

            //DynamicProgramming.PrintCommonSubSequence dplcsprnt = new DynamicProgramming.PrintCommonSubSequence();
            //Console.WriteLine(dplcsprnt.PrintLargestCommonSubsequence(X, Y, m, n));
            // Console.WriteLine(dp.LargestCommonSubsequenceTopDown(X, Y, m, n));
            //dp.DynamicProgrammingLCSMemoization(m, n);
            // Console.WriteLine(dp.LargestCommonSubSequence(X,Y,m,n));
            // Console.WriteLine(dp.LargestCommonSubStringMemoization(X, Y, m, n));
            //int[] arr = { 9,6,5,1 };
            //int[] val = { 4, 2, 1 };
            //int sum = 8;
            //DynamicProgramming dp = new DynamicProgramming();
            //Console.WriteLine(dp.MinimumCoinCount(arr,11));
            //// Console.WriteLine(dp.CountWaysforCoinChange(arr, sum));
            //Console.ReadLine();
            //int[] arr = { 1,1,2,3};
            //int diff =1;
            //DynamicProgramming dp = new DynamicProgramming();
            //int returnval = dp.CountSubSetWithDifference(arr, diff);

            //int[] arr = { 4,1, 2,7 };
            //DynamicProgramming.KnapsackMinimumSubset kdp = new DynamicProgramming.KnapsackMinimumSubset();
            //int returnval = kdp.KnapsackminimumSubset(arr);
            //Console.WriteLine(returnval);
            //Console.ReadLine();

            //int[] arr = { 2, 3, 5, 6, 8, 10 };
            //DynamicProgramming dp = new DynamicProgramming();
            //int returnval = dp.KnapsackCountSumSubset(arr,12,arr.Length);
            //Console.WriteLine(returnval);
            //int[] arr = { 7,3,2};
            //DynamicProgramming dp = new DynamicProgramming();
            //bool returnval=dp.KnapsackEqualSumSubset(arr);
            //Console.WriteLine(returnval);
            //Console.ReadLine();
            //Console.WriteLine("Please enter the string:");
            //string input = Console.ReadLine();
            //HuffmanAlgorithm huffmanTree = new HuffmanAlgorithm();

            //// Build the Huffman tree
            //huffmanTree.Build(input);

            //// Encode
            //BitArray encoded = huffmanTree.Encode(input);

            //Console.Write("Encoded: ");
            //foreach (bool bit in encoded)
            //{
            //    Console.Write((bit ? 1 : 0) + "");
            //}
            //Console.WriteLine();

            //// Decode
            //string decoded = huffmanTree.Decode(encoded);

            //Console.WriteLine("Decoded: " + decoded);

            //Console.ReadLine();

            //int[,] graph = { { 0, 1, 1, 1 },
            //              { 1, 0, 1, 0 },
            //              { 1, 1, 0, 1 },
            //              { 1, 0, 1, 0 } };
            //int m = 3;
            //CheckMColoringGraph Coloring = new CheckMColoringGraph(4, m, graph);
            //Coloring.ColoringGraph(0);
            //int[,] graph = { {1, 1, 0, 1},
            //                 {1, 1, 1, 1},
            //                 {0, 1, 1, 1},
            //                 {1, 1, 1, 1}
            //            };
            //MColoringGraph mg = new MColoringGraph(4, 3, graph);
            //mg.ColoringGraph(0);
            //mg.PrintColor();
            //GFG n = new GFG();
            //GFG.main();

            //FloydWarshall fws = new FloydWarshall(4);
            //int INF = 99999;
            //int[,] graph = { {0, 5, INF, 10},
            //            {INF, 0, 3, INF},
            //            {INF, INF, 0, 1},
            //            {INF, INF, INF, 0}
            //            };


            //// Print the solution 
            //fws.FloydWarshallAlgo(graph);

            //int V = 5; // Number of vertices in graph 
            //int E = 8; // Number of edges in graph 

            //BellmanFordGraph graph = new BellmanFordGraph(V, E);
            //graph.edge[0].src = 0;
            //graph.edge[0].dest = 1;
            //graph.edge[0].weight = -1;

            //// add edge 0-2 (or A-C in above figure) 
            //graph.edge[1].src = 0;
            //graph.edge[1].dest = 2;
            //graph.edge[1].weight = 4;

            //// add edge 1-2 (or B-C in above figure) 
            //graph.edge[2].src = 1;
            //graph.edge[2].dest = 2;
            //graph.edge[2].weight = 3;

            //// add edge 1-3 (or B-D in above figure) 
            //graph.edge[3].src = 1;
            //graph.edge[3].dest = 3;
            //graph.edge[3].weight = 2;

            //// add edge 1-4 (or A-E in above figure) 
            //graph.edge[4].src = 1;
            //graph.edge[4].dest = 4;
            //graph.edge[4].weight = 2;

            //// add edge 3-2 (or D-C in above figure) 
            //graph.edge[5].src = 3;
            //graph.edge[5].dest = 2;
            //graph.edge[5].weight = 5;

            //// add edge 3-1 (or D-B in above figure) 
            //graph.edge[6].src = 3;
            //graph.edge[6].dest = 1;
            //graph.edge[6].weight = 1;

            //// add edge 4-3 (or E-D in above figure) 
            //graph.edge[7].src = 4;
            //graph.edge[7].dest = 3;
            //graph.edge[7].weight = -3;

            //graph.BellmanFodAlgo(graph, 0);

            //int[,] graph = new int[,] { { 0, 4, 0, 0, 0, 0, 0, 8, 0 },
            //                          { 4, 0, 8, 0, 0, 0, 0, 11, 0 },
            //                          { 0, 8, 0, 7, 0, 4, 0, 0, 2 },
            //                          { 0, 0, 7, 0, 9, 14, 0, 0, 0 },
            //                          { 0, 0, 0, 9, 0, 10, 0, 0, 0 },
            //                          { 0, 0, 4, 14, 10, 0, 2, 0, 0 },
            //                          { 0, 0, 0, 0, 0, 2, 0, 1, 6 },
            //                          { 8, 11, 0, 0, 0, 0, 1, 0, 7 },
            //                          { 0, 0, 2, 0, 0, 0, 6, 7, 0 } };
            //Dijsktra t = new Dijsktra(9);
            //t.DijsktraAlgo(graph, 0);

            // Create graphs given in above diagrams  
            //Console.WriteLine("Bridges in first graph ");
            //FindBridges g1 = new FindBridges(5);
            //g1.addEdge(1, 0);
            //g1.addEdge(0, 2);
            //g1.addEdge(2, 1);
            //g1.addEdge(0, 3);
            //g1.addEdge(3, 4);
            //g1.DisplayBridges();
            //Console.WriteLine();

            //Console.WriteLine("Bridges in Second graph");
            //FindBridges g2 = new FindBridges(4);
            //g2.addEdge(0, 1);
            //g2.addEdge(1, 2);
            //g2.addEdge(2, 3);
            //g2.DisplayBridges();
            //Console.WriteLine();

            //Console.WriteLine("Bridges in Third graph ");
            //FindBridges g3 = new FindBridges(7);
            //g3.addEdge(0, 1);
            //g3.addEdge(1, 2);
            //g3.addEdge(2, 0);
            //g3.addEdge(1, 3);
            //g3.addEdge(1, 4);
            //g3.addEdge(1, 6);
            //g3.addEdge(3, 5);
            //g3.addEdge(4, 5);
            //g3.DisplayBridges();


            //UDGraph g1 = new UDGraph(5);
            // g1.addEdge(1, 0);
            // g1.addEdge(0, 2);
            //// g1.addEdge(2, 1);
            // g1.addEdge(0, 3);
            // g1.addEdge(3, 4);
            // if (g1.isCycle())
            //     Console.WriteLine("Graph contains cycle");
            // else
            //     Console.WriteLine("Graph doesn't contains cycle");

            // DGGraph graph = new DGGraph(3);
            // graph.addEdge(0, 1);
            // graph.addEdge(0, 2);
            // graph.addEdge(1, 2);
            //// graph.addEdge(2, 0);
            //// graph.addEdge(2, 3);
            //// graph.addEdge(3, 3);

            // if (graph.isCyclic())
            //     Console.WriteLine("Graph contains cycle");
            // else
            //     Console.WriteLine("Graph doesn't "
            //                             + "contain cycle");


            //List<Edge> edges = new List<Edge>();
            //edges.Add(new Edge(1, 2));
            //edges.Add(new Edge(1, 3));
            //edges.Add(new Edge(1, 4));
            //edges.Add(new Edge(2, 5));
            //edges.Add(new Edge(2, 6));
            //edges.Add(new Edge(5, 9));
            //edges.Add(new Edge(5, 10));
            //edges.Add(new Edge(4, 7));
            //edges.Add(new Edge(4, 8));
            //edges.Add(new Edge(7, 11));
            //edges.Add(new Edge(7, 12));
            //edges.Add(new Edge(6, 10));

            //// Set number of vertices in the graph
            //int N = 13;

            //// create a graph from edges
            //GraphDetectCycleUndirected graph = new GraphDetectCycleUndirected(edges, N);

            //// Do BFS traversal in connected components of graph
            //if (graph.BFS(graph, 1, N))
            //    Console.WriteLine("Graph contains cycle");
            //else
            //    Console.WriteLine("Graph doesn't contain any cycle");

            //KrushkalExample krushkalExample = new KrushkalExample();
            //int verticesCount = 4;
            //int edgesCount = 5;
            //KrushkalExample.KrushkalGraph graph = krushkalExample.CreateGraph(verticesCount, edgesCount);

            //for (int i = 0; i < graph.edge.Length; i++)
            //{
            //    graph.edge[i] = new KrushkalExample.KrushkalEdge();
            //}

            //// Edge 0-1
            //graph.edge[0].Source = 0;
            //graph.edge[0].Destination = 1;
            //graph.edge[0].Weight = 10;

            //// Edge 0-2
            //graph.edge[1].Source = 0;
            //graph.edge[1].Destination = 2;
            //graph.edge[1].Weight = 6;

            //// Edge 0-3
            //graph.edge[2].Source = 0;
            //graph.edge[2].Destination = 3;
            //graph.edge[2].Weight = 5;

            //// Edge 1-3
            //graph.edge[3].Source = 1;
            //graph.edge[3].Destination = 3;
            //graph.edge[3].Weight = 15;

            //// Edge 2-3
            //graph.edge[4].Source = 2;
            //graph.edge[4].Destination = 3;
            //graph.edge[4].Weight = 4;

            //krushkalExample. KrushkalAlgorithm(graph);

            //int vertices = 6;
            //KrushkalMST.Graph graph = new KrushkalMST.Graph(vertices);
            //graph.addEgde(0, 1, 4);
            //graph.addEgde(0, 2, 3);
            //graph.addEgde(1, 2, 1);
            //graph.addEgde(1, 3, 2);
            //graph.addEgde(2, 3, 4);
            //graph.addEgde(3, 4, 2);
            //graph.addEgde(4, 5, 6);
            //graph.kruskalMST();

            //int vertices = 6;
            //Graph graph = new Graph(vertices);
            //graph.AddEdges(0, 1, 4);
            //graph.AddEdges(0, 2, 3);
            //graph.AddEdges(1, 2, 1);
            //graph.AddEdges(1, 3, 2);
            //graph.AddEdges(2, 3, 4);
            //graph.AddEdges(3, 4, 2);
            //graph.AddEdges(4, 5, 6);
            //graph.PrimsMST();

            //Console.Read();


            //    int[,] grid = new int[,] {
            //        {1, 2, 3, 4},
            //        {5, 6, 7, 8},
            //        {9, 10, 11, 12},
            //        {13, 14, 15, 16}
            //};
            //    BFSInMatrix d = new BFSInMatrix();
            //    // d.DFS(grid);
            //    d.DFSRecursive(grid);
            //Graphs g = new Graphs(4);

            //g.AddEdge(0, 1);
            //g.AddEdge(0, 2);
            //g.AddEdge(1, 2);
            //g.AddEdge(2, 0);
            //g.AddEdge(2, 3);
            //g.AddEdge(3, 3);

            //Console.WriteLine("Following is Depth First Traversal " +
            //                  "(starting from vertex 2)");

            //g.DFS(2);


            //Graphs g = new Graphs(4);

            //g.AddEdge(0, 1);
            //g.AddEdge(0, 2);
            //g.AddEdge(1, 2);
            //g.AddEdge(2, 0);
            //g.AddEdge(2, 3);
            //g.AddEdge(3, 3);

            //Console.Write("Following is Breadth First " + "Traversal(starting from " + "vertex 2)\n");
            //g.BFS(2);


            //Console.ReadLine();


            //TreeGraphs graphs = new TreeGraphs();
            //TreeGraphNode root= graphs.CreateGraph();
            //graphs.BFSTraversal(root);
            //graphs.DFSTraversal(root);
            //Console.ReadLine();

            //int[] arr = { 1, 3, 5, 7, 9, 11 };
            //int n = arr.Length;

            //int x = (int)(Math.Ceiling(Math.Log(n) / Math.Log(2)));
            //int max_size = 2 * (int)Math.Pow(2, x) - 1;

            //int[] st = new int[max_size];
            //SegmentTree tree = new SegmentTree();
            //tree.ConstructSegmentTree(st, 0, arr, 0, n - 1);

            //int i = tree.GetSumST(st, 0, 0, n - 1, 1, 3);
            //int diff = 10 - arr[1];
            //tree.UpdateST(st, 0, 0, n - 1, 1, diff);

            //int j = tree.GetSumST(st, 0, 0, n - 1, 1, 3);

            //AVLTree tree = new AVLTree();
            //tree.root = tree.Insert(tree.root, 10);
            //tree.root = tree.Insert(tree.root, 20);
            //tree.root = tree.Insert(tree.root, 30);
            //tree.root = tree.Insert(tree.root, 40);
            //tree.root = tree.Insert(tree.root, 50);
            //tree.root = tree.Insert(tree.root, 25);


            //BinarySearch binaryTree = new BinarySearch();
            //int[] arr = { 20, 15, 13, 14, 18, 25, 22, 45, 40 };
            //binaryTree.CreateBinaryTree(arr);
            //  int[] postorder = { 9,15,7,20,3 };
            //// int[] preorder = { 3,9,20,15,7 };
            // int[] inoder = { 9,3,15,20,7 };
            // TreeNode root = binaryTree.buidTreePo(postorder, inoder);

            // binaryTree.postorderTraversal(root);
            //int[] arr = { 1, 2, 3, 4, 5, 6, 6, 6, 6 };
            // BinaryTreeNode node = binaryTree.ConstructBinaryTreeFromArray(arr, binaryTree.root, 0);
            //binaryTree.push(36);
            //binaryTree.push(30);
            //binaryTree.push(25);
            //binaryTree.push(15);
            //binaryTree.push(12);
            //binaryTree.push(10);
            //BinaryTreeNode node = binaryTree.convertList2Binary();
            // binaryTree.inorderTraversal(node);
            //Console.ReadLine();
            // ImplementStackUsingQueue2 objstack = new ImplementStackUsingQueue2();
            // objstack.Push(1);
            // objstack.Push(2);
            // objstack.Push(3);
            //// objstack.Display();
            // objstack.Pop();
            // objstack.Pop();
            // Console.ReadLine();
            //DoubleEndedQueue deq = new DoubleEndedQueue();
            //deq.EnqueFront(2);
            //deq.EnqueFront(5);
            //deq.EnqueRare(-1);
            //deq.EnqueRare(0);
            //deq.EnqueFront(7);
            //deq.EnqueFront(4);
            //deq.PrintFront();
            //deq.PrintRear();
            //deq.Display();
            //deq.DequFront();
            //deq.DequRear();
            //deq.Display();

            ImplementQueueFromArray qal = new ImplementQueueFromArray();
            int i = 0;
            do
            {
                i = Convert.ToInt16(Console.ReadLine());
                switch (i)
                {
                    case 1:
                        qal.EnQue(Convert.ToInt16((Console.ReadLine())));
                        break;
                    case 2:
                        qal.DeQue();
                        break;
                    case 3:
                        qal.Peek();
                        break;
                    case 4:
                        qal.Display();
                        break;
                    case 5:
                        break;
                }
            }
            while (i != 0);
            Console.ReadLine();
            //QueueAlgorithms objque = new QueueAlgorithms();
            //objque.QueueOperation();

            StackAlgorithms sal = new StackAlgorithms();
            Console.Write(sal.findMaxLen("()(()))))"));

            //Stack<int> input = new Stack<int>();
            //input.Push(34);
            //input.Push(3);
            //input.Push(31);
            //input.Push(98);
            //input.Push(92);
            //input.Push(23);
            //sal.DeleteMid(input, input.Count);
            //sal.SortStackRecursion(input);

            //sal.BalancedParanthises("[()]{}}");
            //Console.ReadLine();

            //StackAlgorithms sal = new StackAlgorithms();
            //String s = "(A-B/C)*(A/K-L)";
            //Console.WriteLine(sal.infixToPrefix(s));

            //string exp = "a+b*(c^d-e)^(f+g*h)-i";
            //Console.WriteLine(sal.infixToPostfix(exp));

            //StackUsingLinkedList sull = new StackUsingLinkedList();
            //int i = 0;
            //do
            //{
            //    i = Convert.ToInt16(Console.ReadLine());
            //    switch (i)
            //    {
            //        case 1:
            //            sull.Push(Convert.ToInt16((Console.ReadLine())));
            //            break;
            //        case 2:
            //            sull.Pop();
            //            break;
            //        case 3:
            //            sull.Peek();
            //            break;
            //        case 4:
            //            sull.Display();
            //            break;
            //        case 5:
            //            break;
            //    }
            //}
            //while (i != 0);


            //StackUsingArray sua = new StackUsingArray(3);
            //int i = 0;
            //do
            //{
            //    i = Convert.ToInt16(Console.ReadLine());
            //    switch (i)
            //    {
            //        case 1:
            //            sua.Push();
            //            break;
            //        case 2:
            //            sua.Pop();
            //            break;
            //        case 3:
            //            sua.Peek();
            //            break;
            //        case 4:
            //            sua.Display();
            //            break;
            //        case 5:
            //            break;
            //    }
            //}
            //while (i != 0);


            //StackAlgorithms stckalgo = new StackAlgorithms();
            //stckalgo.StackOperations();


            //SinglyLinkedList objslst = new SinglyLinkedList();
            //SingleLinkedList objlst = new SingleLinkedList();
            //Node objnode = objslst.CreateListedListFormergesort();
            //Node objsorted = objslst.MergeSort(objnode);

            // DoubleCircularLL dcll = new DoubleCircularLL();
            //DoubleCircularLL.Node node = null;

            //node = dcll.InsertEnd(node, 2);
            //node = dcll.InsertEnd(node, 3);

            //node = dcll.InsertBegin(node, 1);
            //node = dcll.InsertAfter(4, 3, node);
            //dcll.Travers(node);

            //node = dcll.deleteNode(node, 1);
            //Console.ReadLine();

            //SinglyCircularLL Scll = new SinglyCircularLL();
            //SinglyCircularLL.Node node = null;
            //node = Scll.InsertEmpty(node, 2);
            //node = Scll.addEnd(node, 3);
            //node = Scll.beginNode(node, 1);
            //node = Scll.InsertAfter(node, 4,3);
            //Scll.Traverse(node);
            //node = Scll.remove(4, node);

            //DLinkedList dlink = new DLinkedList();
            //DoubleLinkedList dblnk = new DoubleLinkedList();

            //dblnk = dlink.CreateDoubleList();
            //dblnk = dlink.InsertFront(dblnk, -1);
            //dlink.InsertLast(dblnk, 444);
            //dlink.DeleteNodebyKey(dblnk, 1);
            //dlink.ReverseLinkedList(dblnk);
            //SinglyLinkedList objslst = new SinglyLinkedList();
            //SingleLinkedList objlst = new SingleLinkedList();
            //objlst = objslst.CreateListedList();
            //objlst = objslst.InserFront(objlst, -1);
            //objlst = objslst.InsertLast(objlst, 4);
            //objslst.DeleteNodebyKeys(objlst, 1);
            //objslst.DeleteByPosition(objlst, 0);
            //objslst.Search(objlst, 6);
            //objslst.FindMid(objlst);
            //objslst.ReverseLinkedList(objlst);
            //Console.ReadLine();

            //  string i = GetSubString(Console.ReadLine());
            //  Console.Write(i);

        }

        public static string GetSubString(string s)
        {
            string sub = "";

            string[] sar = s.Split(' ');
            int mincount = sar[0].ToString().ToCharArray().Length;
            char[] minstring = sar[0].ToString().ToCharArray();
            for (int l = 0; l < sar.Length; l++)
            {
                if (sar[l].ToString().ToCharArray().Length < mincount)
                {
                    mincount = sar[l].ToString().ToCharArray().Length;
                    minstring = sar[l].ToString().ToCharArray();
                }
            }

            int k = 0;
            int i = 0;
            foreach (char item in minstring)
            {

                for (i = 0; i < sar.Length; i++)
                {
                    if (item == Convert.ToChar(sar[i].ToString().ToCharArray()[k]))
                    {
                    }
                    else
                    {
                        return sub = sar[0].ToString().Substring(0, k);
                    }
                }
                k = k + 1;


            }

            return sar[0].ToString().Substring(0, k);
        }
    }
}
