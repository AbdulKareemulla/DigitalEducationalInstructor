﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logical
{
    public class StackAlgorithms
    {
        public void StackOperations()
        {
            Stack stack = new Stack();
            stack.Push("1st Element");
            stack.Push("2nd Element");
            Console.WriteLine(stack.Count);
            Console.WriteLine(stack.Peek());
            Console.WriteLine(stack.Pop());
            Console.WriteLine(stack.Pop());

            foreach (var i in stack)
            {
                Console.WriteLine(i);

            }
        }

        public bool IsMatching(char a, char b)
        {
            if (a == '(' && b == ')')
                return true;

            if (a == '{' && b == '}')
                return true;


            if (a == '[' && b == ']')
                return true;

            return false;
        }

        public bool BalancedParanthises(string balpara)
        {
            Stack<char> st = new Stack<char>();
            foreach (char c in balpara)
            {
                if (c == '(' || c == '{' || c == '[')
                {
                    st.Push(c);
                }
                if (c == ')' || c == '}' || c == ']')
                {
                    if (st.Count == 0)
                    {
                        return false;
                    }
                    if (!IsMatching(st.Pop(), c))
                    {
                        return false;
                    }
                }
            }

            if (st.Count > 0)
            {
                Console.WriteLine("Not balanced");
                return false;
            }
            else
            {
                Console.WriteLine("Balanced");
                return true;
            }
        }

        public Stack<int> sortstack(Stack<int> input)
        {
            Stack<int> tmpst = new Stack<int>();

            while (input.Count != 0)
            {
                int k = input.Pop();

                while (tmpst.Count > 0 && tmpst.Peek() < k)
                {
                    input.Push(tmpst.Pop());
                }
                tmpst.Push(k);
            }

            return tmpst;
        }

        public void SortStackRecursion(Stack<int> st)
        {
            if (st.Count == 0)
            {
                return;
            }
            int tmp = st.Pop();
            SortStackRecursion(st);
            InsertAtCorrectPosition(st, tmp);
        }
        public void InsertAtCorrectPosition(Stack<int> st, int temp)
        {
            if (st.Count == 0 || st.Peek() < temp)
            {
                st.Push(temp);
                return;
            }
            int ele = st.Pop();
            InsertAtCorrectPosition(st, temp);
            st.Push(ele);
        }

        public void DeleteMid(Stack<int> st, int n, int curr = 0)
        {
            if (st.Count == 0 || curr == n)
            {
                return;
            }

            int temp = st.Pop();
            DeleteMid(st, n, curr + 1);

            if (curr != n / 2)
            {
                st.Push(temp);
            }


        }

        //Find maxmium valid len
        public int findMaxLen(string str)
        {
            int result = 0;
            Stack<int> st = new Stack<int>();
            st.Push(-1);
            for (int i = 0; i < str.Length; i++)
            {
                if (str[i] == '(')
                {
                    st.Push(i);
                }
                else
                {
                    st.Pop();
                    if (st.Count > 0)
                    {
                        result = Math.Max(result, i - st.Peek());
                    }
                    else
                    {
                        st.Push(i);
                    }
                }
            }
            return result;
        }
    }

    public class StackUsingArray
    {
        int n, top;
        int[] ar;
        public StackUsingArray(int num)
        {
            n = num;
            top = -1;
            ar = new int[num];
        }

        public void Push()
        {
            Console.WriteLine("Enter data to Push");
            int data = Convert.ToInt16(Console.ReadLine());
            if (top == n - 1)
            {
                Console.WriteLine("Overflow");
            }
            else
            {
                top++;
                ar[top] = data;
            }
        }

        public void Pop()
        {
            if (top == -1)
            {
                Console.WriteLine(" Empty");
            }
            else
            {
                ar[top--] = 0;
            }

        }

        public void Peek()
        {
            if (top == -1)
            {
                Console.WriteLine("Empty");
            }
            else
            {
                Console.WriteLine(ar[top]);
            }
        }

        public void Display()
        {
            for (int i = top; i >= 0; i--)
            {
                Console.WriteLine(ar[i]);
            }
        }
    }

    public class StackUsingLinkedList
    {
        public class Node
        {
            public int data;
            public Node Next;
        }

        public Node top;

        public StackUsingLinkedList()
        {
            this.top = null;
        }


        public void Push(int d)
        {
            Node node = new Node();
            if (node == null)
            {
                Console.WriteLine("Overflow");
                return;
            }
            node.data = d;
            node.Next = top;
            top = node;
        }

        public void Pop()
        {

            if (top == null)
            {
                Console.WriteLine("Empty");
                return;
            }
            top = top.Next;
        }

        public void Peek()
        {
            if (top == null)
            {
                Console.WriteLine("Empty");
                return;
            }

            Console.Write(top.data);
        }

        public void Display()
        {
            Node temp = top;
            while (temp != null)
            {
                Console.WriteLine(temp.data);
                temp = temp.Next;

            }
        }
    }
}
