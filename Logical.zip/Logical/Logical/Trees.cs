﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logical
{
    public class LinkListNode
    {
        public int data { get; set; }
        public LinkListNode lstnode;
        public LinkListNode(int d)
        {
            data = d;
            lstnode = null;
        }
    }

    public class BinaryTreeNode
    {
        public int data { get; set; }
        public BinaryTreeNode leftnode;
        public BinaryTreeNode rightnode;
        public BinaryTreeNode(int d)
        {
            data = d;
            leftnode = null;
            rightnode = null;
        }


    }

    public class BinaryTree
    {
        public LinkListNode head;
        public BinaryTreeNode root;
        public void push(int listdata)
        {
            LinkListNode lk = new LinkListNode(listdata);
            lk.lstnode = head;
            head = lk;
        }

        public BinaryTreeNode convertList2Binary()
        {
            BinaryTreeNode node;
            Queue<BinaryTreeNode> que = new Queue<BinaryTreeNode>();
            if (head == null)
            {
                node = null;
                return node;
            }
            node = new BinaryTreeNode(head.data);

            head = head.lstnode;
            que.Enqueue(node);
            while (head != null)
            {
                BinaryTreeNode parent = que.Dequeue();

                BinaryTreeNode leftnode, rightnode = null;

                leftnode = new BinaryTreeNode(head.data);
                que.Enqueue(leftnode);
                head = head.lstnode;
                if (head != null)
                {
                    rightnode = new BinaryTreeNode(head.data);
                    que.Enqueue(rightnode);
                    head = head.lstnode;
                }

                parent.leftnode = leftnode;
                parent.rightnode = rightnode;
            }


            return node;
        }

        public void inorderTraversal(BinaryTreeNode node)
        {
            if (node != null)
            {
                inorderTraversal(node.leftnode);
                Console.WriteLine(node.data);
                inorderTraversal(node.rightnode);
            }
        }

        public BinaryTreeNode ConstructBinaryTreeFromArray(int[] arr, BinaryTreeNode root, int i)
        {
            if (i < arr.Length)
            {
                root = new BinaryTreeNode(arr[i]);
                root.leftnode = ConstructBinaryTreeFromArray(arr, root.leftnode, (2 * i + 1));
                root.rightnode = ConstructBinaryTreeFromArray(arr, root.rightnode, (2 * i + 2));
            }
            return root;
        }



    }
}