﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logical
{
    internal class DoubleLinkedList
    {
        internal DNode head;
    }

    internal class DNode
    {
        internal int data;
        internal DNode next;
        internal DNode prev;
        internal DNode(int d)
        {
            data = d;
            next = null;
            prev = null;
        }
    }

    internal class DLinkedList
    {

        public DoubleLinkedList CreateDoubleList()
        {
            DoubleLinkedList doubleLinkedList = new DoubleLinkedList();

            DNode node0 = new DNode(0);
            DNode node1 = new DNode(1);
            DNode node3 = new DNode(3);

            node3.prev = node1;
            node3.next = null;

            node1.prev = node0;
            node1.next = node3;

           
            node0.prev = null;
            node0.next = node1;

            doubleLinkedList.head = node0;

            InsertAfter(node1, 2);
           // InsertBefore(node3, 78);
            
            return doubleLinkedList;
        }
        #region Insert_into_DoubleLinkedList
        public DoubleLinkedList InsertFront(DoubleLinkedList doubleLinkedList, int data)
        {
            DNode newnode = new DNode(data);
            newnode.next = doubleLinkedList.head;
            newnode.prev = null;

            if (doubleLinkedList.head != null)
            {
                doubleLinkedList.head.prev = newnode;
            }

            doubleLinkedList.head = newnode;

            return doubleLinkedList;
        }

        internal void InsertAfter(DNode prev_node, int data)
        {
            DNode newnode =new DNode(data);
            newnode.next = prev_node.next;
            newnode.prev = prev_node;

            prev_node.next = newnode;

            if (newnode.next != null)
            {
                newnode.next.prev = newnode;
            }

        }

        internal void InsertBefore(DNode next_node, int data)
        {
            DNode newnode = new DNode(data);
            newnode.next = next_node;
            newnode.prev = next_node.prev;

            next_node.prev = newnode;

            if (newnode.prev != null)
            {
                newnode.prev.next = newnode;
            }


        }

        internal void InsertLast(DoubleLinkedList doubleLinkedList, int data)
        {
            DNode temp = doubleLinkedList.head;
            DNode lastnode = null;

            while (temp!=null) {
                lastnode = temp;
                temp = temp.next;
            }

            DNode newnode = new DNode(data);
            if (doubleLinkedList.head == null)
            {
                newnode.prev = null;
                doubleLinkedList.head = newnode;
                return;
            }
           
            newnode.next = null;
            newnode.prev = lastnode;

            lastnode.next = newnode;
        }

        #endregion Insert_into_DoubleLinkedList


        internal void DeleteNodebyKey(DoubleLinkedList doubleLinkedList, int key)
        {
            DNode temp = doubleLinkedList.head;

            if (temp != null && temp.data == key)
            {
                doubleLinkedList.head = temp.next;
                doubleLinkedList.head.prev = null;
                return;
            }

            while (temp != null && temp.data!=key)
            {
                temp = temp.next;
            }

            if (temp == null)
            {
                return;
            }

            if (temp.next != null)
            {
                temp.next.prev = temp.prev;
            }

            if (temp.prev != null)
            {
                temp.prev.next = temp.next;
            }

        }
        internal void ReverseLinkedList(DoubleLinkedList doubleLinkedList)
        {
            DNode temp = null;
            DNode current = doubleLinkedList.head;

            /* swap next and prev for all nodes of doubly linked list */
            while (current != null)
            {
                temp = current.prev;
                current.prev = current.next;
                current.next = temp;
                current = current.prev;
            }
            if (temp != null)
            {
                doubleLinkedList.head = temp.prev;
            }
        }

    }
}
