﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logical
{
    public class DynamicProgramming
    {
        static int[,] memorize;
        public DynamicProgramming(int n, int w)
        {
            memorize = new int[n + 1, w + 1];
        }

        public DynamicProgramming()
        {
        }
        public int Knapsack(int[] val, int[] wt, int w, int n)
        {
            if (n == 0 || w == 0)
                return 0;
            if (w >= wt[n - 1])
                return Math.Max(val[n - 1] + Knapsack(val, wt, w - wt[n - 1], n - 1), Knapsack(val, wt, w, n - 1));

            else
                return Knapsack(val, wt, w, n - 1);

        }

        public int KnapsackMemorize(int[] val, int[] wt, int w, int n)
        {
            if (n == 0 || w == 0)
                return 0;

            if (memorize[n, w] != 0)
                return memorize[n, w];

            if (w >= wt[n - 1])
                return memorize[n, w] = Math.Max(val[n - 1] + Knapsack(val, wt, w - wt[n - 1], n - 1), Knapsack(val, wt, w, n - 1));

            else
                return memorize[n, w] = Knapsack(val, wt, w, n - 1);
            //if (w < wt[n - 1])
            //    return memorize[n, w] = KnapsackMemorize(val, wt, w, n - 1);

            //else
            //    return memorize[n, w] = Math.Max(val[n - 1] + KnapsackMemorize(val, wt, w - wt[n - 1], n - 1), KnapsackMemorize(val, wt, w, n - 1));

        }

        public int KnapsackTopDown(int[] val, int[] wt, int w, int n)
        {

            int[,] graph = new int[n + 1, w + 1];

            for (int i = 0; i < n + 1; i++)
            {
                for (int j = 0; j < w + 1; j++)
                {
                    if (i == 0 || j == 0)
                    {
                        graph[n, w] = 0;
                    }
                }
            }

            for (int i = 1; i < n + 1; i++)
            {
                for (int j = 1; j < w + 1; j++)
                {
                    if (j >= wt[i - 1])
                    {
                        graph[i, j] = Math.Max(val[i - 1] + graph[i - 1, j - wt[i - 1]], graph[i - 1, j]);
                    }
                    else
                    {
                        graph[i, j] = graph[i - 1, j];
                    }
                }
            }

            return graph[n, w];


        }

        public bool KnapsackSumSubset(int[] arr, int w, int n)
        {

            bool[,] graph = new bool[n + 1, w + 1];



            for (int j = 0; j < w + 1; j++)
            {
                graph[0, j] = false;
            }

            for (int i = 0; i < n + 1; i++)
            {
                graph[i, 0] = true;
            }

            for (int i = 1; i < n + 1; i++)
            {
                for (int j = 1; j < w + 1; j++)
                {
                    if (j >= arr[i - 1])
                    {
                        graph[i, j] = graph[i - 1, j - arr[i - 1]] || graph[i - 1, j];
                    }
                    else
                    {
                        graph[i, j] = graph[i - 1, j];
                    }
                }
            }

            return graph[n, w];


        }

        public bool KnapsackEqualSumSubset(int[] arr)
        {
            int sum = 0;

            for (int i = 0; i < arr.Length; i++)
            {
                sum += arr[i];
            }

            if (sum % 2 != 0)
            {
                return false;
            }
            else
            {
                return KnapsackSumSubset(arr, sum / 2, arr.Length);
            }
        }

        public int KnapsackCountSumSubset(int[] arr, int w, int n)
        {
            int[,] graph = new int[n + 1, w + 1];
            for (int j = 0; j < w + 1; j++)
            {
                graph[0, j] = 0;
            }
            for (int i = 0; i < n + 1; i++)
            {
                graph[i, 0] = 1;
            }
            for (int i = 1; i < n + 1; i++)
            {
                for (int j = 1; j < w + 1; j++)
                {
                    if (j >= arr[i - 1])
                    {
                        graph[i, j] = graph[i - 1, j - arr[i - 1]] + graph[i - 1, j];
                    }
                    else
                    {
                        graph[i, j] = graph[i - 1, j];
                    }
                }
            }
            return graph[n, w];
        }

        public class KnapsackMinimumSubset
        {
            public bool[,] KnapsackSumSubset(int[] arr, int w, int n)
            {

                bool[,] graph = new bool[n + 1, w + 1];



                for (int j = 0; j < w + 1; j++)
                {
                    graph[0, j] = false;
                }

                for (int i = 0; i < n + 1; i++)
                {
                    graph[i, 0] = true;
                }

                for (int i = 1; i < n + 1; i++)
                {
                    for (int j = 1; j < w + 1; j++)
                    {
                        if (j >= arr[i - 1])
                        {
                            graph[i, j] = graph[i - 1, j - arr[i - 1]] || graph[i - 1, j];
                        }
                        else
                        {
                            graph[i, j] = graph[i - 1, j];
                        }
                    }
                }

                return graph;


            }

            public int KnapsackminimumSubset(int[] arr)
            {
                int sum = 0;
                for (int i = 0; i < arr.Length; i++)
                {
                    sum += arr[i];
                }
                bool[,] graph = KnapsackSumSubset(arr, sum, arr.Length);

                int min = int.MaxValue;

                for (int j = sum / 2; j >= 0; j--)
                {
                    if (graph[arr.Length, j] == true)
                    {
                        min = Math.Min(min, sum - 2 * j);

                    }
                }
                return min;
            }
        }

        public int CountSubSetWithDifference(int[] arr, int diff)
        {
            int sum = 0;
            for (int i = 0; i < arr.Length; i++)
            {
                sum += arr[i];
            }

            int sum1 = (diff + sum) / 2;

            return KnapsackCountSumSubset(arr, sum1, arr.Length);
        }

        /* Rod cutting is same as
             UnBounded Knapsack */

        public int UnboundKnapsack(int[] val, int[] wt, int w, int n)
        {
            int[,] graph = new int[n + 1, w + 1];

            for (int i = 0; i < n + 1; i++)
            {
                for (int j = 0; j < w + 1; j++)
                {
                    if (i == 0 || j == 0)
                    {
                        graph[n, w] = 0;
                    }
                }
            }

            for (int i = 1; i < n + 1; i++)
            {
                for (int j = 1; j < w + 1; j++)
                {
                    if (j >= wt[i - 1])
                    {
                        graph[i, j] = Math.Max(val[i - 1] + graph[i, j - wt[i - 1]], graph[i - 1, j]);
                    }
                    else
                    {
                        graph[i, j] = graph[i - 1, j];
                    }
                }
            }

            return graph[n, w];

        }

        public int CountWaysforCoinChange(int[] coins, int sum)
        {
            int[,] graph = new int[coins.Length + 1, sum + 1];

            for (int i = 0; i < sum + 1; i++)
            {
                graph[0, i] = 0;
            }

            for (int i = 0; i < coins.Length + 1; i++)
            {
                graph[i, 0] = 1;
            }

            for (int i = 1; i < coins.Length + 1; i++)
            {
                for (int j = 1; j < sum + 1; j++)
                {

                    if (j >= coins[i - 1])
                    {
                        graph[i, j] = (graph[i, j - coins[i - 1]] + graph[i - 1, j]);
                    }
                    else
                    {
                        graph[i, j] = graph[i - 1, j];
                    }
                }
            }

            return graph[coins.Length, sum];
        }


        public static void MinimumCoins(int[] coins, int sum, int n)
        {
            int[,] dp = new int[n + 1, sum + 1];
            for (int i = 0; i < sum + 1; i++)
            {
                dp[0, i] = int.MaxValue - 1;
            }
            for (int i = 0; i < n + 1; i++)
            {
                dp[i, 0] = 0;
            }

            for (int i = 1; i < sum + 1; i++)
            {
                if (i % coins[0] == 0)
                {
                    dp[1, i] = i / coins[0];
                }
                else
                {
                    dp[1, i] = int.MaxValue - 1;
                }
            }

            for (int i = 2; i < n + 1; i++)
            {
                for (int j = 1; j < sum + 1; j++)
                {
                    if (j >= coins[i - 1])
                    {
                        dp[i, j] = Math.Min(1 + dp[i, j - coins[i - 1]], dp[i - 1, j]);
                    }
                    else
                    {
                        dp[i, j] = dp[i - 1, j];
                    }
                }
            }

            Console.WriteLine("Minimum Coins : " + dp[n, sum]);
        }
        //public int MinimumCoinCount(int[] coins, int sum)
        //{
        //    int[,] graph = new int[coins.Length + 1, sum + 1];
        //    int maxvalue = int.MaxValue - 1;

        //    for (int i = 0; i < sum + 1; i++)
        //    {
        //        graph[0, i] = maxvalue;
        //    }

        //    for (int i = 1; i < coins.Length + 1; i++)
        //    {
        //        graph[i, 0] = 0;
        //    }

        //    for (int i = 1; i < coins.Length + 1; i++)
        //    {
        //        for (int j = 1; j < sum + 1; j++)
        //        {
        //            if (j >= coins[i - 1])
        //            {
        //                graph[i, j] = Math.Min(1 + graph[i, j - coins[i - 1]], graph[i - 1, j]);
        //            }
        //            else
        //            {
        //                graph[i, j] = graph[i - 1, j];
        //            }
        //        }
        //    }

        //    return graph[coins.Length, sum];
        //}

        /// <summary>
        /// //////////////////////////////////////////////////LCS
        /// </summary>
        public int LargestCommonSubSequence(char[] x, char[] y, int m, int n)
        {
            if (m == 0 || n == 0)
            {
                return 0;
            }

            if (x[m - 1] == y[n - 1])
            {
                return 1 + LargestCommonSubSequence(x, y, m - 1, n - 1);
            }
            else
            {
                return Math.Max(LargestCommonSubSequence(x, y, m, n - 1),
                    LargestCommonSubSequence(x, y, m - 1, n));

            }
        }

        int[,] graph;

        public void DynamicProgrammingLCSMemoization(int m, int n)
        {
            graph = new int[m + 1, n + 1];
        }
        public int LargestCommonSubsequencemoization(char[] x, char[] y, int m, int n)
        {
            if (m == 0 || n == 0)
            {
                return 0;
            }

            if (graph[m, n] != 0)
            {
                return graph[m, n];
            }
            if (x[m - 1] == y[n - 1])
            {
                return graph[m, n] = 1 + LargestCommonSubsequencemoization(x, y, m - 1, n - 1);
            }
            else
            {
                return graph[m, n] = Math.Max(LargestCommonSubsequencemoization(x, y, m - 1, n), LargestCommonSubsequencemoization(x, y, m, n - 1));
            }

        }

        public int LargestCommonSubsequenceTopDown(char[] x, char[] y, int m, int n)
        {
            int[,] graph = new int[m + 1, n + 1];
            for (int i = 0; i < m + 1; i++)
            {
                graph[i, 0] = 0;
            }

            for (int j = 0; j < n + 1; j++)
            {
                graph[0, j] = 0;
            }


            for (int i = 1; i < m + 1; i++)
            {
                for (int j = 1; j < n + 1; j++)
                {
                    if (x[i - 1] == y[j - 1])
                    {
                        graph[i, j] = 1 + graph[i - 1, j - 1];
                    }
                    else
                    {
                        graph[i, j] = Math.Max(graph[i, j - 1], graph[i - 1, j]);
                    }
                }
            }
            return graph[m, n];
        }

        public int LargestCommonSubString(char[] x, char[] y, int m, int n)
        {
            int[,] graph = new int[m + 1, n + 1];

            for (int i = 0; i < m + 1; i++)
            {
                graph[i, 0] = 0;
            }

            for (int j = 0; j < n + 1; j++)
            {
                graph[0, j] = 0;
            }

            for (int i = 1; i < m + 1; i++)
            {
                for (int j = 1; j < n + 1; j++)
                {
                    if (x[i - 1] == y[j - 1])
                    {
                        graph[i, j] = 1 + graph[i - 1, j - 1];
                    }
                    else
                    {
                        graph[i, j] = 0;
                    }
                }
            }

            return graph[m, n];
        }

        public class PrintCommonSubSequence
        {
            public int[,] LargestCommonSubsequence(char[] x, char[] y, int m, int n)
            {
                int[,] graph = new int[m + 1, n + 1];
                for (int i = 0; i < m + 1; i++)
                {
                    graph[i, 0] = 0;
                }

                for (int j = 0; j < n + 1; j++)
                {
                    graph[0, j] = 0;
                }


                for (int i = 1; i < m + 1; i++)
                {
                    for (int j = 1; j < n + 1; j++)
                    {
                        if (x[i - 1] == y[j - 1])
                        {
                            graph[i, j] = 1 + graph[i - 1, j - 1];
                        }
                        else
                        {
                            graph[i, j] = Math.Max(graph[i, j - 1], graph[i - 1, j]);
                        }
                    }
                }
                return graph;
            }

            public string PrintLargestCommonSubsequence(char[] x, char[] y, int m, int n)
            {
                string commonsubsequencestring = "";

                int[,] graph = LargestCommonSubsequence(x, y, m, n);

                int i = m, j = n;
                while (i != 0 && j != 0)
                {
                    if (x[i - 1] == y[j - 1])
                    {
                        commonsubsequencestring = x[i - 1] + commonsubsequencestring;
                        i--;
                        j--;
                    }
                    else
                    {
                        if (graph[i, j - 1] > graph[i - 1, j])
                        {
                            j--;
                        }
                        else
                        {
                            i--;
                        }
                    }
                }
                return commonsubsequencestring;
            }
        }

        public class PrintCommonSubstring
        {
            public int[,] LargestCommonSubString(char[] x, char[] y, int m, int n)
            {
                int[,] graph = new int[m + 1, n + 1];

                for (int i = 0; i < m + 1; i++)
                {
                    graph[i, 0] = 0;
                }

                for (int j = 0; j < n + 1; j++)
                {
                    graph[0, j] = 0;
                }

                for (int i = 1; i < m + 1; i++)
                {
                    for (int j = 1; j < n + 1; j++)
                    {
                        if (x[i - 1] == y[j - 1])
                        {
                            graph[i, j] = 1 + graph[i - 1, j - 1];
                        }
                        else
                        {
                            graph[i, j] = 0;
                        }
                    }
                }

                return graph;
            }
            public void PrintLargestCommonSubString(char[] x, char[] y, int m, int n)
            {

                int[,] L = LargestCommonSubString(x, y, m, n);
                int i = m, j = n;
                String resultStr = "";

                while (L[i, j] != 0)
                {
                    resultStr = x[i - 1] + resultStr;
                    i--;
                    j--;
                }
                Console.WriteLine(resultStr);
            }
        }

        public string findstem(String[] arr)
        {
            int n = arr.Length;
            String s = arr[0];
            int len = s.Length;

            String res = "";

            for (int i = 0; i < len; i++)
            {
                for (int j = i + 1; j <= len; j++)
                {

                    String stem = s.Substring(i, j - i);
                    int k = 1;
                    for (k = 1; k < n; k++)

                        if (!arr[k].Contains(stem))
                            break;

                    if (k == n && res.Length < stem.Length)
                        res = stem;
                }
            }

            return res;
        }

        public int ShortestCommonSubsequence(char[] x, char[] y, int m, int n)
        {
            int lcs = LargestCommonSubsequenceTopDown(x, y, m, n);
            return m + n - lcs;

        }

        public void MinimumInsertionDeletionConvertionAtoB(char[] x, char[] y, int m, int n)
        {
            int lcs = LargestCommonSubsequenceTopDown(x, y, m, n);
            int mindel = m - lcs;
            int mininsert = n - lcs;

            Console.WriteLine("Minimum deletion : " + mindel + " and Insertion : " + mininsert);
        }

        public int LargestPalindromFromString(string a)
        {

            char[] charArray = a.ToCharArray();
            Array.Reverse(charArray);

            return LargestCommonSubSequence(a.ToCharArray(), charArray, a.ToCharArray().Length, charArray.Length);
        }

        public int MinimumDeletionForPalindrom(string a)
        {
            int lps = LargestPalindromFromString(a);
            return a.Length - lps;
        }

        public int MinimumInsertionForPalindrom(string a)
        {
            int lps = LargestPalindromFromString(a);
            return a.Length - lps;
        }

        public class PrintShortestCommonSubSequence
        {

            public int[,] LargestCommonSubsequenceTopDown(char[] x, char[] y, int m, int n)
            {
                int[,] graph = new int[m + 1, n + 1];
                for (int i = 0; i < m + 1; i++)
                {
                    graph[i, 0] = 0;
                }

                for (int j = 0; j < n + 1; j++)
                {
                    graph[0, j] = 0;
                }


                for (int i = 1; i < m + 1; i++)
                {
                    for (int j = 1; j < n + 1; j++)
                    {
                        if (x[i - 1] == y[j - 1])
                        {
                            graph[i, j] = 1 + graph[i - 1, j - 1];
                        }
                        else
                        {
                            graph[i, j] = Math.Max(graph[i, j - 1], graph[i - 1, j]);
                        }
                    }
                }
                return graph;
            }

            public string PrintShortestSubSequece(char[] x, char[] y, int m, int n)
            {
                int[,] graph = LargestCommonSubsequenceTopDown(x, y, m, n);
                int i = m, j = n;
                string commonsubsequencestring = "";
                while (i != 0 && j != 0)
                {
                    if (x[i - 1] == y[j - 1])
                    {
                        commonsubsequencestring = x[i - 1] + commonsubsequencestring;
                        i--;
                        j--;
                    }
                    else
                    {
                        if (graph[i, j - 1] > graph[i - 1, j])
                        {
                            commonsubsequencestring = y[j - 1] + commonsubsequencestring;
                            j--;
                        }
                        else
                        {
                            commonsubsequencestring = x[i - 1] + commonsubsequencestring;
                            i--;
                        }
                    }
                }
                while (i > 0)
                {
                    commonsubsequencestring = x[i - 1] + commonsubsequencestring;
                    i--;
                }

                while (j > 0)
                {
                    commonsubsequencestring = y[j - 1] + commonsubsequencestring;
                    j--;
                }

                return commonsubsequencestring;
            }

        }

        public int LogestRepeatingSubSequence(char[] x, char[] y, int m, int n)
        {
            int[,] graph = new int[m + 1, n + 1];
            for (int i = 0; i < m + 1; i++)
            {
                graph[i, 0] = 0;
            }

            for (int j = 0; j < n + 1; j++)
            {
                graph[0, j] = 0;
            }


            for (int i = 1; i < m + 1; i++)
            {
                for (int j = 1; j < n + 1; j++)
                {
                    if (x[i - 1] == y[j - 1] && i != j)
                    {
                        graph[i, j] = 1 + graph[i - 1, j - 1];
                    }
                    else
                    {
                        graph[i, j] = Math.Max(graph[i, j - 1], graph[i - 1, j]);
                    }
                }
            }
            return graph[m, n];
        }

        public bool SequencePatternMatching(char[] x, char[] y, int m, int n)
        {
            int lcs = LargestCommonSubsequenceTopDown(x, y, m, n);
            if (lcs == m)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public int MatrixChainMultiplication(int[] arr, int i, int j)
        {
            if (i >= j)
                return 0;
            int min = int.MaxValue;
            for (int k = i; k <= j - 1; k++)
            {
                int temp = MatrixChainMultiplication(arr, i, k) + MatrixChainMultiplication(arr, k + 1, j)
                    + arr[i - 1] * arr[k] * arr[j];

                if (min > temp)
                {
                    min = temp;
                }
            }
            return min;
        }

        public int EvaluateExpression(string str, int i, int j, bool isTrue)
        {
            int ans = 0;
            if (i > j)
                return 0;
            if (i == j)
            {
                if (isTrue)
                {
                    if (str[i] == 'T')
                    {
                        return 1;
                    }
                    else
                    {
                        return 0;
                    }
                }
                else
                {
                    if (str[i] == 'F')
                    {
                        return 1;
                    }
                    else
                    {
                        return 0;
                    }
                }
            }

            for (int k = i + 1; k <= j; k = k + 2)
            {
                int lt = EvaluateExpression(str, i, k - 1, true);
                int lf = EvaluateExpression(str, i, k - 1, false);

                int rt = EvaluateExpression(str, k + 1, j, true);
                int rf = EvaluateExpression(str, k + 1, j, false);

                if (str[k] == '&')
                {
                    if (isTrue)
                    {
                        ans = ans + (lt * rt);
                    }
                    else
                    {
                        ans = ans + (lf * rt) + (lt * rf) + (lf * rf);
                    }
                }
                else if (str[k] == '|')
                {
                    if (isTrue)
                    {
                        ans = ans + (lt * rt) + (lf * rt) + (lt * rf);
                    }
                    else
                    {
                        ans = ans + (lf * rf);
                    }
                }
                else if (str[k] == '^')
                {
                    if (isTrue)
                    {
                        ans = ans + (lf * rt) + (lt * rf);
                    }
                    else
                    {
                        ans = ans + (lt * rt) + (lf * rf);
                    }
                }
            }

            return ans;
        }

        int[,,] dp = new int[1001, 1001, 2];

        public void Forloop(int m, int n, int o)
        {
            for (int i = 0; i < m; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    for (int k = 0; k < o; k++)
                    {
                        dp[i, j, k] = -1;
                    }
                }
            }
        }

        public void Forloop(int m, int n)
        {
            graph = new int[m, n];
            for (int i = 0; i < m; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    graph[i, j] = -1;
                }
            }
        }
        public int EvaluateExpressionMemoize(string str, int i, int j, int isTrue)
        {
            int ans = 0;
            if (i > j)
                return 0;
            if (i == j)
            {
                if (isTrue == 1)
                {
                    if (str[i] == 'T')
                    {
                        return 1;
                    }
                    else
                    {
                        return 0;
                    }
                }
                else
                {
                    if (str[i] == 'F')
                    {
                        return 1;
                    }
                    else
                    {
                        return 0;
                    }
                }
            }

            if (dp[i, j, isTrue] != -1)
                return dp[i, j, isTrue];

            for (int k = i + 1; k <= j; k = k + 2)
            {
                int lf, lt, rt, rf;
                //int lt = EvaluateExpressionMemoize(str, i, k - 1, 1);
                //int lf = EvaluateExpressionMemoize(str, i, k - 1, 0);
                //int rt = EvaluateExpressionMemoize(str, k + 1, j, 1);
                //int rf = EvaluateExpressionMemoize(str, k + 1, j, 0);

                if (dp[i, k - 1, 1] == -1)
                {
                    lt = EvaluateExpressionMemoize(str, i, k - 1, 1);
                }
                else
                {
                    lt = dp[i, k - 1, 1];
                }

                if (dp[k + 1, j, 1] == -1)
                {
                    rt = EvaluateExpressionMemoize(str, k + 1, j, 1);
                }
                else
                {
                    rt = dp[k + 1, j, 1];
                }

                if (dp[i, k - 1, 0] == -1)
                {
                    lf = EvaluateExpressionMemoize(str, i, k - 1, 0);
                }
                else
                {
                    lf = dp[i, k - 1, 0];
                }

                if (dp[k + 1, j, 0] == -1)
                {
                    rf = EvaluateExpressionMemoize(str, k + 1, j, 0);
                }
                else
                {
                    rf = dp[k + 1, j, 0];
                }

                if (str[k] == '&')
                {
                    if (isTrue == 1)
                    {
                        ans = ans + (lt * rt);
                    }
                    else
                    {
                        ans = ans + (lf * rt) + (lt * rf) + (lf * rf);
                    }
                }
                else if (str[k] == '|')
                {
                    if (isTrue == 1)
                    {
                        ans = ans + (lt * rt) + (lf * rt) + (lt * rf);
                    }
                    else
                    {
                        ans = ans + (lf * rf);
                    }
                }
                else if (str[k] == '^')
                {
                    if (isTrue == 1)
                    {
                        ans = ans + (lf * rt) + (lt * rf);
                    }
                    else
                    {
                        ans = ans + (lt * rt) + (lf * rf);
                    }
                }
                dp[i, j, isTrue] = ans;
            }

            return ans;
        }

        public bool ScrumbleString(string a, string b)
        {
            if (string.Compare(a, b) == 0)
            {
                return true;
            }
            if (a.Length <= 1)
            {
                return false;
            }
            int n = a.Length;
            bool flag = false;
            for (int i = 1; i < n - 1; i++)
            {
                bool cond1 = ScrumbleString(a.Substring(0, i), b.Substring(n - i, i)) == true &&
                    (ScrumbleString(a.Substring(i, n - i), b.Substring(0, n - i)) == true);

                bool cond2 = (ScrumbleString(a.Substring(0, i), b.Substring(0, i)) == true &&
                    (ScrumbleString(a.Substring(i, n - i), b.Substring(i, n - i))) == true);

                if (cond1 || cond2)
                {
                    flag = true;
                    break;
                }
            }
            return flag;
        }


        Dictionary<String, Boolean> cache = new Dictionary<String, Boolean>();
        public bool ScrumbleStringMemoize(string a, string b)
        {
            if (string.Compare(a, b) == 0)
            {
                return true;
            }
            if (a.Length <= 1)
            {
                return false;
            }

            String cacheKey = a + " " + b;
            if (cache.ContainsKey(cacheKey))
                return cache[cacheKey];

            int n = a.Length;
            bool flag = false;
            for (int i = 1; i < n - 1; i++)
            {
                bool cond1 = ScrumbleStringMemoize(a.Substring(0, i), b.Substring(n - i, i)) == true &&
                    (ScrumbleStringMemoize(a.Substring(i, n - i), b.Substring(0, n - i)) == true);

                bool cond2 = (ScrumbleStringMemoize(a.Substring(0, i), b.Substring(0, i)) == true &&
                    (ScrumbleStringMemoize(a.Substring(i, n - i), b.Substring(i, n - i))) == true);

                if (cond1 || cond2)
                {
                    flag = true;
                    break;
                }
            }
            cache.Add(cacheKey, flag);
            return flag;
        }

        public int EggDropping(int egg, int floor)
        {
            if (floor == 0 || floor == 1)
                return floor;

            if (egg == 1)
            {
                return floor;
            }

            int min = int.MaxValue;
            for (int k = 1; k <= floor; k++)
            {
                int temp = 1 + Math.Max(EggDropping(egg - 1, k - 1), EggDropping(egg, floor - k));
                min = Math.Min(min, temp);
            }

            return min;
        }

        public int EggDroppingMemoize(int egg, int floor)
        {
            if (floor == 0 || floor == 1)
                return floor;

            if (egg == 1)
            {
                return floor;
            }

            if (graph[egg, floor] != -1)
                return graph[egg, floor];

            int min = int.MaxValue;
            for (int k = 1; k <= floor; k++)
            {
                int temp = 1 + Math.Max(EggDropping(egg - 1, k - 1), EggDropping(egg, floor - k));
                min = Math.Min(min, temp);
            }

            return graph[egg, floor] = min;
        }

        public class TreesDP
        {

            public int data;
            public TreesDP left;
            public TreesDP right;

            public class min
            {
                public int value = int.MinValue;
            }
            public TreesDP(int d)
            {
                data = d;
                left = null;
                right = null;
            }

            public int Diameter(TreesDP root, min res)
            {
                if (root == null)
                    return 0;

                int l = Diameter(root.left, res);
                int r = Diameter(root.right, res);

                int tem = Math.Max(l, r) + 1;
                int ans1 = Math.Max(tem, l + r + 1);
                res.value = Math.Max(res.value, ans1);

                return tem;
            }

            public int PathSum(TreesDP root, min min)
            {
                if (root == null)
                    return 0;

                int l = PathSum(root.left, min);
                int r = PathSum(root.right, min);

                int temp = Math.Max(Math.Max(l, r) + root.data, root.data);
                int ans = Math.Max(temp, root.data + l + r);
                min.value = Math.Max(min.value, ans);

                return ans;
                //got wrong when returning ans 
                //need to return temp
            }

            public int PathSumWithleafnode(TreesDP root, min min)
            {
                if (root == null)
                    return 0;

                int l = PathSumWithleafnode(root.left, min);
                int r = PathSumWithleafnode(root.right, min);

                int temp = Math.Max(l, r) + root.data;
                int ans = root.data + l + r;
                min.value = Math.Max(min.value, ans);

                return temp;
            }


        }

    }
}
