﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logical
{
    // Begin Singly Circular Linked List
   public class SinglyCircularLL
    {
        public class Node
        {
            internal int data;
            internal Node Next;
        }

        public Node InsertEmpty(Node lastnode,int data)
        {
            if (lastnode != null)
            {
                return lastnode;
            }

            Node node = new Node();
            node.data = data;

            lastnode = node;
            lastnode.Next = lastnode;

            return lastnode;
        }
        public Node addEnd(Node lastnode,int data)
        {
            if (lastnode==null)
            {
                return InsertEmpty(lastnode, data);
            }

            Node node = new Node();
            node.data = data;
            node.Next = lastnode.Next;
            lastnode.Next = node;
            lastnode = node;

            return lastnode;
        }
        public Node beginNode(Node lastnode, int data)
        {
            if (lastnode == null)
            {
                return InsertEmpty(lastnode, data);
            }

            Node node = new Node();
            node.data = data;
            node.Next = lastnode.Next;
            lastnode.Next = node;
            return lastnode;
        }
        public Node InsertAfter(Node lastnode, int data,int item)
        {
            Node temp, p;
            p = lastnode.Next;

            do {
                if (p.data == item)
                {
                    Node node = new Node();
                    node.data = data;
                    node.Next = p.Next;
                    p.Next = node;

                    if (p == lastnode)
                        lastnode = node;

                    return lastnode;
                }
                p = p.Next;
            }
            while (p != lastnode.Next);

            return lastnode;
        }
        public void Traverse(Node lastnode)
        {
            Node p = lastnode.Next;
            do
            {
                Console.Write(p.data + " ");
                p = p.Next;
            }
            while (p != lastnode.Next);
        }

        public Node remove(int i,Node head)
        {
            Node node = head;
            do
            {
                if (node.Next.data == i)
                {
                    Node n = node.Next;
                    node.Next = n.Next;
                    if (n == head)
                    { // removal of head
                        head = node;
                    }
                    return n.Next;
                }
                node = node.Next;
            } while (node != head);
            return null;
        }
    }
    // End Singly Circular Linked List


    // Begin Double Circular List
    public class DoubleCircularLL
    {
        public class Node
        {
            public int data;
            public Node Next;
            public Node Prev;
        }

        public Node start;

        public Node InsertEnd(Node head,int data)
        {
            if (head == null)
            {
                Node node = new Node();
                node.data = data;

                node.Next = node;
                node.Prev = node;

                head = node;

                return head;
            }

            Node last = head.Prev;

            Node node1 = new Node();
            node1.data = data;

            node1.Next = head;
            node1.Prev = last;

            last.Next = node1;
            head.Prev = node1;
            return head;
        
}


        public Node InsertBegin(Node head,int data)
        {
            Node lastnode = head.Prev;
            Node node = new Node();
            node.data = data;
            node.Prev = lastnode;
            node.Next = head;

            lastnode.Next = node;
            head.Prev = node;
            return node;
        }

        public Node InsertAfter(int value1, int value2,Node node)
        {
            Node newnode = new Node();
            newnode.data = value1;

            Node temp = node;
            while (temp.data != value2)
            {
                temp = temp.Next;
            }



            newnode.Prev = temp;
            newnode.Next = temp.Next;
            temp.Next.Prev = newnode;
            temp.Next = newnode;
           

            return node;
        }

        public void Travers(Node head)
        {
            Console.WriteLine(" Forward Direction");
           Node temp = head;
            while (temp.Next != head)
            {
                Console.Write(temp.data + " ");
                temp = temp.Next;
            }
            Console.Write(temp.data + " ");

            Console.WriteLine(" Back Direction");

            Node last = head.Prev;
            Node temp1 = last;
            while (temp1.Prev != last)
            {
                Console.Write(temp1.data + " ");
                temp1 = temp1.Prev;
            }
            Console.Write(temp1.data + " ");
        }

        public Node deleteNode(Node start, int key)
        {
            if(start == null)
            {
                return null;    
            }

            Node curr = start, Prev = null;
            while (curr.data != key)
            {
                if (curr.Next == start)
                {
                    Console.WriteLine("No Data Found");
                    return start;
                }
                Prev = curr;
                curr = curr.Next;
            }

            if(curr.Next==start && Prev == null)
            {
                start = null;
                return start;
            }

            if (curr == start)
            {
                Node last = start.Prev;
                start = start.Next;
                last.Next = start;
                start.Prev = last;

            }
            else if (curr.Next == start) {
                Prev.Next = start;
                start.Prev = Prev;
            } else {

                Node nxt = curr.Next;
                Prev.Next = nxt;
                nxt.Prev=Prev;
            }
            return start;
        }


    }
    // End Double Circular List
}
