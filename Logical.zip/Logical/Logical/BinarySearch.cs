﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logical
{
    public class BinarySearch
    {

        public class TreeNode
        {
            public int data { get; set; }
            public TreeNode leftnode;
            public TreeNode rightnode;
            public TreeNode(int da)
            {
                data = da;
                leftnode = null;
                rightnode = null;
            }
        }

        Dictionary<int, int> hm = new Dictionary<int, int>();
        int preindex = 0;

        public TreeNode buidTree(int[] preorder, int[] inorder)
        {
            for (int i = 0; i < inorder.Length - 1; i++)
                hm.Add(inorder[i], i);

            return build(preorder, inorder, 0, inorder.Length - 1);
        }

        public TreeNode build(int[] preorder, int[] inorder, int start, int end)
        {
            if (start > end)
                return null;

            TreeNode root = new TreeNode(preorder[preindex++]);
            if (root == null)
                return null;

            if (start == end)
                return root;
            int index = hm[root.data];
            root.leftnode = build(preorder, inorder, start, index - 1);
            root.rightnode = build(preorder, inorder, index + 1, end);
            return root;

        }



        public TreeNode buidTreePo(int[] postorder, int[] inorder)
        {
            for (int i = 0; i < inorder.Length; i++)
                hm.Add(inorder[i], i);
            preindex = inorder.Length;
            return buildPo(postorder, inorder, 0, inorder.Length - 1, inorder.Length - 1);
        }

        public TreeNode buildPo(int[] postorder, int[] inorder, int start, int end, int index)
        {
            if (start > end)
                return null;
            TreeNode root = new TreeNode(postorder[index]);
            if (root == null)
                return null;

            if (start == end)
                return root;
            int inRootIndex = hm[postorder[index]];
            root.rightnode = buildPo(postorder, inorder, inRootIndex + 1, end, index - 1);
            root.leftnode = buildPo(postorder, inorder, start, inRootIndex - 1, index - (end - inRootIndex) - 1);
            return root;

        }

        //public TreeNode buildTree(int[] inorder, int[] postorder)
        //{
        //    if (inorder.Length == 0 || postorder.Length == 0) return null;

        //    return this.buildTreeRecursion(inorder, 0, inorder.Length - 1, postorder, 0, postorder.Length - 1);
        //}

        //private TreeNode buildTreeRecursion(
        //    int[] inorder,
        //    int inorderlow,
        //    int inorderhigh,
        //    int[] postorder,
        //    int postorderlow,
        //    int postorderhigh)
        //{
        //    if (inorderlow > inorderhigh || postorderlow > postorderhigh)
        //    {
        //        return null;
        //    }

        //    var rootValue = postorder[postorderhigh];
        //    var root = new TreeNode(rootValue);
        //    var inorderIndex = Array.IndexOf(inorder, postorder[postorderhigh], inorderlow, inorderhigh - inorderlow + 1);

        //    root.leftnode = this.buildTreeRecursion(
        //        inorder,
        //        inorderlow,
        //        inorderIndex - 1,
        //        postorder,
        //        postorderlow,
        //        postorderlow + (inorderIndex - inorderlow - 1));

        //    root.rightnode = this.buildTreeRecursion(
        //        inorder,
        //        inorderIndex + 1,
        //        inorderhigh,
        //        postorder,
        //        postorderlow + (inorderIndex - inorderlow - 1) + 1,
        //        postorderhigh - 1);

        //    return root;
        //}

        //public TreeNode buildTree(int[] inorder, int[] postorder)
        //{
        //    if (inorder.Length == 0 || postorder.Length == 0) return null;

        //    return this.buildTreeRecursion(inorder, 0, inorder.Length - 1, postorder, 0, postorder.Length - 1);
        //}

        //private TreeNode buildTreeRecursion(
        //    int[] inorder,
        //    int inorderlow,
        //    int inorderhigh,
        //    int[] postorder,
        //    int postorderlow,
        //    int postorderhigh)
        //{
        //    if (inorderlow > inorderhigh || postorderlow > postorderhigh)
        //    {
        //        return null;
        //    }

        //    var rootValue = postorder[postorderhigh];
        //    var root = new TreeNode(rootValue);

        //    var inorderIndex = Array.IndexOf(inorder, postorder[postorderhigh], inorderlow, inorderhigh - inorderlow + 1);

        //    root.leftnode = this.buildTreeRecursion(
        //        inorder,
        //        inorderlow,
        //        inorderIndex - 1,
        //        postorder,
        //        postorderlow,
        //        postorderlow + (inorderIndex - inorderlow - 1));

        //    root.rightnode = this.buildTreeRecursion(
        //        inorder,
        //        inorderIndex + 1,
        //        inorderhigh,
        //        postorder,
        //        postorderlow + (inorderIndex - inorderlow - 1) + 1,
        //        postorderhigh - 1);

        //    return root;
        //}

        //  pu


        public void postorderTraversal(TreeNode node)
        {
            if (node != null)
            {
                postorderTraversal(node.leftnode);
                postorderTraversal(node.rightnode);
                Console.Write(node.data + " ");
            }
        }

        public void InorderTraversal(TreeNode node)
        {
            if (node != null)
            {
                InorderTraversal(node.leftnode);
                Console.Write(node.data + " ");
                InorderTraversal(node.rightnode);
            }
        }

        public void CreateBinaryTree(int[] arr)
        {
            TreeNode root = null;
            for (int i = 0; i < arr.Length; i++)
            {
                root = InsertBinaryTree(arr[i], root);
            }
            InorderTraversal(root);
            root = DeleteBinaryTree(20, root);
            Console.WriteLine();
            InorderTraversal(root);
        }

        public TreeNode InsertBinaryTree(int data, TreeNode root)
        {
            if (root == null)
                return new TreeNode(data);
            if (root.data > data)
            {
                root.leftnode = InsertBinaryTree(data, root.leftnode);
            }
            else
            {
                root.rightnode = InsertBinaryTree(data, root.rightnode);
            }
            return root;

        }

        public TreeNode DeleteBinaryTree(int data, TreeNode root)
        {
            if (root == null)
                return root;
            if (root.data > data)
            {
                root.leftnode = DeleteBinaryTree(data, root.leftnode);
            }
            else if (root.data < data)
            {
                root.rightnode = DeleteBinaryTree(data, root.rightnode);
            }
            else
            {
                if (root.leftnode == null)
                    return root.rightnode;
                else if (root.rightnode == null)
                    return root.leftnode;

                //root.data = InoderSuccessor(root.rightnode);
                //root.rightnode = DeleteBinaryTree(root.data, root.rightnode);
                root.data = InoderPredessor(root.leftnode);
                root.leftnode = DeleteBinaryTree(root.data, root.leftnode);
            }
            return root;
        }

        public int InoderSuccessor(TreeNode root)
        {
            int i = root.data;

            while (root.leftnode != null)
            {
                i = root.leftnode.data;
                root = root.leftnode;
            }
            return i;

        }

        public int InoderPredessor(TreeNode root)
        {
            int i = root.data;

            while (root.rightnode != null)
            {
                i = root.rightnode.data;
                root = root.rightnode;
            }
            return i;

        }
    }


    public class AVLNode
    {
        public int data { get; set; }
        public int height { get; set; }

        public AVLNode right, left;
        public AVLNode(int d)
        {
            data = d;
            height = 1;
            right = left = null;
        }

    }


    public class AVLTree
    {
        public AVLNode root = null;
        public int max(int a, int b)
        {
            return (a > b) ? a : b;

        }

        public int Height(AVLNode node)
        {
            if (node == null)
                return 0;

            return node.height
;
        }

        public int GetBalance(AVLNode node)
        {
            if (node == null)
                return 0;
            return Height(node.left) - Height(node.right);

        }

        public AVLNode RotateLeft(AVLNode x)
        {
            AVLNode y = x.right;
            AVLNode T2 = y.left;

            y.left = x;
            x.right = T2;

            x.height = 1 + (max(Height(x.left), Height(x.right)));
            y.height = 1 + (max(Height(y.left), Height(y.right)));

            return y;
        }

        public AVLNode RotateRight(AVLNode y)
        {
            AVLNode x = y.left;
            AVLNode T2 = x.right;

            x.right = y;
            y.left = T2;

            y.height = 1 + (max(Height(y.left), Height(y.right)));
            x.height = 1 + (max(Height(x.left), Height(x.right)));


            return x;
        }

        public AVLNode Insert(AVLNode root, int data)
        {
            if (root == null)
                return new AVLNode(data);
            if (data < root.data)
                root.left = Insert(root.left, data);
            else if (data > root.data)
                root.right = Insert(root.right, data);
            else
                return root;
            root.height = 1 + max(Height(root.left), Height(root.right));
            int balance = GetBalance(root);

            if (balance > 1 && data < root.left.data)
            {
                return RotateRight(root);
            }

            if (balance < -1 && data > root.right.data)
            {
                return RotateLeft(root);
            }


            if (balance > 1 && data > root.left.data)
            {
                root.left = RotateLeft(root.left);
                return RotateRight(root);
            }

            if (balance < -1 && data < root.right.data)
            {
                root.right = RotateRight(root.right);
                return RotateLeft(root);
            }
            return root;
        }
    }


}
