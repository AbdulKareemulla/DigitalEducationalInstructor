﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _450
{
    class Program
    {
        static void Main(string[] args)
        {

            //int[,] matrx = new int[4, 4];
            //Random random = new Random();
            //for (int i = 0; i < 4; i++)
            //{
            //    for (int j = 0; j < 4; j++)
            //    {

            //        matrx[i, j] = random.Next(1, 5);
            //    }
            //}

            //MatrixColoring mcol = new MatrixColoring();
            //mcol.printMatrix(matrx);

            //int k = 1;
            //while (k != 0)
            //{
            //    bool[,] visited = new bool[4, 4];
            //    int m = Convert.ToInt32(Console.ReadLine());
            //    //mcol.BFS(matrx, matrx[0, 0], m);
            //    mcol.DFSUtil(matrx, 0, 0, visited, matrx[0, 0], m);
            //    mcol.printMatrix(matrx);
            //    k = Convert.ToInt32(Console.ReadLine());
            //}

            // int[] arr = { 1, 2, 3, 4, 5 };
            //Arrays.ReverseArray(arr);
            //Arrays.MaxMinValu(arr);

            //int[] arr = { 7 ,10 ,4 ,3 ,20 ,15 };
            //Arrays.FindKSmallest(arr, 3);

            //int[] arr = { 2,3,4,-2,-3};
            //Arrays.NegativeElemetsAside(arr);

            //   int[] arr1 = { 2,3, 4, 6, 8 };
            //   int[] arr2 = { 1, 3, 5, 7 };

            ////   Arrays.UnionArr(arr1, arr2);
            //   Arrays.RotateCyclically(arr1);

            //int[] arr = { -2, 3, 2, -1 };
            //Arrays.Kadane(arr);
            //int[] arr = { 1, 3, 5, 8, 9, 2, 6, 7, 6, 8, 9 };
            //Console.WriteLine(Arrays.MinimumJumptoEnd(arr));

            //int[] ar = { 4, 2, 4, 5, 2, 3, 1 };
            //Arrays.DuplicateInArrayMethod2(ar);

            //int[] arr = { 5,4,3,2,1};
            //Arrays.NextPermutation(arr);

            //int[] arr = { 2, 4, 1, 3, 5 };
            //Arrays.ArrayInversion(arr);

            //int[] arr = { 7,6,4,3,1 };
            //Arrays.BuySellStock(arr);

            //int[] arr = { 1, 1, 1, 1 };
            //int sum = 2;
            //Arrays.SumPairOfInterger(arr, sum);

            //int[] ar1 = { 1, 5, 10, 20, 40, 80 };
            //int[] ar2 = { 6, 7, 20, 80, 100 };
            //int[] ar3 = { 3, 4, 15, 20, 30, 70, 80, 120 };
            //Arrays.CommonElementin3Array(ar1, ar2, ar3);

            //int[] arr = { 1, 2, 3, 4, 5, 6 };
            // int[] arr = { 2, 3, -4, -1, 6, -9 };
            //Arrays.RearrangePositiveNegative(arr);
            //Console.ReadLine();
            //int[] arr = {4, 2, -3, 1 ,6 };
            //Arrays.SubArraySumZero(arr);

            //Console.WriteLine( Arrays.Factorial(5));

            //int[] arr = { 6, -3, -10, 0, 2 };
            //Arrays.MaxProductSubArray(arr);

            //int[] arr = { 1, 9, 3, 10, 4, 20, 2 };
            //Arrays.LogestConsecutive(arr);

            //int[] arr = { 3, 1, 2, 2, 1, 2, 3, 3 };
            //Arrays.AllElementAppearNbyK(arr, 4);

            //int[] arr1 = { 11, 1, 13, 21, 3, 7 };
            //int[] arr2 = { 11, 3, 7, 1 ,5};
            //Arrays.ArraySubsetofAnother(arr1, arr2);

            //int[] arr = { 1 ,4, 45, 6, 10, 8 };
            //Arrays.TripletSumArray(arr,13);

            //int[] arr = { 2, 30, 15, 10, 8, 25, 80 };
            //Arrays.BuySellTwice(arr);

            // int[] arr = { 7, 3, 2, 4, 9, 12, 56 };
            // Arrays.ChocolateDistribution(arr, 3);

            //int[] arr = { 7, 4, 0, 9 };
            //Arrays.TrappingRainWater(arr);

            //string s = "Abdul";
            //Strings.ReverseString(s);

            // string s = "aabbaa";
            //Strings.IsPalindrom(s);

            //string s = "tesa sTring";
            //Strings.DuplicateChar(s);

            //string s1 = "ABCD";
            //string s2 = "ACBD";
            //Strings.StringRotationofEachOther(s1, s2);
            //string s1 = "XY";
            //string s2 = "12";
            //string result = "Y12X";
            //Strings.IstwoStringShuffletoOne(s1, s2, result);

            //Strings.CountandSay(4);
            //string s = "agbcba";
            //Strings.LongestPalindrom(s);

            //string s = "ABSG";
            //Strings.Permutation(s, 0, s.Length-1);

            //string s= "0111100010";
            //Strings.SubstringEqual01s(s);

            //string s = "GEEKSFORGEEKS";
            //Strings.EquivalentMobileNumeric(s);

            //string s = "{{}}}}";
            //Strings.ReversalCount(s);

            //string s = "0001010111";
            //Strings.NumberofFlips(s);

            // string[] s = { "aaa", "bbb", "ccc", "bbb", "aaa", "aaa" };
            // Strings.SecondRepeated(s);

            //string s = "[]][][";
            ///Strings.minimumSwap(s);

            //string s = "AABBBCBBAC";
            //Strings.SmallestWindowAllChar(s);

            // string s = "aaabbca";
            // Strings.RearrangeNoTwoAdjacent(s);

            //string s = "AACECAAAA";
            //Strings.AddFrontPalindrom(s);

            // string[] s = { "cat", "dog", "tac", "god", "act" };
            // Strings.PrintAllAnagrams(s);

            //string s = "timetopractice";
            //string searchstring = "toc";
            //Strings.SmallestWindowAllCharAnotherString(s, searchstring);

            //string s = "aabaa";
            //Strings.RemoveAllAdjacent(s);

            //string s1 = "aab";
            //string s2 = "zxy";
            //Strings.Isomorphic(s1, s2);

            //string s1 = "ABD";
            //string s2 = "BAD";
            //Strings.TransformStringMinOps(s1, s2);

            //string s = "ABCBCADEED";
            //int n = 1;
            //Strings.AssignComputers(s.ToCharArray(), n);

            //string[] s = {"flow","flower","fly" };
            //Strings.LongestCommonPrefix(s);

            //Strings.SearchString("abcxabcdabcdabcy", "abcdabcyx");

            //Strings.RomanToInteger("XCVI");

            //int[] wt = { 10,20,30 };
            //int[] val = { 60, 100, 120 };
            //Practice.Knapsack(wt, val,3, 50);

            //int[] arr = { 10,25,35,50};
            //Practice.SubsetSum(arr, arr.Length, 70);
            //Practice.EqualSumSubset(arr, arr.Length, 80);

            // int[] arr = { 1, 1, 1, 1 };
            //Practice.CountSubSet(arr, arr.Length, 1);

            //int[] arr = { 1, 6, 11, 5 };
            // Practice.SumminDiff(arr, arr.Length);

            //int[] arr = { 1, 1, 2, 3 };
            //Practice.CountSubsetSumdiff(arr, arr.Length, 1);

            //int[] rodlens = { 1, 2, 3, 4, 5, 6, 7, 8 };
            //int[] profit = { 1, 5, 8, 9, 10, 17, 17, 20 };
            //int rodlength = 8;
            //Practice.RodCutting(rodlens, profit, rodlength, rodlens.Length);

            //int[] coins = { 2, 5, 3, 6 };
            //int sum = 10;
            //Practice.CoinChangeWays(coins, sum, coins.Length);

            //int[] coins = { 1, 2, 3,5 };
            //int sum = 5;
            //Practice.MinimumCoins(coins, sum, coins.Length);

            // string x = "AGGTAB";
            // string y = "GXTXAYB";
            // Practice.LongestSubsequence(x, y, x.Length, y.Length);

            //string x = "zxabcdezy";
            //string y = "yzabcdezx";
            //Practice.LongestSubString(x, y, x.Length, y.Length);


            //string x = "AGGTAB";
            //string y = "GXTXAYB";
            //Practice.PrintSubsequence(x, y, x.Length, y.Length);

            //string x = "AGGTAB";
            //string y = "GXTXAYB";
            //Practice.ShortestCommonSupersequence(x, y, x.Length, y.Length);

            //string x = "heap";
            //string y = "pea";
            //Practice.MinimuminsertionDeletionAtoB(x, y, x.Length, y.Length);

            //string x = "agbcba";
            //Practice.LongestPalindromicSubsequence(x, x.Length);

            // string x = "agbcba";
            // Practice.MinimumNoDeletiontoPalindrome(x, x.Length);

            //string x = "geek";
            //string y = "eke";
            //Practice.PrintShortestSubsequence(x, x.Length, y, y.Length);

            //string x = "AABEBCDD";
            //Practice.LongestRepeatingSequence(x, x.Length);

            //string x = "ADXCPY";
            //string y = "AXY";
            //Practice.SequencePatternMatching(x, y, x.Length, y.Length);

            // string x = "agbcba";
            //Practice.MinimumNoInsertiontoPalindrome(x, x.Length);

            //int[] arr = { 40, 20, 30, 10, 30 };
            //Console.WriteLine(Practice.MinCost(arr, 1, arr.Length - 1));

            //string s = "nitik";
            //Console.WriteLine(Practice.Palindrompartition(s, 0, s.Length - 1));

            //Console.Write(Practice.ScrumbledString("abcde", "caebd"));

            //Console.WriteLine(Practice.EggDropping(3, 7));
            //string str = "cab";
            //Strings.PrintAllSubSequences(str, str.Length, -1, "");

            // string str = "aaaa";
            //Console.WriteLine(Strings.CountAllPalindromicSubsequence(0, str.Length - 1, str));
            //Strings.PrintAllIPAddresses("25505011535");

            //string ptrn = "ge*ks";
            //string str = "geeks";
            //Console.Write(Strings.WildCardStringMatching(ptrn, str, ptrn.Length-1, str.Length-1));
            //char[,] matx = { {'A','B','C','E' },
            //                 {'S','F','C','S' },
            //                 {'A','D','E','E' } };
            //Console.WriteLine(Strings.SearchStringinMatrix(matx, "SEE"));

            //string word = "i like sam sung samsung mobile ice cream icecream man go mango";
            //string s = "ilikesung";
            //Strings.WordBreak(word, s);


            //string x = "saturday";
            //string y = "sunday";
            //Console.WriteLine(Strings.EditDistance(x, y, x.Length, y.Length));


            //Practice.DPTressNode root = new Practice.DPTressNode(1);
            //root.leftnode = new Practice.DPTressNode(2);
            //root.rightnode = new Practice.DPTressNode(3);
            //root.leftnode.leftnode = new Practice.DPTressNode(4);
            //root.leftnode.rightnode = new Practice.DPTressNode(5);

            //Practice.min minv = new Practice.min();
            //Practice.TreeDP tree = new Practice.TreeDP();
            //tree.TreeDiameter(root, minv);
            //Console.WriteLine(minv.mvalue);

            //Practice.DPTressNode rootmaxpath = new Practice.DPTressNode(10);
            //rootmaxpath.leftnode = new Practice.DPTressNode(2);
            //rootmaxpath.rightnode = new Practice.DPTressNode(10);
            //rootmaxpath.leftnode.leftnode = new Practice.DPTressNode(20);
            //rootmaxpath.leftnode.rightnode = new Practice.DPTressNode(1);
            //rootmaxpath.rightnode.rightnode = new Practice.DPTressNode(-25);
            //rootmaxpath.rightnode.rightnode.leftnode = new Practice.DPTressNode(3);
            //rootmaxpath.rightnode.rightnode.rightnode = new Practice.DPTressNode(4);
            //tree.TreeFullPath(rootmaxpath, minv);
            //Console.WriteLine(minv.mvalue);

            //Practice.DPTressNode rootmaxpathleaf = new Practice.DPTressNode(-15);
            //rootmaxpathleaf.leftnode = new Practice.DPTressNode(5);
            //rootmaxpathleaf.rightnode = new Practice.DPTressNode(6);

            //rootmaxpathleaf.leftnode.leftnode = new Practice.DPTressNode(-8);
            //rootmaxpathleaf.leftnode.rightnode = new Practice.DPTressNode(1);
            //rootmaxpathleaf.leftnode.leftnode.leftnode = new Practice.DPTressNode(2);
            //rootmaxpathleaf.leftnode.leftnode.rightnode = new Practice.DPTressNode(6);

            //rootmaxpathleaf.rightnode.leftnode = new Practice.DPTressNode(3);
            //rootmaxpathleaf.rightnode.rightnode = new Practice.DPTressNode(9);

            //rootmaxpathleaf.rightnode.rightnode.rightnode = new Practice.DPTressNode(0);
            //rootmaxpathleaf.rightnode.rightnode.rightnode.leftnode = new Practice.DPTressNode(4);
            //rootmaxpathleaf.rightnode.rightnode.rightnode.rightnode = new Practice.DPTressNode(-1);
            //rootmaxpathleaf.rightnode.rightnode.rightnode.rightnode.leftnode = new Practice.DPTressNode(10);
            //tree.TreeFullPathWithLeaf(rootmaxpathleaf, minv);
            //Console.WriteLine(minv.mvalue

            //LiskovSubstitutionPrinciple.LSP.Food food = new LiskovSubstitutionPrinciple.LSP.Food();
            //food = new LiskovSubstitutionPrinciple.LSP.Pizza();
            //food.GatherIngredients(new string[] { "mushroom", "tomato", "cheek" });
            //food.Cook();


            //DesignPattern.IcreditCard icredit = null;
            //DesignPattern.FactoryClass factoryClass = new DesignPattern.FactoryClass();
            //icredit = factoryClass.Factory("MoneyBack");
            //Console.WriteLine(icredit.GetCardInfo());
            //Console.WriteLine(icredit.CardLimit());
            //Console.WriteLine(icredit.AnnualCharges());



            //DesignPattern.IcreditCardFM icreditfm = new DesignPattern.PlatinumFactory().CreateProduct();
            //Console.WriteLine("Card Type : " + icreditfm.GetCardInfo());
            //Console.WriteLine("Card Annual Charges : " + icreditfm.AnnualCharges());
            //Console.WriteLine("Card Limit : " + icreditfm.CardLimit());
            //Console.ReadLine();

            //DesignPattern.Animal animal = null;
            //DesignPattern.AnimalFactory animalFactory = null;

            //animalFactory = DesignPattern.AnimalFactory.CreateAnimalFactory("Sea");
            //animal = animalFactory.GetAnimal("Octopus");
            //Console.WriteLine(animal.GetType().Name + " Speak : " + animal.Speak());

            DesignPattern.Singleton fromteacher = DesignPattern.Singleton.GetInstance;
            fromteacher.Print("Teacher");

            DesignPattern.Singleton fromstudent = DesignPattern.Singleton.GetInstance;
            fromstudent.Print("Student");

            Console.ReadKey();
        }
    }
}
