﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _450
{

    public static class LinearSort
    {
        public static void LinearSort1(int[] arr)
        {
            int count = 0;
            for (int i = 1; i < arr.Length; i++)
            {
                int temp = arr[i];
                int j = i - 1;

                while (j >= 0 && arr[j] > temp)
                {
                    count++;
                    arr[j + 1] = arr[j];
                    j--;
                }
                arr[j + 1] = temp;
            }
        }
    }

    public static class CountingSort
    {
        public static void CountinfSort1(int[] arr)
        {
            int maxvalue = 0;
            for (int i = 0; i < arr.Length; i++)
            {
                if (maxvalue < arr[i])
                    maxvalue = arr[i];
            }
            int[] count = new int[maxvalue + 1];

            for (int i = 0; i < arr.Length; i++)
            {
                count[arr[i]] = count[arr[i]] + 1;
            }

            for (int i = 1; i < count.Length; i++)
            {
                count[i] = count[i] + count[i - 1];
            }

            int[] b = new int[arr.Length];
            for (int i = arr.Length - 1; i >= 0; i--)
            {
                count[arr[i]] = count[arr[i]] - 1;
                b[count[arr[i]]] = arr[i];
            }

            for (int i = 0; i < b.Length - 1; i++)
            {
                Console.Write(b[i] + " ");
            }
        }
      
    }
    public static class MergeSort
    {
        public static void MergeSort1(int[] arr, int lb, int ub)
        {
            if (lb < ub)
            {
                int mid = (lb + ub) / 2;
                MergeSort1(arr, lb, mid);
                MergeSort1(arr, mid + 1, ub);
                Merge(arr, lb, mid, ub);
            }
        }

        public static void Merge(int[] arr, int lb, int mid, int ub)
        {
            int i = 0;
            int j = 0;
            int k = lb;
            int n1 = mid - lb + 1;
            int n2 = ub - mid;
            int[] L = new int[n1];
            int[] R = new int[n2];

            for (i = 0; i < n1; i++)
                L[i] = arr[lb + i];
            for (j = 0; j < n2; j++)
                R[j] = arr[mid + 1 + j];

            i = 0;
            j = 0;
            while (i < n1 && j < n2)
            {
                if (L[i] <= R[j])
                {
                    arr[k] = L[i];
                    i++;
                    k++;
                }
                else
                {
                    arr[k] = R[j];
                    j++;
                    k++;
                }
            }

            while (i < n1)
            {
                arr[k] = L[i];
                i++;
                k++;
            }

            while (j < n2)
            {
                arr[k] = R[j];
                j++;
                k++;
            }

        }
    }

    public static class QuickSort
    {
        public static void QuickSort2(int[] arr, int lb, int ub)
        {
            if (lb < ub)
            {
                int pivotindx = Partition2(arr, lb, ub);
                Console.WriteLine(string.Join(" ", arr));
                QuickSort2(arr, lb, pivotindx - 1);
                QuickSort2(arr, pivotindx + 1, ub);
            }
        }

        public static int Partition2(int[] arr, int lb, int ub)
        {
            int pivot = arr[ub];
            int startingind = lb;
            for (int i = lb; i < ub; i++)
            {
                if (arr[i] < pivot)
                {
                    int temp = arr[i];
                    arr[i] = arr[startingind];
                    arr[startingind] = temp;
                    startingind++;
                }
            }

            int temp1 = arr[ub];
            arr[ub] = arr[startingind];
            arr[startingind] = temp1;
            return startingind;
        }
    }
}
