﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _450
{
    public class Arrays
    {
        //Reverse Array

        //6
        public static void ReverseArray(int[] arr)
        {
            //Array.Reverse(arr);
            for (int i = arr.Length - 1; i >= 0; i--)
            {
                Console.Write(arr[i] + " ");
            }
        }

        //7
        public static void MaxMinValu(int[] arr)
        {
            if (arr.Length == 0)
            {
                Console.WriteLine("Array is empty");
                return;
            }
            int max = arr[0];
            int min = arr[0];
            if (arr.Length == 1)
            {
                Console.WriteLine("Array MAX value is {0} and MIN Value is {1}", max, min);

            }

            for (int i = 1; i < arr.Length; i++)
            {
                if (min > arr[i])
                {
                    min = arr[i];
                }
                if (max < arr[i])
                {
                    max = arr[i];
                }
            }
            Console.WriteLine("Array MAX value is {0} and MIN Value is {1}", max, min);
        }

        //8
        public static void FindKSmallest(int[] arr, int k)
        {
            for (int i = 1; i < arr.Length; i++)
            {
                int temp = arr[i];
                int j = i - 1;
                while (j >= 0 && temp < arr[j])
                {
                    arr[j + 1] = arr[j];
                    j--;
                }

                arr[j + 1] = temp;
            }

            Console.Write("Values you are looking for is : " + arr[k - 1]);
        }

        //10
        public static void NegativeElemetsAside(int[] arr)
        {
            int min = 0;
            for (int i = 0; i < arr.Length; i++)
            {
                if (arr[i] < 0)
                {
                    int swap = arr[i];
                    arr[i] = arr[min];
                    arr[min] = swap;
                    min++;
                }
            }
            for (int i = 0; i < arr.Length; i++)
            {
                Console.Write(arr[i] + " ");
            }
        }

        //11 Union
        //Itersection is also same only need to check for else if condition
        public static void UnionArr(int[] arr1, int[] arr2)
        {
            int n1 = arr1.Length;
            int n2 = arr2.Length;
            int resultarrylenth = n1 + n2;
            int res = 0;
            int i = 0;
            int j = 0;
            int[] arrres = new int[resultarrylenth];
            while (i <= n1 - 1 && j <= n2 - 1)
            {
                if (arr1[i] < arr2[j])
                {
                    arrres[res] = arr1[i];
                    res++;
                    i++;
                }
                else if (arr1[i] == arr2[j])
                {
                    arrres[res] = arr1[i];
                    res++;
                    i++;
                    j++;
                }
                else
                {
                    arrres[res] = arr2[j];
                    res++;
                    j++;
                }
            }

            while (i <= n1 - 1)
            {
                arrres[res] = arr1[i];
                res++;
                i++;
            }

            while (j <= n2 - 1)
            {
                arrres[res] = arr1[j];
                res++;
                j++;
            }

            Console.Read();
        }

        //12 
        public static void RotateCyclically(int[] arr)
        {
            int temp = arr[arr.Length - 1];
            for (int i = arr.Length - 1; i > 0; i--)
            {
                arr[i] = arr[i - 1];
            }
            arr[0] = temp;
        }

        //13
        public static void Kadane(int[] arr)
        {
            int max_current = arr[0], max_global = arr[0];
            for (int i = 1; i < arr.Length; i++)
            {
                max_current = Math.Max(arr[i], max_current + arr[i]);
                if (max_global < max_current)
                {
                    max_global = max_current;
                }
            }
            Console.Write("Max Contigious sub String is : " + max_global);
        }

        //15 - Medium - Dinamic programming
        public static int MinimumJumptoEnd(int[] arr)
        {
            int n = arr.Length;
            if (n == 1)
            {
                return 0;
            }
            else if (arr[0] == 0)
            {
                return -1;
            }
            else
            {
                //1, 3, 5, 8, 9, 2, 6, 7, 6, 8, 9
                int jump = 1;
                int maxR = arr[0];
                int steps = arr[0];
                for (int i = 1; i < arr.Length; i++)
                {
                    if (i == n - 1)
                    {
                        return jump;
                    }
                    maxR = Math.Max(maxR, i + arr[i]);
                    steps--;
                    if (steps == 0)
                    {
                        jump++;
                        if (i >= maxR)
                        {
                            return -1;
                        }
                        steps = maxR - i;
                    }
                }
                return jump;
            }
        }

        //16 
        public static void DuplicateInArray(int[] arr)
        {
            for (int i = 0; i < arr.Length; i++)
            {
                for (int j = i + 1; j < arr.Length; j++)
                {
                    if (arr[i] == arr[j])
                        Console.WriteLine(arr[i]);
                }
            }
        }

        //20
        /// <summary>
        /// 3 Steps
        /// 1. Check for array from the end whose value is greater than the previous value
        /// 2. Pick the smallest number and check for the next highest number from the searched elements then swap
        /// 3.Reverse the array from the largest of the search of the array
        /// </summary>
        /// <param name="arr"></param>
        public static void NextPermutation(int[] arr)
        {
            int idx = -1;
            for (int i = arr.Length - 1; i > 0; i--)
            {
                if (arr[i] > arr[i - 1])
                {
                    idx = i;
                    break;
                }
            }

            if (idx < 0)
            {
                Array.Reverse(arr);
                for (int i = 0; i < arr.Length; i++)
                {
                    Console.Write(arr[i] + " ");
                }
                return;
            }

            int next = idx;
            for (int i = idx + 1; i < arr.Length; i++)
            {
                if ((arr[next] > arr[i]) && (arr[idx - 1] < arr[i]))
                {
                    next = i;
                }
            }

            int swap = arr[idx - 1];
            arr[idx - 1] = arr[next];
            arr[next] = swap;

            int j = arr.Length - 1;
            int k = idx;
            while (k < j)
            {
                int swap1 = arr[k];
                arr[k] = arr[j];
                arr[j] = swap1;
                k++;
                j--;
            }

            for (int i = 0; i < arr.Length; i++)
            {
                Console.Write(arr[i] + " ");
            }
        }

        //21
        public static void ArrayInversion(int[] arr)
        {
            for (int i = 0; i < arr.Length - 1; i++)
            {
                for (int j = i + 1; j < arr.Length; j++)
                {
                    if (arr[i] > arr[j])
                    {
                        Console.WriteLine(arr[i] + " - " + arr[j]);
                    }
                }
            }
        }

        //22
        public static void BuySellStock(int[] arr)
        {
            int min = int.MaxValue;
            int maxprofit = 0;
            if (arr.Length == 0)
            {
                Console.WriteLine(0);
                return;
            }
            for (int i = 0; i < arr.Length; i++)
            {
                if (arr[i] < min)
                {
                    min = arr[i];
                }
                else if (maxprofit < arr[i] - min)
                {
                    maxprofit = arr[i] - min;
                }
            }
            Console.WriteLine("Maximum profit is : " + maxprofit);
        }

        //23
        public static void SumPairOfInterger(int[] arr, int sum)
        {
            Dictionary<int, int> dicCollect = new Dictionary<int, int>();

            for (int i = 0; i < arr.Length; i++)
            {
                if (!dicCollect.ContainsKey(arr[i]))
                {
                    dicCollect.Add(arr[i], 0);
                }
                dicCollect[arr[i]]++;
            }
            int twice_count = 0;
            for (int i = 0; i < arr.Length; i++)
            {
                if (dicCollect.ContainsKey(sum - arr[i]))
                {
                    if (dicCollect[sum - arr[i]] != 0)
                        twice_count += dicCollect[sum - arr[i]];
                }
                if (sum - arr[i] == arr[i])
                {
                    twice_count--;
                }
            }
            Console.WriteLine(" Count is : " + twice_count / 2);
        }

        //24
        public static void CommonElementin3Array(int[] arr1, int[] arr2, int[] arr3)
        {
            int i = 0;
            int j = 0;
            int k = 0;
            int count = 0;
            while (arr1.Length > i && arr2.Length > j && arr3.Length > k)
            {
                if (arr1[i] == arr2[j] && arr2[j] == arr3[k])
                {
                    Console.WriteLine(arr3[k]);
                    count++;
                    i++;
                    j++;
                    k++;
                }
                else if (arr1[i] < arr2[j])
                {
                    i++;
                }
                else if (arr2[j] < arr3[k])
                {
                    j++;
                }
                else
                {
                    k++;
                }
            }
        }

        //25
        public static void RearrangePositiveNegative(int[] arr)
        {
            int j = arr.Length - 1;
            int i = 0;
            while (i < j)
            {
                if (arr[i] < 0 && arr[j] > 0)
                {
                    int swap = arr[i];
                    arr[i] = arr[j];
                    arr[j] = swap;

                    i++;
                    j--;
                }
                else if (arr[i] > 0 && arr[j] < 0)
                {
                    i++;
                    j--;
                }
                else if (arr[i] > 0)
                {
                    i++;
                }
                else if (arr[j] < 0)
                {
                    j--;
                }
            }
            if (i == 0 || i == arr.Length - 1)
            {
                
            }
            else
            {
                int n = arr.Length ;
                int k = 0;
                while (i < n && k < n)
                {
                    int swap = arr[i];
                    arr[i] = arr[k];
                    arr[k] = swap;

                    i++;
                    k = k + 2;
                }


            }
            for (int el = 0; el < arr.Length; el++)
            {
                Console.Write(arr[el] + " ");
            }
        }

        //26
        public static void SubArraySumZero(int[] arr)
        {
            bool flag = false;
            int n = arr.Length - 1;
            HashSet<int> set = new HashSet<int>();
            int sum = 0;
            for (int i = 0; i < arr.Length - 1; i++)
            {
                sum = sum + arr[i];
                if (sum == 0 || arr[i] == 0 || set.Contains(sum))
                {
                    flag = true;
                    break;
                }
                set.Add(arr[i]);
            }
            Console.WriteLine(flag);
        }

        //27
        public static int Factorial(int n)
        {
            if (n == 1)
            {
                return n;
            }
            return n * Factorial(n - 1);
        }

        //28
        public static void MaxProductSubArray(int[] arr)
        {
            int max = arr[0];
            int min = arr[0];
            int product = arr[0];
            for (int i = 1; i < arr.Length; i++)
            {
                if (arr[i] < 0)
                {
                    int swapele = min;
                    min = max;
                    max = swapele;
                }
                max = Math.Max(arr[i], max * arr[i]);
                min = Math.Min(arr[i], min * arr[i]);
                if (product < max)
                {
                    product = max;
                }
            }

            Console.WriteLine("Maximum Product SubArray : " + product);
        }

        //29
        public static void LogestConsecutive(int[] arr)
        {
            HashSet<int> set = new HashSet<int>();
            for (int i = 0; i < arr.Length; i++)
            {
                set.Add(arr[i]);
            }

            int lngestStreak = 0;
            for (int i = 0; i < arr.Length; i++)
            {
                int currentstreak = 0;
                int num = arr[i];
                if (!set.Contains(num - 1))
                {

                    int sint = num;

                    while (set.Contains(sint))
                    {
                        Console.Write(sint + " ");
                        sint = sint + 1;
                        currentstreak++;
                    }
                    Console.WriteLine();
                }
                if (currentstreak > lngestStreak)
                {
                    lngestStreak = currentstreak;
                }
            }
            Console.WriteLine(lngestStreak);
        }

        //30
        public static void AllElementAppearNbyK(int[] arr, int k)
        {
            Dictionary<int, int> dic = new Dictionary<int, int>();

            for (int i = 0; i < arr.Length; i++)
            {
                if (!dic.ContainsKey(arr[i]))
                    dic[arr[i]] = 1;
                else
                    dic[arr[i]] = dic[arr[i]] + 1;
            }

            int value = (arr.Length) / k;
            int count = 0;
            foreach (KeyValuePair<int, int> item in dic)
            {
                if (item.Value > value)
                {
                    Console.Write(item.Key + " ");
                    count++;
                }
            }
            Console.WriteLine();
            Console.WriteLine(count);

        }

        //31
        public static void BuySellTwice(int[] arr)
        {
            int buy1 = int.MaxValue;
            int buy2 = int.MaxValue;
            int profit1 = 0;
            int profit2 = 0;
            for (int i = 0; i < arr.Length; i++)
            {
                buy1 = Math.Min(buy1, arr[i]);
                profit1 = Math.Max(profit1, arr[i] - buy1);

                buy2 = Math.Min(buy2, arr[i] - profit1);
                profit2 = Math.Max(profit2, arr[i] - buy2);

            }

            Console.WriteLine(profit2);
        }

        //32
        public static void ArraySubsetofAnother(int[] arr1, int[] arr2)
        {
            bool istrue = false;
            HashSet<int> set = new HashSet<int>();

            for (int i = 0; i < arr1.Length; i++)
            {
                set.Add(arr1[i]);
            }
            int firstarraylength = set.Count;

            for (int i = 0; i < arr2.Length; i++)
            {
                set.Add(arr2[i]);
            }
            int secondarraylength = set.Count;
            if (firstarraylength == secondarraylength)
            {
                istrue = true;
            }
            Console.WriteLine("One array is subset of another " + istrue);
        }

        //33 
        public static void TripletSumArray(int[] arr, int sum)
        {
            bool istriplet = false;
            Array.Sort(arr);
            for (int i = 0; i < arr.Length; i++)
            {
                int l = i + 1;
                int r = arr.Length - 1;

                while (l < r)
                {
                    if (arr[i] + arr[l] + arr[r] == sum)
                    {
                        istriplet = true;
                        break;
                    }
                    else if (arr[i] + arr[l] + arr[r] < sum)
                    {
                        l++;
                    }
                    else
                    {
                        r--;
                    }
                }

            }

            Console.WriteLine(" Array is Triplet : " + istriplet);
        }


        //34 time=o(n) and space=o(n)
        public static void TrappingRainWater(int[] arr)
        {
            int n = arr.Length;
            int[] l = new int[n];
            int[] r = new int[n];
            int ma = l[0] = arr[0];
            int mi = r[n - 1] = arr[n - 1];

            for (int i = 1; i < n; i++)
            {
                if (ma < arr[i])
                {
                    ma = arr[i];
                }
                l[i] = ma;
            }

            for (int i = n - 2; i >= 0; i--)
            {
                if (mi < arr[i])
                {
                    mi = arr[i];
                }
                r[i] = mi;
            }
            int sum = 0;
            for (int i = 0; i < arr.Length; i++)
            {
                sum += Math.Min(l[i], r[i]) - arr[i];
            }
            Console.WriteLine("" + sum);
        }

        //35  o(nlogn)
        public static void ChocolateDistribution(int[] arr, int students)
        {
            int min = int.MaxValue;
            int n = arr.Length;
            Array.Sort(arr);
            for (int i = 0; i + students - 1 < arr.Length; i++)
            {
                if (min > (arr[i + students - 1] - arr[i]))
                {
                    min = arr[i + students - 1] - arr[i];
                }
            }
            Console.WriteLine("Minimum difference is : " + min);
        }
    }
}
