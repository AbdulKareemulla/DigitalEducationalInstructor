﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _450
{
    public class Strings
    {
        //56  o(n)
        public static void ReverseString(string s)
        {
            char[] chrarr = s.ToCharArray();
            Array.Reverse(chrarr);
            Console.WriteLine(new string(chrarr));

            int strlen = s.Length - 1;
            while (strlen >= 0)
            {
                Console.Write(s[strlen]);
                strlen--;
            }
        }

        //57
        public static void IsPalindrom(string s)
        {
            int strlen = s.Length - 1;
            string rsting = "";
            while (strlen >= 0)
            {
                rsting = rsting + s[strlen];
                strlen--;
            }

            if (s == rsting)
                Console.WriteLine("String is Palindrom");
            else
                Console.WriteLine("String is not Palindrom");
        }


        //58 time o(n) n=array space o(m) m=total character
        //Adding Dictionary is better than using array of 256 size
        public static void DuplicateChar(string s)
        {
            int totalchar = 256;
            int[] count = new int[totalchar];
            for (int i = 0; i < s.Length; i++)
            {
                count[s[i]] += 1;
            }

            Console.WriteLine();
            for (int i = 0; i < count.Length; i++)
            {
                if (count[i] > 1)
                    Console.WriteLine((char)i + " - " + count[i]);
            }
        }

        //59 
        public static void StringRotationofEachOther(string firststring, string secondstring)
        {
            string firstcontact = firststring + firststring;
            if (firststring.Length == secondstring.Length && firstcontact.IndexOf(secondstring) != -1)
            {
                Console.WriteLine("One string is rotation of another");
            }
            else
            {
                Console.WriteLine("One string is not rotation of another");
            }
        }

        public static void IstwoStringShuffletoOne(string firststr, string secondstr, string result)
        {
            bool istrue = true;
            if (firststr.Length + secondstr.Length != result.Length)
            {
                istrue = false;
            }

            int i = 0; int j = 0; int k = 0;
            while (k != result.Length)
            {
                if (i < firststr.Length && firststr[i] == result[k])
                {
                    i++;
                    k++;
                }
                else if (j < secondstr.Length && secondstr[j] == result[k])
                {
                    j++;
                    k++;
                }
                else
                {
                    istrue = false;
                    break;
                }
            }

            Console.WriteLine("Two string shuffle : " + istrue);
        }

        public static void CountandSay(int nums)
        {
            string res = "11";
            if (nums == 1)
            {
                Console.WriteLine("1");
                return;
            }
            if (nums == 2)
            {
                Console.WriteLine("11");
                return;
            }

            for (int i = 3; i <= nums; i++)
            {
                int count = 1;
                string t = "";
                res = res + '&';
                for (int j = 1; j < res.Length; j++)
                {
                    if (res[j] == res[j - 1])
                        count++;
                    else
                    {
                        //  t = t + count.ToString();
                        //  t = t + res[j - 1];
                        //  count = 1;

                        t = t + count.ToString() + res[j - 1];
                    }
                }
                res = t;
            }
            Console.WriteLine(res);
        }

        public static void LongestPalindrom(string s)
        {
            int start = 0;
            int end = 1;
            int l, r;
            for (int i = 1; i < s.Length; i++)
            {
                l = i - 1;
                r = i;
                while (l >= 0 && r < s.Length && s[l] == s[r])
                {
                    if (r - l + 1 > end)
                    {
                        start = l;
                        end = r - l + 1;
                    }
                    l--;
                    r++;
                }

                l = i - 1;
                r = i + 1;
                while (l >= 0 && r < s.Length && s[l] == s[r])
                {
                    if (r - l + 1 > end)
                    {
                        start = l;
                        end = r - l + 1;
                    }
                    l--;
                    r++;
                }
            }
            Console.WriteLine(s.Substring(start, end));
        }

        public static void Permutation(string str, int index, int length)
        {
            if (index == length)
            {
                Console.WriteLine(str);
            }
            else
            {
                for (int i = index; i <= length; i++)
                {
                    str = Swap(str, index, i);
                    Permutation(str, index + 1, length);
                    str = Swap(str, index, i);
                }
            }
        }

        public static string Swap(string str, int i, int j)
        {
            char[] chararray = str.ToCharArray();
            char tem = chararray[i];
            chararray[i] = chararray[j];
            chararray[j] = tem;
            return new string(chararray);
        }

        public static void SubstringEqual01s(string s)
        {
            int len = s.Length;
            int count0 = 0;
            int count1 = 0;
            int cnt = 0;
            for (int i = 0; i < len; i++)
            {
                if (s[i] == '0')
                {
                    count0++;
                }
                else
                {
                    count1++;
                }
                if (count1 == count0)
                {
                    cnt++;
                }
            }
            if (count0 != count1)
            {
                Console.WriteLine(-1);
            }
            else
            {
                Console.WriteLine(cnt);
            }
        }

        public static bool IsMatching(char a, char b)
        {
            if (a == '(' && b == ')')
                return true;

            if (a == '{' && b == '}')
                return true;


            if (a == '[' && b == ']')
                return true;

            return false;
        }

        public static bool BalancedParanthises(string balpara)
        {
            Stack<char> st = new Stack<char>();
            foreach (char c in balpara)
            {
                if (c == '(' || c == '{' || c == '[')
                {
                    st.Push(c);
                }
                if (c == ')' || c == '}' || c == ']')
                {
                    if (st.Count == 0)
                    {
                        return false;
                    }
                    if (!IsMatching(st.Pop(), c))
                    {
                        return false;
                    }
                }
            }

            if (st.Count > 0)
            {
                Console.WriteLine("Not balanced");
                return false;
            }
            else
            {
                Console.WriteLine("Balanced");
                return true;
            }
        }

        public static void EquivalentMobileNumeric(string s)
        {
            string[] arr = {"2","22","222","3","33","333","4","44","444",
                "5","55","555","6","66","666","7","77","777","7777","8","88","888","9","99","999","9999" };

            for (int i = 0; i < s.Length; i++)
            {
                Console.Write(arr[s[i] - 'A']);
            }
        }

        public static void ReversalCount(string s)
        {
            int n = s.Length;
            if (n % 2 != 0)
                Console.WriteLine("Cannot be done");
            else

            {
                Stack<string> stk = new Stack<string>();
                int countropen = 0;
                int countrclose = 0;
                for (int i = 0; i < s.Length; i++)
                {
                    if (s[i] == '{')
                    {
                        stk.Push("{");
                        countropen++;
                    }
                    else if (s[i] == '}' && stk.Count != 0)
                    {
                        stk.Pop();
                        countropen--;
                    }
                    else
                    {
                        countrclose++;
                    }
                }
                if (countropen % 2 == 0)
                {
                    countropen = countropen / 2;
                }
                else
                {
                    countropen = (countropen / 2) + 1;
                }
                if (countrclose % 2 == 0)
                {
                    countrclose = countrclose / 2
;
                }
                else
                {
                    countrclose = (countrclose / 2) + 1;
                }
                Console.WriteLine(countropen + countrclose);
            }
        }

        public static void NumberofFlips(string s)
        {
            int cntr0 = 0;
            int cntr1 = 0;
            for (int i = 0; i < s.Length; i++)
            {
                if (s[i] == '0')
                {
                    cntr0++;
                }
                else
                {
                    cntr1++;
                }
            }
            if (cntr0 > cntr1)
            {
                if (cntr0 != cntr1 + 1)
                {
                    Console.WriteLine("Cannot be done");
                    return;
                }
            }

            if (cntr0 < cntr1)
            {
                if (cntr1 != cntr0 + 1)
                {
                    Console.WriteLine("Cannot be done");
                    return;
                }
            }


            int cnt1 = 0;
            int cnt2 = 0;
            for (int i = 0; i < s.Length; i++)
            {
                if (i % 2 == 0 && s[i] == '0')
                    cnt1++;
                if (i % 2 == 1 && s[i] == '1')
                    cnt1++;
                if (i % 2 == 0 && s[i] == '1')
                    cnt2++;
                if (i % 2 == 1 && s[i] == '0')
                    cnt2++;
            }
            Console.WriteLine(Math.Min(cnt1, cnt2));
        }

        public static void SecondRepeated(string[] arr)
        {
            Dictionary<string, int> dic = new Dictionary<string, int>();
            for (int i = 0; i < arr.Length; i++)
            {
                if (!dic.ContainsKey(arr[i]))
                    dic.Add(arr[i], 1);
                else
                {
                    Console.WriteLine(arr[i]);
                    break;
                }
            }
        }

        public static void minimumSwap(string s)
        {
            List<int> lst = new List<int>();
            int count = 0;
            int ans = 0;
            for (int i = 0; i < s.Length; i++)
            {
                if (s[i] == '[')
                {
                    lst.Add(i);
                }
            }

            int idx = 0;
            for (int i = 0; i < s.Length; i++)
            {
                if (s[i] == '[')
                {
                    count++;
                    idx++;
                }
                else

                {
                    count--;
                    if (count < 0)
                    {
                        ans += lst[idx] - i;
                        s = Swap(s, lst[idx], i);
                        count = 1;
                        idx++;
                    }
                }
            }
            Console.WriteLine(s + "  :  " + ans);
        }

        public static void SmallestWindowAllChar(string s)
        {
            Dictionary<char, int> dic = new Dictionary<char, int>();
            for (int it = 0; it < s.Length; it++)
            {
                if (!dic.ContainsKey(s[it]))
                    dic.Add(s[it], 0);
            }


            int n = dic.Count;
            int i = 0;
            int j = 1;
            int count = 0;
            dic[s[i]]++;
            count++;
            int min = int.MaxValue;
            while (j >= i && s.Length > j)
            {
                if (count < n)
                {
                    if (dic[s[j]] == 0)
                        count++;

                    dic[s[j]]++;
                    j++;

                }
                else if (count == n)
                {
                    min = Math.Min(min, j - i);
                    if (dic[s[i]] == 1)
                        count--;
                    dic[s[i]]--;
                    i++;

                }
            }
            while (count == n)
            {
                min = Math.Min(min, j - i);
                if (dic[s[i]] == 1)
                    count--;
                dic[s[i]]--;
                i++;
            }
            Console.WriteLine(min);
        }

        public static void RearrangeNoTwoAdjacent(string s)
        {
            Dictionary<char, int> dic = new Dictionary<char, int>();
            int max = 0;
            for (int i = 0; i < s.Length; i++)
            {
                if (!dic.ContainsKey(s[i]))
                    dic.Add(s[i], 1);
                else
                    dic[s[i]]++;

                if (max < dic[s[i]])
                {
                    max = dic[s[i]];
                }
            }
            if (max <= s.Length - max + 1)
                Console.WriteLine(true);
            else
                Console.WriteLine(false);

        }

        public static bool IsStringPalindrom(string s)
        {
            int strlen = s.Length - 1;
            string rsting = "";
            while (strlen >= 0)
            {
                rsting = rsting + s[strlen];
                strlen--;
            }

            if (s == rsting)
                return true;
            else
                return false;
        }

        public static void AddFrontPalindrom(string s)
        {
            int cnt = 0;
            while (s.Length > 0)
            {
                if (!IsStringPalindrom(s))
                {
                    s = s.Substring(0, s.Length - 1);
                    cnt++;
                }
                else
                {
                    break;
                }
            }
            Console.WriteLine(s + " : " + cnt);
        }

        public static void PrintAllAnagrams(string[] s)
        {
            Dictionary<string, List<string>> dic = new Dictionary<string, List<string>>();

            foreach (var item in s)
            {
                string it = item;
                char[] charr = it.ToCharArray();
                Array.Sort(charr);
                string si = new string(charr);
                if (!dic.ContainsKey(si))
                {
                    List<string> lst = new List<string>();
                    lst.Add(it);
                    dic.Add(new string(charr), lst);
                }
                else
                {
                    dic[si].Add(it);
                }
            }
            foreach (KeyValuePair<string, List<string>> item in dic)
            {
                Console.Write(item.Key + " : ");
                foreach (var item1 in item.Value)
                {
                    Console.Write(item1 + " ");
                }
                Console.WriteLine();
            }
        }

        public static void SmallestWindowAllCharAnotherString(string s, string searchstring)
        {
            Dictionary<char, int> dic = new Dictionary<char, int>();
            for (int it = 0; it < searchstring.Length; it++)
            {
                if (!dic.ContainsKey(searchstring[it]))
                    dic.Add(searchstring[it], 0);
            }

            int ival = 0;
            int n = dic.Count;
            int i = 0;
            int j = 1;
            int count = 0;
            dic[s[i]]++;
            count++;
            int min = int.MaxValue;
            while (j >= i && s.Length > j)
            {
                if (count < n)
                {
                    if (dic.ContainsKey(s[j]))
                    {
                        if (dic[s[j]] == 0)
                            count++;

                        dic[s[j]]++;
                    }
                    j++;

                }
                else if (count == n)
                {
                    if (min > j - i)
                    {
                        min = j - i;
                        ival = i;
                    }
                    // min = Math.Min(min, j - i);
                    if (dic.ContainsKey(s[i]))
                    {
                        if (dic[s[i]] == 1)
                            count--;
                        dic[s[i]]--;
                    }
                    i++;

                }
            }
            while (count == n)
            {
                if (dic.ContainsKey(s[i]))
                {
                    if (min > j - i)
                    {
                        min = j - i;
                        ival = i;
                    }
                    //min = Math.Min(min, j - i);
                    if (dic[s[i]] == 1)
                        count--;
                    dic[s[i]]--;
                }
                i++;
            }
            Console.WriteLine(s.Substring(ival, min));
        }

        public static void RemoveAllAdjacent(string s)
        {
            Console.Write(s[0]);
            for (int i = 1; i < s.Length; i++)
            {
                if (s[i] != s[i - 1])
                    Console.Write(s[i]);
            }
        }

        public static void Isomorphic(string s1, string s2)
        {
            Dictionary<char, char> dic = new Dictionary<char, char>();
            bool istrue = true;
            if (s1.Length != s2.Length)
            {
                Console.WriteLine(false);
                return;
            }
            for (int i = 0; i < s1.Length; i++)
            {
                if (!dic.ContainsKey(s1[i]))
                {
                    dic.Add(s1[i], s2[i]);
                }
                else if (dic[s1[i]] != s2[i])
                {
                    istrue = false;
                }
            }

            Console.WriteLine(istrue);
        }

        public static void TransformStringMinOps(string s1, string s2)
        {
            char[] s11 = s1.ToCharArray();
            Array.Sort(s11);
            string strins1 = new string(s11);

            char[] s12 = s1.ToCharArray();
            Array.Sort(s12);
            string strins2 = new string(s12);
            if (strins1 != strins2)
                Console.WriteLine("Cannot be done");

            int i = s1.Length - 1, j = s2.Length - 1;
            int res = 0;
            while (i >= 0)
            {
                if (s1[i] != s2[j])
                    res++;
                else
                    j--;
                i--;
            }
            Console.WriteLine(res);
        }

        public static void AssignComputers(char[] charr, int n)
        {
            int res = 0;
            int occupied = 0;
            Dictionary<char, int> dic = new Dictionary<char, int>();
            foreach (char item in charr)
            {
                if (!dic.ContainsKey(item))
                {
                    dic.Add(item, 1);
                    if (occupied < n)
                    {
                        occupied++;
                        dic[item] = 2;
                    }
                    else
                        res++;
                }
                else
                {
                    if (dic[item] == 2)
                    {
                        occupied--;
                    }
                    dic.Remove(item);
                }
            }
            Console.WriteLine(res);
        }

        public static void LongestCommonPrefix(string[] s)
        {
            string prefix = s[0];
            for (int i = 1; i < s.Length; i++)
            {
                while (s[i].IndexOf(prefix) != 0)
                {
                    prefix = prefix.Substring(0, prefix.Length - 1);
                }
            }
            Console.Write(prefix);
        }

        //NOT KMP but similay O(n+m)
        public static void SearchString(string searchtext, string pattern)
        {
            int i = 0;
            int j = 0;
            int k = 0;
            while (i < searchtext.Length && j < pattern.Length)
            {
                if (searchtext[i] == pattern[j])
                {
                    i++;
                    j++;
                }
                else
                {
                    j = 0;
                    k++;
                    i = k;
                }
            }
            if (pattern.Length == j)
                Console.WriteLine(true);
            else
                Console.WriteLine(false);
        }

        public static int IntValue(char c)
        {
            int currentval = 0;
            switch (c)
            {
                case 'I':
                    currentval = 1;
                    break;
                case 'V':
                    currentval = 5;
                    break;
                case 'X':
                    currentval = 10;
                    break;
                case 'L':
                    currentval = 50;
                    break;
                case 'C':
                    currentval = 100;
                    break;
                case 'D':
                    currentval = 500;
                    break;
                case 'M':
                    currentval = 1000;
                    break;
            }
            return currentval;
        }

        public static void RomanToInteger(string s)
        {
            int ans = 0;
            for (int i = 0; i < s.Length - 1; i++)
            {
                int currentval1 = IntValue(s[i]);
                int currentval2 = IntValue(s[i + 1]);
                if (currentval1 >= currentval2)
                    ans = ans + currentval1;
                else
                    ans = ans - currentval1;
            }
            int val = IntValue(s[s.Length - 1]);
            ans += val;
            Console.WriteLine(ans);
        }

        #region[ Dinamic Program on Strings]

        //65
        public static void PrintAllSubSequences(string str, int n, int index, string curr)
        {
            if (n == index)
            {
                return;
            }

            if (!string.IsNullOrEmpty(curr) && curr.Length > 0)
            {
                Console.WriteLine(curr);
            }

            for (int i = index + 1; i < str.Length; i++)
            {
                curr += str[i];
                PrintAllSubSequences(str, n, i, curr);
                curr = curr.Substring(0, curr.Length - 1);
            }
        }

        static int[,] countpalindromdp = new int[1001, 1001];
        //77
        public static int CountAllPalindromicSubsequence(int i, int j, string str)
        {
            if (i > j)
            {
                return 0;
            }

            if (i == j)
            {
                return countpalindromdp[i, j] = 1;
            }
            else if (str[i] == str[j])
            {
                return countpalindromdp[i, j] = 1 + CountAllPalindromicSubsequence(i, j - 1, str) +
                    CountAllPalindromicSubsequence(i + 1, j, str);
            }
            else
            {
                return countpalindromdp[i, j] = CountAllPalindromicSubsequence(i, j - 1, str) +
                    CountAllPalindromicSubsequence(i + 1, j, str) -
                    CountAllPalindromicSubsequence(i + 1, j - 1, str);
            }
        }

        public static void PrintAllIPAddresses(string ipaddress)
        {
            for (int i = 1; i < 4 && i < ipaddress.Length; i++)
            {
                string firstpart = ipaddress.Substring(0, i);
                if (IsValid(firstpart))
                {
                    for (int j = 1; j < 4 && i + j < ipaddress.Length; j++)
                    {
                        string secondpart = ipaddress.Substring(i, j);

                        if (IsValid(secondpart))
                        {
                            for (int k = 1; k < 4 && i + j + k < ipaddress.Length; k++)
                            {
                                string thirdpart = ipaddress.Substring(i + j, k);
                                string fourthpart = ipaddress.Substring(i + j + k);
                                if (IsValid(thirdpart) && IsValid(fourthpart))
                                {
                                    Console.WriteLine(firstpart + "." + secondpart + "." + thirdpart + "." + fourthpart);
                                }
                            }
                        }
                    }
                }


            }
        }

        public static bool IsValid(string s)
        {
            bool res = true;
            int part = Convert.ToInt32(s);
            if (s.Length > 4)
            {
                res = false;
            }
            if (s.Length > 0 && s[0] == '0')
            {
                res = false;
            }
            if (part < 0 || part > 256)
            {
                res = false;
            }
            return res;
        }

        static bool[,] wdp = new bool[1001, 1001];
        public static bool WildCardStringMatching(string p, string str, int i, int j)
        {
            if (j == -1 && i == -1)
            {
                return true;
            }
            if (j == -1)
            {
                for (int k = 0; k < i; k++)
                {
                    if (p[k] != '*')
                        return false;
                }
                return true;
            }
            if (i == -1)
            {
                return false;
            }
            if (wdp[i, j] != false)
            {
                return wdp[i, j];
            }
            if (str[j] == p[i] || p[i] == '?')
            {
                return wdp[i, j] = WildCardStringMatching(p, str, i - 1, j - 1);
            }
            if (p[i] == '*')
            {
                bool op1 = WildCardStringMatching(p, str, i, j - 1);
                bool op2 = WildCardStringMatching(p, str, i - 1, j);
                return wdp[i, j] = op1 || op2;
            }
            return wdp[i, j] = false;
        }

        public static bool SearchStringinMatrix(char[,] matx, string str)
        {
            for (int i = 0; i < matx.GetLength(0); i++)
            {
                for (int j = 0; j < matx.GetLength(1); j++)
                {
                    if (matx[i, j] == str[0] && (PrintSearchMatrix(matx, 0, i, j, str)))
                    {
                        Console.WriteLine(i + " " + j);
                        return true;
                    }
                }
            }
            return false;
        }

        public static bool PrintSearchMatrix(char[,] matx, int pos, int i, int j, string s)
        {
            if (pos == s.Length)
            {
                return true;
            }
            if (i < 0 || j < 0 || i >= matx.GetLength(0) || j >= matx.GetLength(1))
            {
                return false;
            }
            if (s[pos] != matx[i, j])
            {
                return false;
            }
            char tmp = matx[i, j];
            matx[i, j] = '$';
            bool rowleft = PrintSearchMatrix(matx, pos + 1, i - 1, j, s)
            || PrintSearchMatrix(matx, pos + 1, i + 1, j, s)
            || PrintSearchMatrix(matx, pos + 1, i, j - 1, s)
            || PrintSearchMatrix(matx, pos + 1, i, j + 1, s);
            if (rowleft)
            {
                return true;
            }
            matx[i, j] = tmp;
            return false;
        }

        public static HashSet<string> dictwordbreak = new HashSet<string>();

        //public static Dictionary<string, int> dpdic = new Dictionary<string, int>();
        public static void WordBreak(string dics, string s)
        {
            string[] ss = dics.Split(' ');
            foreach (var item in ss)
            {
                dictwordbreak.Add(item);
                //dpdic.Add(item, 0);
            }
            if (WordBreakSolve(s) == 1)
                Console.WriteLine("True");
            else
                Console.WriteLine("False");
        }
        public static int WordBreakSolve(string s)
        {
            if (s.Length == 0)
                return 1;
            //if (dpdic.ContainsKey(s))
            //    return dpdic[s];

            for (int i = 1; i <= s.Length; i++)
            {
                int f = 0;
                string searchstr = s.Substring(0, i);

                foreach (var item in dictwordbreak)
                {
                    if (item == searchstr)
                    {
                        f = 1;
                        break;
                    }
                }

                if (f == 1)
                {
                    if (WordBreakSolve(s.Substring(i, s.Length - i)) == 1)
                    {
                        return 1;
                    }
                }
            }
            return -1;
        }

        public static int EditDistance(string x, string y, int m, int n)
        {
            int[,] dpedit = new int[m + 1, n + 1];

            for (int i = 0; i <= m; i++)
            {
                for (int j = 0; j <= n; j++)
                {
                    if (i == 0)
                    {
                        dpedit[i, j] = j;
                    }
                    else if (j == 0)
                    {
                        dpedit[i, j] = i;
                    }
                    else if (x[i - 1] == y[j - 1])
                    {
                        dpedit[i, j] = dpedit[i - 1, j - 1];
                    }
                    else
                    {
                        dpedit[i, j] = 1 + min(dpedit[i, j - 1], dpedit[i - 1, j], dpedit[i - 1, j - 1]);
                    }
                }
            }
            return dpedit[m, n];
        }

        public static int min(int i, int j, int k)
        {
            int l = Math.Min(i, j);
            return Math.Min(l, k);
        }
        #endregion
    }
}
