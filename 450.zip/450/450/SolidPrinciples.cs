﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;
using System.Threading.Tasks;

namespace _450
{
    //SOLID principles are the design principles that enable us to 
    //manage most of the software design problems. These principles provide us 
    //with ways to move from tightly coupled code and little encapsulation 
    //to the desired results of loosely coupled and encapsulated real needs of a business properly.


    #region SingleResponsiblePrinciple
    //Student class should consist of student functionality
    //For example Create, Update, Delete Studentor Related to Student itself
    public class SingleResponsiblePrinciple
    {
        public void CreateStudent()
        {
            // Add Student Code
        }

        public void UpdateStudent()
        {
            //Update Student
        }

        public void DeleteStudent()
        {
            //Delete Student
        }
    }
    #endregion


    public class OpenClosePrinciple
    {
        public abstract class Shape
        {
            public abstract double Area();
        }

        public class Rectangle : Shape
        {
            public double height { get; set; }
            public double width { get; set; }

            public override double Area()
            {
                return height * width;
            }
        }

        public class Circle : Shape
        {
            public double Radius { get; set; }
            public override double Area()
            {
                return Radius * Radius * Math.PI;
            }

        }

        public class CalculateArea
        {
            public double area = 0;
            public double TotalArea(Shape[] shapes)
            {
                foreach (var item in shapes)
                {
                    area += item.Area();
                }
                return area;
            }
        }
    }

    // Check if the subclass is taking to its core principle
    // It is all about the behaviour not about the attributes
    // Any sub-Class replacing parent class instantiation is not always fulfilling the LSP
    // When sub-calss behaviour does not matches with parent class then it cannot be called as LSP
    public class LiskovSubstitutionPrinciple
    {

        //Valid Example of LSP
        public class LSP
        {
            public class Food
            {
                public virtual void GatherIngredients(string[] ingredeients) { }
                public virtual void Cook() { }
            }

            public class Pizza : Food
            {
                public override void GatherIngredients(string[] ingredeients)
                {
                    List<string> UpdateIngredients = ingredeients.ToList();
                    UpdateIngredients.Add("Pizza base");
                    UpdateIngredients.Add("Lots of cheese");
                    UpdateIngredients.Add("Lots of ketchup");
                }
                public override void Cook()
                {

                }
            }
        }

        // Not Valid Example of LSP because it is not a healthy food
        public class NotLSP
        {
            public class HealthyFood
            {
                public virtual void GatherIngredients(string[] ingredeients) { }
                public virtual void Cook() { }
            }

            public class Pizza : HealthyFood
            {
                public override void GatherIngredients(string[] ingredeients)
                {
                    List<string> UpdateIngredients = ingredeients.ToList();
                    UpdateIngredients.Add("Pizza base");
                    UpdateIngredients.Add("Lots of cheese");
                    UpdateIngredients.Add("Lots of ketchup");
                }
                public override void Cook()
                {

                }
            }
        }
    }


    #region [Interface Segregation Principle]
    // Interface Segregation Principle states "that clients should not be forced to implement 
    // interfaces they don't use. Instead of one fat interface, many small interfaces are preferred 
    // based on groups of methods, each one serving one submodule.".
    interface IProgrammer
    {
        void WorkOnTask();
    }
    public interface ILead
    {
        void AssignTask();
        void CreateSubTask();
    }
    public class Programmers : IProgrammer
    {
        public void WorkOnTask()
        {
            // * Work On Task
        }
    }

    public class TeamLead : IProgrammer, ILead
    {
        public void WorkOnTask()
        {
            // * Work On Task
        }

        public void AssignTask()
        {
            // * Assign Task
        }

        public void CreateSubTask()
        {
            // * Create Sub Task
        }
    }

    public class Manager : ILead
    {
        public void AssignTask()
        {
            // * Assign Task
        }

        public void CreateSubTask()
        {
            // * Create Sub Task
        }
    }

    #endregion

    #region DependencyInversionPrinciple
    // The Dependency Inversion Principle (DIP) states that high-level modules/classes should not 
    // depend on low-level modules/classes. Both should depend upon abstractions. 
    // Secondly, abstractions should not depend upon details. Details should depend upon abstractions.


    //High-level modules/classes implement business rules or logic in a system (application). 
    //Low-level modules/classes deal with more detailed operations; in other words they 
    //may deal with writing information to databases or passing messages to the operating system or services.

    interface ILogger
    {
        void LogMessage(string message);
    }

    class DBLogger : ILogger
    {
        public void LogMessage(string message)
        {
            // Db Log Message
        }
    }

    class FileLogger : ILogger
    {
        public void LogMessage(string message)
        {
            // File Log Message
        }
    }

    class ExceptionLogging
    {
        private ILogger _ilogger;
        public ExceptionLogging(ILogger ilogger)
        {
            _ilogger = ilogger;
        }

        public void LogException(Exception aException)
        {
            _ilogger.LogMessage(ExceptiontoUserReadable(aException));
        }

        public string ExceptiontoUserReadable(Exception exception)
        {
            return exception.Message;
        }
    }

    class DataExporter
    {
        public void ExportDataFromFile()
        {
            ExceptionLogging logger;
            try
            {
                // Export data from file
            }
            catch (IOException ioex)
            {
                logger = new ExceptionLogging(new DBLogger());
                logger.LogException(ioex);
            }
            catch (Exception ex)
            {
                logger = new ExceptionLogging(new FileLogger());
                logger.LogException(ex);
            }
        }
    }

    #endregion
}

