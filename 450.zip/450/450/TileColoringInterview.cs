﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _450
{
    public class MatrixColoring
    {
        public void BFS(int[,] matrix, int findcolor, int replace)
        {
            int h = matrix.GetLength(0);
            if (h == 0)
                return;
            int l = matrix.GetLength(1);
            Boolean[,] visited = new Boolean[h, l];

            Queue<string> que = new Queue<string>();
            que.Enqueue("0,0");

            while (que.Count > 0)
            {
                string s = que.Dequeue();

                int row = Convert.ToInt32(s.Split(',')[0]);
                int col = Convert.ToInt32(s.Split(',')[1]);

                if ((row < 0) || (col < 0) || row >= h || col >= l || visited[row, col])
                    continue;

                if (matrix[row, col] != replace)
                {
                    if (matrix[row, col] != findcolor)
                    {
                        continue;
                    }
                }
                visited[row, col] = true;
                matrix[row, col] = replace;
                // Console.Write(matrix[row, col] + " ");
                que.Enqueue(row + "," + (col - 1));
                que.Enqueue(row + "," + (col + 1));
                que.Enqueue(row - 1 + "," + (col));
                que.Enqueue(row + 1 + "," + (col));
            }
        }

        public void printMatrix(int[,] matx)
        {
            for (int i = 0; i < matx.GetLength(0) - 1; i++)
            {
                for (int j = 0; j < matx.GetLength(1) - 1; j++)
                {
                    Console.Write(matx[i, j] + " ");
                }
                Console.WriteLine();
            }
        }

        public void DFSUtil(int[,] matrix, int row, int col, Boolean[,] visited, int findcolor, int replace)
        {
            int h = matrix.GetLength(0);
            int l = matrix.GetLength(1);

            if (row < 0 || col < 0 || col >= l || row >= h || visited[row, col])
                return;

            if (matrix[row, col] != replace)
            {
                if (matrix[row, col] != findcolor)
                {
                    return;
                }
            }
            visited[row, col] = true;
            matrix[row, col] = replace;

            // Console.Write(matrix[row, col] + " ");

            DFSUtil(matrix, row + 1, col, visited, findcolor, replace);
            DFSUtil(matrix, row - 1, col, visited, findcolor, replace);
            DFSUtil(matrix, row, col + 1, visited, findcolor, replace);
            DFSUtil(matrix, row, col - 1, visited, findcolor, replace);

        }
    }


}
