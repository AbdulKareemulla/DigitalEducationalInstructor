﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _450.DesignPattern
{
    //https://dotnettutorials.net/lesson/factory-method-design-pattern-csharp/
    //According to Gang of Four Definition “Define an interface for creating an object, 
    //but let the subclasses decide which class to instantiate.
    //The Factory Method Design Pattern is used, when we need to create the object (i.e.instance of the Product class) without exposing the object creation logic to the client.
    public interface IcreditCardFM
    {
        string GetCardInfo();
        int CardLimit();
        int AnnualCharges();
    }

    public class MoneyBackCard : IcreditCardFM
    {
        public string GetCardInfo()
        {
            return "MoneyBack";
        }
        public int CardLimit()
        {
            return 25000;
        }

        public int AnnualCharges()
        {
            return 2500;
        }
    }

    public class TitaniumCard : IcreditCardFM
    {
        public string GetCardInfo()
        {
            return "Titanium";
        }
        public int CardLimit()
        {
            return 30000;
        }

        public int AnnualCharges()
        {
            return 3000;
        }
    }

    public class PlatinumCard : IcreditCardFM
    {
        public string GetCardInfo()
        {
            return "Platinium";
        }
        public int CardLimit()
        {
            return 35000;
        }

        public int AnnualCharges()
        {
            return 3500;
        }
    }

    public abstract class CreditCardFactory
    {
        public abstract IcreditCardFM MakeProduct();

        public IcreditCardFM CreateProduct()
        {
            return this.MakeProduct();
        }
    }

    public class MoneyBackFactory : CreditCardFactory
    {
        public override IcreditCardFM MakeProduct()
        {
            IcreditCardFM icreditCard = new MoneyBackCard();
            return icreditCard;
        }
    }

    public class TitaniumFactory : CreditCardFactory
    {
        public override IcreditCardFM MakeProduct()
        {
            IcreditCardFM icreditCard = new TitaniumCard();
            return icreditCard;
        }
    }

    public class PlatinumFactory : CreditCardFactory
    {
        public override IcreditCardFM MakeProduct()
        {
            IcreditCardFM icreditCard = new PlatinumCard();
            return icreditCard;
        }
    }
}
