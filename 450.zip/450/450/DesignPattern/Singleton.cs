﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _450.DesignPattern
{
    // https://dotnettutorials.net/lesson/singleton-design-pattern/
    // Singleton Design Pattern is to ensures that only one instance of a particular class is going to be created and then provide simple global access to that instance for the entire application.

    // The Builder Design Pattern builds a complex object using many simple objects and using a step-by-step approach.
    // The Builder Design Pattern is all about separating the construction process from its representation. When the construction process of your object is very complex then only you need to use to Builder Design Pattern. 

    #region Structural Design 

    // The Adapter Design Pattern works as a bridge between two incompatible interfaces. 
    // This design pattern involves a single class called adapter which is responsible for communication between two independent or incompatible interfaces. 
    // So, in simple words, we can say that the Adapter Pattern helps two incompatible interfaces to work together. 


    // The Decorator Design Pattern allows us to dynamically add new functionalities to an existing object without altering or modifying its structure and this design pattern acts as a wrapper to the existing class.
    // This design pattern dynamically changes the functionality of an object at runtime without impacting the existing functionality of the objects.In short, this decorator design pattern adds additional functionalities to the object by wrapping it.

    #endregion

    #region Behavioural Design 

    // The Iterator Design Pattern in C# allows sequential access of elements without exposing the inside logic. 
    // That means using the Iterator Design Pattern we can access the elements of a collection object in a sequential manner without any need to know its internal representations.
    // The iterator pattern is a design pattern in which an iterator is used to traverse a container and access the elements of the container. 

    // The chain of responsibility design pattern creates a chain of receiver objects for a given request. In this design pattern, normally each receiver contains a reference to another receiver. If one receiver cannot handle the request then it passes the same request to the next receiver and so on. One receiver handles the request in the chain or one or more receivers handle the request.
    #endregion
    public sealed class Singleton
    {
        public int counter = 0;
        private static Singleton Instance = null;
        public static Singleton GetInstance
        {
            get
            {
                if (Instance == null)
                {
                    Instance = new Singleton();
                }
                return Instance;
            }
        }

        public Singleton()
        {
            counter++;
            Console.WriteLine("Value : " + counter.ToString());
        }

        public void Print(string mes)
        {
            Console.WriteLine(" From : " + mes);
        }
    }
}
