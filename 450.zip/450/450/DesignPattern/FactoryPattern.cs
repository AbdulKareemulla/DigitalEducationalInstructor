﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _450.DesignPattern
{
    // https://dotnettutorials.net/lesson/factory-design-pattern-csharp/
    // Design pattern are time tested solution for architecture problem.
    // Design pattern are time tested practice for OOP problems.
    // Design Patterns in the object-oriented world is a reusable solution to common software design problems that occur repeatedly in real-world application development.

    // Three types of design patterns
    // Creational design pattern
    // Structural design pattern
    // Behavioural design pattern

    // Creational design patterns are design patterns that deal with object creation mechanisms i.e. trying to create objects in a manner that is suitable to a given situation.
    // These design patterns are all about class instantiation or object creation.
    // Creational design patterns are the Factory Method, Abstract Factory, Builder, Singleton, Object Pool, and Prototype. 

    // Structural design patterns are about organizing different classes and objects to form larger structures and provide new functionality. 
    // Structural design patterns are Adapter, Bridge, Composite, Decorator, Facade, Flyweight, Private Class Data, and Proxy.

    // Behariour patterns are designed depending on how one class communicates with others.
    // Behavioral patterns are Chain of responsibility, Command, Interpreter, Iterator, Mediator, Memento, Null Object, Observer, State, Strategy, Template method, Visitor 

    // Simple Factory is a class with a method. That method will create and return different types of objects based on the input parameter, it received.
    public interface IcreditCard
    {
        string GetCardInfo();
        int CardLimit();
        int AnnualCharges();
    }

    public class MoneyBack : IcreditCard
    {
        public string GetCardInfo()
        {
            return "MoneyBack";
        }
        public int CardLimit()
        {
            return 25000;
        }

        public int AnnualCharges()
        {
            return 2500;
        }
    }

    public class Titanium : IcreditCard
    {
        public string GetCardInfo()
        {
            return "Titanium";
        }
        public int CardLimit()
        {
            return 30000;
        }

        public int AnnualCharges()
        {
            return 3000;
        }
    }

    public class Platinum : IcreditCard
    {
        public string GetCardInfo()
        {
            return "Platinium";
        }
        public int CardLimit()
        {
            return 35000;
        }

        public int AnnualCharges()
        {
            return 3500;
        }
    }

    public class FactoryClass
    {
        public IcreditCard Factory(string cardType)
        {
            IcreditCard icredit = null;
            if (cardType == "MoneyBack")
            {
                icredit = new MoneyBack();
            }
            else if (cardType == "Titanium")
            {
                icredit = new Titanium();
            }
            else if (cardType == "Platinum")
            {
                icredit = new Platinum();
            }
            return icredit;
        }
    }

}
