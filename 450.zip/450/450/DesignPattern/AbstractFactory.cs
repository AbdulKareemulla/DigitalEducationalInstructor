﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _450.DesignPattern
{
    //https://dotnettutorials.net/lesson/abstract-factory-design-pattern-csharp/
    // The Abstract Factory is a super factory that creates other factories. This Factory is also called Factory of Factories.
    public interface Animal
    {
        string Speak();
    }

    public class Cat : Animal
    {
        public string Speak()
        {
            return "Meow Meow";
        }
    }

    public class Lion : Animal
    {
        public string Speak()
        {
            return "Roar";
        }
    }

    public class Dog : Animal
    {
        public string Speak()
        {
            return "Bark";
        }
    }

    public class Octopus : Animal
    {
        public string Speak()
        {
            return "SQUAWCK";
        }
    }

    public class Shark : Animal
    {
        public string Speak()
        {
            return "Cannot Speak";
        }
    }

    public abstract class AnimalFactory
    {
        public abstract Animal GetAnimal(string AnimalType);
        public static AnimalFactory CreateAnimalFactory(string AnimalType)
        {
            if (AnimalType=="Land")
            {
                return new LandAnimalFactory();
            }
            else
            {
                return new SeaAnimalFactory();
            }
        }
    }

    public class LandAnimalFactory : AnimalFactory
    {
        public override Animal GetAnimal(string AnimalType)
        {
            if (AnimalType=="Dog")
            {
                return new Dog();
            }
            else if (AnimalType =="Cat")
            {
                return new Cat();
            }
            else if (AnimalType=="Lion")
            {
                return new Lion();
            }
            return null;
        }
    }

    public class SeaAnimalFactory : AnimalFactory
    {
        public override Animal GetAnimal(string AnimalType)
        {
            if (AnimalType=="Shark")
            {
                return new Shark();
            }
            else if (AnimalType=="Octopus")
            {
                return new Octopus();
            }
            return null;
        }
    }
}
