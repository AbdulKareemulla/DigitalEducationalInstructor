﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _450
{
    public class Practice
    {
        #region [Knapsack]
        public static void Knapsack(int[] wt, int[] val, int n, int w)
        {
            int[,] dp = new int[n + 1, w + 1];

            //for (int i = 0; i < n + 1; i++)
            //{
            //    for (int j = 0; j < w + 1; j++)
            //    {
            //        if (i == 0 || j == 0)
            //        {
            //            dp[n, w] = 0;
            //        }
            //    }
            //}

            for (int i = 1; i < n + 1; i++)
            {
                for (int j = 1; j < w + 1; j++)
                {
                    if (j >= wt[i - 1])
                    {
                        dp[i, j] = Math.Max(val[i - 1] + dp[i - 1, j - wt[i - 1]], dp[i - 1, j]);
                    }
                    else
                    {
                        dp[i, j] = dp[i - 1, j];
                    }
                }
            }

            Console.WriteLine("Maximum profit : " + dp[n, w]);
        }
        // {2,3,8,10} sum= 11
        // {8,3} is 11 just return true
        public static void SubsetSum(int[] arr, int n, int w)
        {
            bool[,] dp = new bool[n + 1, w + 1];

            for (int i = 0; i < n + 1; i++)
            {
                for (int j = 0; j < w + 1; j++)
                {
                    if (i == 0)
                        dp[i, j] = false;

                    if (j == 0)
                        dp[i, j] = true;
                }
            }
            for (int i = 1; i < n + 1; i++)
            {
                for (int j = 1; j < w + 1; j++)
                {
                    if (j >= arr[i - 1])
                    {
                        dp[i, j] = dp[i - 1, j - arr[i - 1]] || dp[i - 1, j];
                    }
                    else
                    {
                        dp[i, j] = dp[i - 1, j];
                    }
                }
            }

            Console.Write(" Sub " + dp[n, w]);
        }

        public static bool[,] SubsetSumreturn(int[] arr, int n, int w)
        {
            bool[,] dp = new bool[n + 1, w + 1];

            for (int i = 0; i < n + 1; i++)
            {
                for (int j = 0; j < w + 1; j++)
                {
                    if (i == 0)
                        dp[i, j] = false;

                    if (j == 0)
                        dp[i, j] = true;
                }
            }
            for (int i = 1; i < n + 1; i++)
            {
                for (int j = 1; j < w + 1; j++)
                {
                    if (j >= arr[i - 1])
                    {
                        dp[i, j] = dp[i - 1, j - arr[i - 1]] || dp[i - 1, j];
                    }
                    else
                    {
                        dp[i, j] = dp[i - 1, j];
                    }
                }
            }
            return dp;
            //Console.Write(" Sub " + dp[n, w]);
        }

        public static void EqualSumSubset(int[] arr, int n, int w)
        {
            int sum = 0;
            for (int i = 0; i < arr.Length; i++)
            {
                sum = sum + arr[i];
            }
            SubsetSum(arr, n, sum / 2);
        }

        // {2,3,5,6,8,10} sum =10 
        //{2,3,5}  {10}  {8,2} result=3
        public static void CountSubSet(int[] arr, int n, int w)
        {
            int[,] dp = new int[n + 1, w + 1];

            for (int i = 0; i < n + 1; i++)
            {
                for (int j = 0; j < w + 1; j++)
                {
                    if (j == 0)
                    {
                        dp[i, j] = 1;
                    }
                }
            }

            for (int i = 1; i < n + 1; i++)
            {
                for (int j = 1; j < w + 1; j++)
                {
                    if (j >= arr[i - 1])
                        dp[i, j] = dp[i - 1, j - arr[i - 1]] + dp[i - 1, j];
                    else
                        dp[i, j] = dp[i - 1, j];
                }
            }
            Console.WriteLine(dp[n, w]);
        }

        //diff= sum - 2(subset)
        //Find the last row in subsetsum whose values is true and min of the equation above
        //Below i represents the each subset 
        public static void MinDiff(int[] arr, int n)
        {
            int sum = 0;
            for (int i = 0; i < arr.Length; i++)
            {
                sum += arr[i];
            }
            bool[,] dp = SubsetSumreturn(arr, arr.Length, sum);
            int min = int.MaxValue;
            for (int i = 0; i < (sum + 1) / 2; i++)
            {
                if (dp[n, i] == true)
                {
                    min = Math.Min(min, sum - 2 * i);
                }
            }
            Console.WriteLine(min);
        }

        //sums1-sums2=diff;
        //sums1+sums2=sum;
        //sums1=(diff+sum)/2
        public static void CountSubsetSumdiff(int[] arr, int n, int diff)
        {
            int sum = 0;
            for (int i = 0; i < arr.Length; i++)
            {
                sum += arr[i];
            }
            int sums1 = (diff + sum) / 2;

            CountSubSet(arr, arr.Length, sums1);
        }

        /// Target sum is same as Count Subset Sum diff
        /// 

        /// UnBound Knapscak will pick same item multiple if it he is intreseted like icecream
        /// If someone no need to ask another time for icecrea
        /// 

        /// if someone not intrested in samosa then they will not pick the samosa and no need to check further
        /// Small difference is removing -1 from code below
        ///        dp[i, j] = Math.Max(val[i - 1] + dp[i
        ///        , j - wt[i - 1]], dp[i - 1, j]);


        /// if only one array is given that will be the profit array, rodlength aray we need to create 
        /// it using [1,2,3,4....n]
        public static void RodCutting(int[] rodlens, int[] profit, int rodlength, int n)
        {
            int[,] dp = new int[rodlength + 1, n + 1];


            for (int i = 0; i < rodlength + 1; i++)
            {
                for (int j = 0; j < n + 1; j++)
                {
                    if (i == 0 || j == 0)
                    {
                        dp[i, j] = 0;
                    }
                }
            }
            for (int i = 1; i < rodlength + 1; i++)
            {
                for (int j = 1; j < n + 1; j++)
                {
                    if (j >= rodlens[i - 1])
                    {
                        dp[i, j] = Math.Max(profit[i - 1] + dp[i, j - rodlens[i - 1]], dp[i - 1, j]);
                    }
                    else
                    {
                        dp[i, j] = dp[i - 1, j];
                    }
                }
            }
            Console.WriteLine("Max Profit is : " + dp[rodlength, n]);
        }

        public static void CoinChangeWays(int[] coins, int sum, int n)
        {
            int[,] dp = new int[n + 1, sum + 1];

            for (int j = 0; j < sum + 1; j++)
            {
                dp[0, j] = 0;
            }

            for (int i = 0; i < n + 1; i++)
            {
                dp[i, 0] = 1;
            }


            for (int i = 1; i < n + 1; i++)
            {
                for (int j = 1; j < sum + 1; j++)
                {
                    if (j >= coins[i - 1])
                    {
                        dp[i, j] = dp[i, j - coins[i - 1]] + dp[i - 1, j];
                    }
                    else
                    {
                        dp[i, j] = dp[i - 1, j];
                    }
                }
            }

            Console.WriteLine(" No Of Ways is : " + dp[n, sum]);
        }

        public static void MinimumCoins(int[] coins, int sum, int n)
        {
            int[,] dp = new int[n + 1, sum + 1];
            for (int i = 0; i < sum + 1; i++)
            {
                dp[0, i] = int.MaxValue - 1;
            }
            for (int i = 0; i < n + 1; i++)
            {
                dp[i, 0] = 0;
            }

            for (int i = 1; i < sum + 1; i++)
            {
                if (i % coins[0] == 0)
                {
                    dp[1, i] = i / coins[0];
                }
                else
                {
                    dp[1, i] = int.MaxValue - 1;
                }
            }

            for (int i = 2; i < n + 1; i++)
            {
                for (int j = 1; j < sum + 1; j++)
                {
                    if (j >= coins[i - 1])
                    {
                        dp[i, j] = Math.Min(1 + dp[i, j - coins[i - 1]], dp[i - 1, j]);
                    }
                    else
                    {
                        dp[i, j] = dp[i - 1, j];
                    }
                }
            }

            Console.WriteLine("Minimum Coins : " + dp[n, sum]);
        }



        #endregion

        #region [Subsequence]
        public static void LongestSubsequence(string x, string y, int m, int n)
        {
            int[,] dp = new int[m + 1, n + 1];

            for (int i = 0; i < n + 1; i++)
            {
                dp[0, i] = 0;
            }

            for (int i = 0; i < m + 1; i++)
            {
                dp[i, 0] = 0;
            }

            for (int i = 1; i < m + 1; i++)
            {
                for (int j = 1; j < n + 1; j++)
                {
                    if (x[i - 1] == y[j - 1])
                    {
                        dp[i, j] = 1 + dp[i - 1, j - 1];
                    }
                    else
                    {
                        dp[i, j] = Math.Max(dp[i - 1, j], dp[i, j - 1]);
                    }
                }
            }
            Console.WriteLine(dp[m, n]);
        }

        public static int[,] LongestSubsequenceReturn(string x, string y, int m, int n)
        {
            int[,] dp = new int[m + 1, n + 1];

            for (int i = 0; i < n + 1; i++)
            {
                dp[0, i] = 0;
            }

            for (int i = 0; i < m + 1; i++)
            {
                dp[i, 0] = 0;
            }

            for (int i = 1; i < m + 1; i++)
            {
                for (int j = 1; j < n + 1; j++)
                {
                    if (x[i - 1] == y[j - 1])
                    {
                        dp[i, j] = 1 + dp[i - 1, j - 1];
                    }
                    else
                    {
                        dp[i, j] = Math.Max(dp[i - 1, j], dp[i, j - 1]);
                    }
                }
            }
            //Console.WriteLine(dp[m, n]);
            return dp;
        }

        public static void LongestSubString(string x, string y, int m, int n)
        {
            int[,] dp = new int[m + 1, n + 1];
            int len = 0;
            for (int i = 1; i < m + 1; i++)
            {
                for (int j = 1; j < n + 1; j++)
                {
                    if (x[i - 1] == y[j - 1])
                    {
                        dp[i, j] = 1 + dp[i - 1, j - 1];
                        if (dp[i, j] > len)
                        {
                            len = dp[i, j];
                        }
                    }
                    else
                    {
                        dp[i, j] = 0;
                    }
                }
            }
            Console.WriteLine(len);
        }

        public static void PrintSubsequence(string x, string y, int m, int n)
        {
            string result = "";
            int[,] dp = LongestSubsequenceReturn(x, y, m, n);
            while (m > 0 && n > 0)
            {
                if (x[m - 1] == y[n - 1])
                {
                    result = x[m - 1] + result;
                    m--;
                    n--;
                }
                else
                {
                    if (dp[m, n - 1] > dp[m - 1, n])
                    {
                        n--;
                    }
                    else
                    {
                        m--;
                    }
                }
            }

            Console.WriteLine(result);
        }

        public static void ShortestCommonSupersequence(string x, string y, int m, int n)
        {
            int[,] dp = LongestSubsequenceReturn(x, y, m, n);
            int lcs = dp[m, n];

            int strlen = (x.Length + y.Length) - lcs;
            Console.Write(strlen);
        }

        public static void MinimuminsertionDeletionAtoB(string x, string y, int m, int n)
        {
            int[,] dp = LongestSubsequenceReturn(x, y, m, n);
            int lcs = dp[m, n];
            int mindel = (x.Length) - lcs;
            int mininst = (y.Length) - lcs;
            Console.WriteLine(
                "Minimum Deletion " + mindel +
                " Minimum Insertion " + mininst);
        }

        public static void LongestPalindromicSubsequence(string x, int m)
        {
            char[] chreverse = x.ToCharArray();
            Array.Reverse(chreverse);
            string y = new string(chreverse);
            int[,] dp = LongestSubsequenceReturn(x, y, m, y.Length);
            int lcs = dp[m, y.Length];
            Console.Write(lcs);
        }

        public static void MinimumNoDeletiontoPalindrome(string x, int m)
        {
            char[] chrarr = x.ToCharArray();
            Array.Reverse(chrarr);
            string y = new string(chrarr);
            int[,] dp = LongestSubsequenceReturn(x, y, m, y.Length);
            int lcs = dp[m, y.Length];
            Console.WriteLine(m - lcs);
        }

        public static void PrintShortestSubsequence(string x, int m, string y, int n)
        {
            int[,] dp = LongestSubsequenceReturn(x, y, m, n);
            string res = "";
            while (m > 0 && n > 0)
            {
                if (x[m - 1] == y[n - 1])
                {
                    res = x[m - 1] + res;
                    m--;
                    n--;
                }
                else
                {
                    if (dp[m - 1, n] > dp[m, n - 1])
                    {
                        res = x[m - 1] + res;
                        m--;
                    }
                    else
                    {
                        res = y[n - 1] + res;
                        n--;
                    }
                }
            }

            while (m > 0)
            {
                m--;
                res = x[m] + res;

            }

            while (n > 0)
            {
                n--;
                res = y[n] + res;

            }
            Console.WriteLine(res);
        }

        public static void LongestRepeatingSequence(string x, int m)
        {
            string y = x;
            int n = m;
            int[,] dp = new int[m + 1, n + 1];
            for (int i = 0; i < m + 1; i++)
            {
                for (int j = 0; j < n + 1; j++)
                {
                    if (i == 0 && j == 0)
                    {
                        dp[i, j] = 0;
                    }
                }

            }

            for (int i = 1; i < m + 1; i++)
            {
                for (int j = 1; j < n + 1; j++)
                {
                    if (x[i - 1] == y[j - 1] && i != j)
                    {
                        dp[i, j] = 1 + dp[i - 1, j - 1];
                    }
                    else
                    {
                        dp[i, j] = Math.Max(dp[i - 1, j], dp[i, j - 1]);
                    }
                }
            }
            Console.Write(dp[m, n]);
        }

        public static void SequencePatternMatching(string x, string y, int m, int n)
        {
            int[,] dp = LongestSubsequenceReturn(x, y, m, n);
            int lcs = dp[m, n];

            int min = Math.Min(m, n);
            if (min == lcs)
            {
                Console.WriteLine(true);
            }
            else { Console.WriteLine(false); }
        }

        public static void MinimumNoInsertiontoPalindrome(string x, int m)
        {
            char[] chrarr = x.ToCharArray();
            Array.Reverse(chrarr);
            string y = new string(chrarr);
            int[,] dp = LongestSubsequenceReturn(x, y, m, y.Length);
            int lcs = dp[m, y.Length];
            Console.WriteLine(m - lcs);
        }
        #endregion

        #region [Matrix Chain Multiplication]

        static int[,] dp = new int[1000, 1000];
        public static int MinCost(int[] arr, int i, int j)
        {
            if (i == j)
            {
                return 0;
            }
            if (dp[i, j] != 0)
            {
                return dp[i, j];
            }
            int min = int.MaxValue;
            for (int k = i; k < j; k++)
            {
                int temp = MinCost(arr, i, k) + MinCost(arr, k + 1, j) + arr[i - 1] * arr[k] * arr[j];
                if (temp < min)
                    min = temp;
            }
            return dp[i, j] = min;
        }

        public static bool IsPalindrom(string s, int i, int j)
        {
            if (i == j)
            {
                return true;
            }

            if (i > j)
            {
                return true;
            }
            while (i < j)
            {
                if (s[i] != s[j])
                    return false;
                i++;
                j--;
            }
            return true;
        }

        public static int Palindrompartition(string s, int i, int j)
        {
            if (i >= j)
            {
                return 0;
            }
            if (IsPalindrom(s, i, j))
            {
                return 0;
            }
            if (dp[i, j] != 0)
            {
                return dp[i, j];
            }
            int min = int.MaxValue;
            for (int k = i; k < j; k++)
            {
                int left = 0;
                int right = 0;
                if (dp[i, k] != 0)
                {
                    left = dp[i, k];
                }
                else
                {
                    left = Palindrompartition(s, i, k);
                    dp[i, k] = left;
                }

                if (dp[k + 1, j] != 0)
                {
                    right = dp[k + 1, j];
                }
                else
                {
                    right = Palindrompartition(s, k + 1, j);
                    dp[k + 1, j] = right;
                }


                int temp = left + right + 1;
                if (min > temp)
                {
                    min = temp;
                }

            }

            return dp[i, j] = min;
        }

        public static int EvaluatetoTrue(string s, int i, int j, bool istrue)
        {
            int ans = 0;
            if (i > j)
            {
                return 0;
            }
            if (i == j)
            {
                if (istrue)
                {
                    if (s[i] == 'T')
                    {
                        return 1;
                    }
                    else
                    {
                        return 0;
                    }
                }
                else
                {
                    if (s[i] == 'F')
                    {
                        return 1;
                    }
                    else
                    {
                        return 0;
                    }
                }
            }

            for (int k = i + 1; k < j; k = k + 2)
            {
                int lt = EvaluatetoTrue(s, i, k - 1, true);
                int lf = EvaluatetoTrue(s, i, k - 1, false);
                int rt = EvaluatetoTrue(s, k + 1, j, true);
                int rf = EvaluatetoTrue(s, k + 1, j, false);

                if (s[k] == '&')
                {
                    if (istrue)
                    {
                        ans = ans + (lt * rt);
                    }
                    else
                    {
                        ans = ans + (lf * rt) + (lt * rf) + (rf * lf);
                    }
                }

                else if (s[k] == '|')
                {
                    if (istrue)
                    {
                        ans = ans + (lt * rt) + (lf * rt) + (lt * rf);
                    }
                    else
                    {
                        ans = ans + (rf * lf);
                    }
                }

                else if (s[k] == '^')
                {
                    if (istrue)
                    {
                        ans = ans + (lf * rt) + (lt * rf);
                    }
                    else
                    {
                        ans = ans + (rf * lf) + (lt * rt);
                    }
                }
            }
            return ans;
        }

        static Dictionary<string, bool> cache = new Dictionary<string, bool>();
        public static bool ScrumbledString(string a, string b)
        {
            if (a.CompareTo(b) == 0)
            {
                return true;
            }
            if (a.Length <= 1)
            {
                return false;
            }
            bool flag = false;
            int n = a.Length;
            if (cache.ContainsKey(a + "" + b))
            {
                return cache[a + "" + b];
            }
            for (int i = 1; i < n; i++)
            {
                bool cond1 = ((ScrumbledString(a.Substring(0, i), b.Substring(n - i, i)) == true)
                    && (ScrumbledString(a.Substring(i, n - i), b.Substring(0, n - i))));

                bool cond2 = ((ScrumbledString(a.Substring(0, i), b.Substring(0, i))) == true) &&
                    (ScrumbledString(a.Substring(i, n - i), b.Substring(i, n - i)));

                if (cond1 || cond2)
                {
                    flag = true;
                    break;
                }
            }
            cache.Add(a + "" + b, flag);
            return flag;
        }

        static int[,] dpeggdrop = new int[1001, 1001];
        public static int EggDropping(int egg, int floor)
        {
            if (floor == 0 || floor == 1)
            {
                return floor;
            }
            if (egg == 1)
            {
                return floor;
            }
            if (dpeggdrop[egg, floor] != 0)
            {
                return dpeggdrop[egg, floor];
            }

            int min = int.MaxValue;
            for (int k = 1; k < floor; k++)
            {
                int temp = 1 + Math.Max(EggDropping(egg - 1, k - 1), EggDropping(egg, floor - k));
                if (temp < min)
                {
                    min = temp;
                }
            }
            return dpeggdrop[egg, floor] = min;
        }

        #endregion

        #region[Trees]

        public class DPTressNode
        {
            public DPTressNode leftnode;
            public DPTressNode rightnode;
            public int data;
            public DPTressNode(int d)
            {
                data = d;
                leftnode = null;
                rightnode = null;
            }
        }

        public class min
        {
            public int mvalue = int.MinValue;
        }

        public class TreeDP
        {
            public int TreeHeight(DPTressNode node)
            {
                if (node == null)
                    return 0;
                else
                {
                    int l = TreeHeight(node.leftnode);
                    int r = TreeHeight(node.rightnode);

                    return 1 + Math.Max(l, r);
                    //if (l > r)
                    //    return (l + 1);
                    //else
                    //    return (r + 1);
                }
            }

            public int TreeDiameter(DPTressNode root, min minval)
            {
                if (root == null)
                {
                    return 0;
                }
                int l = TreeDiameter(root.leftnode, minval);
                int r = TreeDiameter(root.rightnode, minval);

                int temp = Math.Max(l, r) + 1;
                int ans = Math.Max(l + r + 1, temp);
                minval.mvalue = Math.Max(minval.mvalue, ans);
                return temp;
            }

            public int TreeFullPath(DPTressNode root, min minval)
            {
                if (root == null)
                    return 0;

                int l = TreeFullPath(root.leftnode, minval);
                int r = TreeFullPath(root.rightnode, minval);

                int temp = Math.Max(Math.Max(l, r) + root.data, root.data);
                int ans = Math.Max(temp, l + r + root.data);
                minval.mvalue = Math.Max(minval.mvalue, ans);

                return temp;
            }

            public int TreeFullPathWithLeaf(DPTressNode root, min minval)
            {
                if (root == null)
                    return 0;
                int l = TreeFullPathWithLeaf(root.leftnode, minval);
                int r = TreeFullPathWithLeaf(root.rightnode, minval);

                int temp = Math.Max(l, r) + root.data;
                int ans = l + r + root.data;
                minval.mvalue = Math.Max(minval.mvalue, ans);
                return temp;
            }
        }

        #endregion
    }
}
